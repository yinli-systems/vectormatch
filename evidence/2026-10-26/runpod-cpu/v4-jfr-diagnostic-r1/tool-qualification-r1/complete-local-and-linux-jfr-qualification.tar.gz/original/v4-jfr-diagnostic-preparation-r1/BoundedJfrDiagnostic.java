package io.vectormatch.cluster;
import jdk.jfr.*;
import jdk.jfr.consumer.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Isolated synthetic qualification; never attaches to or profiles an unrelated JVM. */
public final class BoundedJfrDiagnostic {
    static final Set<String> ALLOW=Set.of("jdk.FileForce","jdk.FileWrite","jdk.GarbageCollection","jdk.GCPhasePause","jdk.CPULoad","jdk.ThreadCPULoad","jdk.ExecutionSample","jdk.ThreadPark","jdk.ObjectAllocationSample","jdk.DataLoss","jdk.JVMInformation","jdk.ActiveRecording","jdk.ActiveSetting");
    static void require(boolean value,String why){if(!value)throw new IllegalStateException(why);}
    static Configuration configuration(Path file)throws Exception {
        var c=Configuration.create(file);
        for(var e:c.getSettings().entrySet())require(ALLOW.contains(e.getKey().split("#",2)[0]),"Event outside explicit allowlist");
        for(String name:ALLOW)require("true".equals(c.getSettings().get(name+"#enabled")),"Required selected event not explicitly enabled");
        require("0 ns".equals(c.getSettings().get("jdk.FileForce#threshold")),"Force calls must not be threshold sampled");
        require("0 ns".equals(c.getSettings().get("jdk.FileWrite#threshold")),"Writes must not be threshold sampled");
        return c;
    }
    public static void main(String[] args)throws Exception {
        require(args.length==2||args.length==3&&args[2].equals("--require-startup-recording"),"BoundedJfrDiagnostic <explicit-jfc> <new-owned-directory> [--require-startup-recording]");
        Path jfc=Path.of(args[0]).toAbsolutePath().normalize(),root=Path.of(args[1]).toAbsolutePath().normalize();
        for(Path p=root;p!=null;p=p.getParent())require(!Files.isSymbolicLink(p),"Symlink owned path refused");
        var config=configuration(jfc);Files.createDirectory(root);Path target=root.resolve("synthetic-force-only.bin"),dump=root.resolve("self-test.jfr");
        try(var recording=new Recording(config)) {
            recording.setName("VectorMatch-isolated-JFR-qualification");recording.setToDisk(true);recording.setMaxSize(32L*1024*1024);recording.start();
            try(var channel=FileChannel.open(target,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)) {
                for(int n=0;n<4;n++){var data=ByteBuffer.wrap(new byte[]{86,77,45,84,69,83,84,(byte)n});while(data.hasRemaining())channel.write(data);channel.force(true);}
            }
            Thread.sleep(1200);recording.stop();recording.dump(dump);
        }
        require(Files.size(dump)<=32L*1024*1024,"JFR qualification file budget");
        int force=0,write=0,info=0;long bytes=0;var types=new TreeMap<String,Long>();
        try(var events=new RecordingFile(dump)) {
            while(events.hasMoreEvents()) {
                var e=events.readEvent();String name=e.getEventType().getName();require(ALLOW.contains(name),"Unregistered event payload: "+name);types.merge(name,1L,Long::sum);
                if(name.equals("jdk.DataLoss"))require(e.getLong("amount")==0,"JFR data loss");
                if(name.equals("jdk.JVMInformation")){require(e.getLong("pid")==ProcessHandle.current().pid(),"Recorded JVM identity differs");info++;}
                if(name.equals("jdk.FileForce")&&target.toString().equals(e.getString("path"))){require(e.getBoolean("metaData")&&!e.getDuration().isNegative(),"Force event metadata/duration differs");force++;}
                if(name.equals("jdk.FileWrite")&&target.toString().equals(e.getString("path"))){write++;bytes+=e.getLong("bytesWritten");}
            }
        }
        require(force==4&&write==4&&bytes==32&&info>0,"Synthetic force/write/PID observation incomplete");
        boolean startupChecked=false;
        if(args.length==3) {
            var startup=FlightRecorder.getFlightRecorder().getRecordings().stream().filter(r->r.getName().equals("vm-owned-startup")).findFirst().orElseThrow();
            require(startup.getSettings().equals(config.getSettings()),"Actual startup recording settings differ from explicit JFC");
            Path destination=root.getParent().resolve("startup-"+ProcessHandle.current().pid()+".jfr");
            require(destination.equals(startup.getDestination()),"Startup recording filename did not expand the actual PID");
            startup.stop();require(Files.isRegularFile(destination)&&Files.size(destination)<=32L*1024*1024,"Startup JFR destination/budget");
            int startupForce=0,startupWrite=0,startupInfo=0;
            try(var events=new RecordingFile(destination)) {
                while(events.hasMoreEvents()) {
                    var e=events.readEvent();String name=e.getEventType().getName();require(ALLOW.contains(name),"Unregistered startup event payload: "+name);
                    if(name.equals("jdk.DataLoss"))require(e.getLong("amount")==0,"Startup JFR data loss");
                    if(name.equals("jdk.JVMInformation")){require(e.getLong("pid")==ProcessHandle.current().pid(),"Startup JFR PID differs");startupInfo++;}
                    if(name.equals("jdk.FileForce")&&target.toString().equals(e.getString("path")))startupForce++;
                    if(name.equals("jdk.FileWrite")&&target.toString().equals(e.getString("path")))startupWrite++;
                }
            }
            require(startupForce==4&&startupWrite==4&&startupInfo>0,"Startup recording incomplete");startupChecked=true;
        }
        var result=new LinkedHashMap<String,Object>();result.put("passed",true);result.put("actualJfrFileForceEvents",force);result.put("actualJfrFileWriteEvents",write);result.put("actualJfrWrittenBytes",bytes);result.put("recordedPid",ProcessHandle.current().pid());result.put("eventCounts",types);result.put("explicitJfcSha256",HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(jfc))));result.put("noEnvironmentOrPropertyEvents",true);result.put("noClusterOrBusinessStarted",true);result.put("startupEnvironmentAndPidExpansionChecked",startupChecked);RetentionCapacityJsonV3.writeNew(root.resolve("RESULT.json"),result);
    }
}
