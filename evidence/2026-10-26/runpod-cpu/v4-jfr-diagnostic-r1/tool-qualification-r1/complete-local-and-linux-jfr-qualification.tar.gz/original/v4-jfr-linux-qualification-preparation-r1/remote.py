from pathlib import Path
import json,sys,hashlib,base64,socket,os,shutil,subprocess,time,importlib.util,tarfile
c=json.load(sys.stdin);root=Path(c['root']);assert root==Path('/opt/vectormatch-cpu/tools/cpu-jfr-selftest-r1')and not root.exists()and socket.gethostname()=='33ace3d92505'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==c['baseline']['bootId']and sorted(os.sched_getaffinity(0))==c['baseline']['affinity']
assert Path('/sys/fs/cgroup/cpu.max').read_text()==c['baseline']['cpuMax']and Path('/sys/fs/cgroup/memory.max').read_text()==c['baseline']['memoryMax']
assert not Path('/opt/vectormatch-cpu/restorations/original-native-r1').exists()and not Path('/opt/vectormatch-cpu/preparation').exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:a=(p/'cmdline').read_bytes().split(bytes([0]));name=Path(os.fsdecode(a[0])).name
 except(FileNotFoundError,ProcessLookupError):continue
 assert name not in('java','javac','javaw','postgres','postmaster','Runner.Listener','Runner.Worker'),name
assert sha(Path(c['java']))==c['javaSha256']and sha(Path(c['java']).parent.parent/'release')==c['releaseSha256']and shutil.disk_usage(root.parent).free>=1024**3
lib=Path(c['lib']);jars={n[4:]:pin for n,pin in c['rows'].items()if n.startswith('lib/')}
for n,pin in jars.items():assert sha(lib/n)==pin['sha256']and(lib/n).stat().st_size==pin['bytes']
os.umask(0o077);root.mkdir(mode=0o700)
for n,pin in c['files'].items():
 path=Path(n);assert not path.is_absolute()and'..'not in path.parts;body=base64.b64decode(pin['body']);assert len(body)==pin['bytes']and hashlib.sha256(body).hexdigest()==pin['sha256'];target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
assert sha(root/'owned_linux_base_8eeb.py')=='d7008449ab64fc689fa61e12040754d49026bb47070eb0cb9875ba7c968223bb'and sha(root/'owned_process_identity.py')=='51ad33fc51a92cdb9041e78093d39e38a42191a9ec50ad9635fd7cc314ba7a1a'
spec=importlib.util.spec_from_file_location('qualified_base',root/'owned_linux_base_8eeb.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);base.enable_pidfd()
args=[c['java'],'--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','-Xmx128m','-cp',str(root/'classes')+':'+':'.join(str(lib/n)for n in c['jarOrder']),'io.vectormatch.cluster.BoundedJfrDiagnostic',str(root/'owned-only.jfc'),str(root/'native-self-test'),'--require-startup-recording']
env={k:v for k,v in os.environ.items()if k not in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS']};env['JAVA_TOOL_OPTIONS']='-XX:StartFlightRecording=name=vm-owned-startup,settings='+str(root/'owned-only.jfc')+',filename='+str(root/'startup-%p.jfr')+',dumponexit=true,maxsize=32m -XX:FlightRecorderOptions=repository='+str(root/'repository')
base.save(root/'STARTUP_OPTIONS.json',dict(registeredJavaToolOptions=env['JAVA_TOOL_OPTIONS'],explicitEventAllowlistSha256=sha(root/'owned-only.jfc'),noEnvironmentOrSystemPropertyEventsSelected=True))
with(root/'stdout').open('xb')as out,(root/'stderr').open('xb')as err:p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,cwd=root,env=env)
record=None
for unused in range(100):
 row=base.process_identity(p.pid)
 if row is not None and row['arguments']==args:record=row;break
 if p.poll()is not None:break
 time.sleep(.005)
assert record is not None,'owned JFR probe identity unproven;no unregistered signal';base.save(root/'STARTED.json',record)
try:code=p.wait(timeout=45)
except subprocess.TimeoutExpired:
 base.stop_owned(record,5);p.wait(timeout=5);raise
finally:
 if p.poll()is None:base.stop_owned(record,5);p.wait(timeout=5)
assert base.matching_identity(record)is None and not Path('/proc',str(record['pid'])).exists()
assert code==0,(code,(root/'stderr').read_text());result=json.loads((root/'native-self-test/RESULT.json').read_text());assert result['passed']and result['noEnvironmentOrPropertyEvents']and result['actualJfrFileForceEvents']==4 and result['actualJfrFileWriteEvents']==4 and result['startupEnvironmentAndPidExpansionChecked']
for n,pin in c['files'].items():assert sha(root/n)==pin['sha256']
for n,pin in jars.items():assert sha(lib/n)==pin['sha256']
summary=dict(passed=True,actualPinnedLinuxJdk=True,sourceInputsUnchanged=True,applicationJarsUnchanged=True,ownedProbeProcess=record,strictProcessAbsentAfterWait=True,nativeSelfTest=result,noClusterOrBusinessStarted=True,noPerformanceClaim=True);base.save(root/'ROOT_RESULT.json',summary)
sp=importlib.util.spec_from_file_location('scope_tar',root/'scope_tar.py');scope=importlib.util.module_from_spec(sp);sp.loader.exec_module(scope);inventory=scope.tree(root);out=Path('/opt/vectormatch-cpu/collections/jfr-selftest-r1');assert not out.exists();out.mkdir();archive=out/'complete-jfr-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:t.add(root,arcname='original/qualification')
review=scope.verify(archive,{'qualification':inventory});assert scope.tree(root)==inventory
manifest=dict(passed=True,rootResult=summary,sourceScopes={'qualification':inventory},everyOriginalMemberVerified=review,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)));base.save(out/'MANIFEST.json',manifest);print(json.dumps(manifest))
