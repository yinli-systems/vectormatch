# V4 common-artifact comparison:500/s

All four arms use the same compiled artifact and fixed leader/configuration. These are separate20-second fresh lineages on one physical CPU.

| Arm | Policy | Accepted/planned | In-window goodput/s | End-to-end p50 ms | End-to-end p99 ms | Post-offer p99 ms | notSent | UNKNOWN final |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | PAUSE | 10000/10000 | 499.8 | 9.349 | 286.782 | 31.669 | 0 | 0 |
| D1 | CONTINUE | 10000/10000 | 499.8 | 8.172 | 65.651 | 11.935 | 0 | 0 |
| C2 | PAUSE | 10000/10000 | 499.75 | 8.194 | 175.014 | 11.671 | 0 | 0 |
| D2 | CONTINUE | 10000/10000 | 499.85 | 8.123 | 59.925 | 11.242 | 0 | 0 |

All four prospective finite gates passed:True. Both registered paired direction criteria passed:True. Both candidates meet the10ms p99 target:False. No default performance promotion follows from these two pairs.

C1/D1:global p99 change -77.10770417669602%;post-offer p99 change -62.312242327714706%;in-window goodput difference 0.0/s.
C2/D2:global p99 change -65.75974297325703%;post-offer p99 change -3.675184988838165%;in-window goodput difference 0.10000000000002274/s.
Each original command/result,trade/event prefix,deadline,read credit and forced/readback receipt passed independent audit. The same adapter replays the actual positive physical-offer order and checks every received reply. All three snapshots and actual cold restores agree in every arm. Each full raw asset was authenticated,re-downloaded and every member byte/mode/owner/directory verified before progression.

Two pairs of finite20-second fresh lineages on one physical host;direction criterion is not statistical significance,endurance,SLA,independent-host durability,100M continuity or funded trading.

The next preregistered rate is 1000 only after this review is privately published. A failed finite gate stops upward escalation;conditional percentiles never replace undefined all-arrival p99.
