import pathlib,json,sys,subprocess,hashlib,tarfile,os,stat,datetime
c=json.loads(sys.argv[1]);attempt=c['attempt'];assert attempt in(1,2,3,4,5,6,7,8,9,10,12,13,14,15)
base=pathlib.Path('/opt/vectormatch-cpu/ci');root=base/f'production-correctness-r{attempt}';repo=root/'runner/_work/vectormatch/vectormatch'
assert root.is_dir()and not(root/'runner/.runner').exists()and not(root/'runner/.credentials').exists()
out=base/'collections'/f'correctness-attempt-{attempt}-r1';assert not out.exists();out.mkdir(parents=True)
files={}
def pin(p):
 assert p.is_file()and not p.is_symlink();s=p.stat();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return dict(bytes=s.st_size,sha256=h.hexdigest(),mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
def add(label,p):
 assert label not in files;files[label]=dict(path=str(p),**pin(p))
for n in ['PREPARED.json','REGISTERED.json','listener.log','config.stdout','config.stderr','git-build.log','git-build-c-only.log','C_ONLY_BUILD_ARGUMENTS.json','initial-failed-build-CFLAGS']:
 if(root/n).is_file():add('runner-public-metadata/'+n,root/n)
git=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r2/tools/git-2.56.0/bin/git')
source=None
if(repo/'.git').is_dir():
 def readgit(*args):return subprocess.check_output(['runuser','-u','vmci','--',str(git),'-C',str(repo),*args],cwd=repo)
 source=readgit('rev-parse','HEAD').decode().strip();assert source==c['expectedSource']
 for row in readgit('ls-files','--stage','-z').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);path=repo/os.fsdecode(name)
  if path.is_file():
   assert meta.split()[0]in(b'100644',b'100755')
   add('source/'+os.fsdecode(name),path)
   h=hashlib.sha1();body=path.read_bytes();h.update(b'blob '+str(len(body)).encode()+b'\0'+body);assert h.hexdigest()==meta.split()[1].decode()
 for module in ('core','cluster','server','projector','bench'):
  for sub in ('test-results','classes','resources','libs'):
   folder=repo/module/'build'/sub
   if folder.is_dir():
    for p in sorted(folder.rglob('*')):
     if p.is_file():add('compiled-and-tests/'+p.relative_to(repo).as_posix(),p)
 if(repo/'runtime/ci').is_dir():
  for p in sorted((repo/'runtime/ci').rglob('*')):
   if p.is_file():add('ci-results/'+p.relative_to(repo/'runtime/ci').as_posix(),p)
assert len(files)<10000 and sum(p['bytes']for p in files.values())<256*1024**2
archive=out/'complete-code-compiled-tests-and-public-logs.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for label,row in sorted(files.items()):t.add(row['path'],arcname='original/'+label,recursive=False)
assert archive.stat().st_size<64*1024**2
for row in files.values():assert pin(pathlib.Path(row['path']))=={k:v for k,v in row.items()if k!='path'}
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),attempt=attempt,sourceCommit=source,
 sourceCheckoutComplete=source is not None,githubRun=c['githubRun'],githubConclusion=c['githubConclusion'],
 archive=dict(path=str(archive),**pin(archive)),originalFiles=files,
 scope='Complete materialized tracked source,compiled classes/resources/JARs,all JUnit result bodies and CI result logs;whitelisted public runner metadata only. No .git,tool caches,worker diagnostic logs,job credentials,registration token,SSH or API keys.')
(out/'MANIFEST.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
