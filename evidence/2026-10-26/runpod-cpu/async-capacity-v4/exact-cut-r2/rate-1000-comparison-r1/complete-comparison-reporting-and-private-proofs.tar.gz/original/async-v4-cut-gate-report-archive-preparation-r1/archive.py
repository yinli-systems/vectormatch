from pathlib import Path
import sys,json,tarfile,shutil,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';P=Path(__file__).resolve().parent;rate=int(sys.argv[1]);O=B/('async-v4-cut-gate-'+str(rate)+'-comparison-r1');A=W/('evidence/2026-10-26/runpod-cpu/async-capacity-v4/exact-cut-r2/rate-'+str(rate)+'-comparison-r1');assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
result=json.loads((O/'RESULT.json').read_text());assert result['passed']
names=[P.name,'async-v4-cut-gate-'+str(rate)+'-comparison-r1','async-v4-cut-gate-'+str(rate)+'-reporting-r1','async-v4-cut-gate-comparison-preparation-r1','async-v4-cut-gate-reporting-preparation-r1','async-v4-cut-gate-native-private-proof-preparation-r1','async-v4-cut-gate-native-archive-preparation-r1','async-v4-cut-gate-point-closure-preparation-r1','dispatch-capacity-scope-tar-preparation-r1']
names+=['async-v4-cut-gate-'+str(rate)+'-'+a+'-private-proof-r1'for a in ['c1','d1','c2','d2']]
retry=B/('async-v4-cut-gate-'+str(rate)+'-c2-private-proof-read-retry-r1')
if retry.exists():names.append(retry.name)
refs={}
for arm in ['c1','d1','c2','d2']:
 case=W/('evidence/2026-10-26/runpod-cpu/async-capacity-v4/exact-cut-r2/rate-'+str(rate)+'-'+arm+'-native-r1');proof=json.loads((B/('async-v4-cut-gate-'+str(rate)+'-'+arm+'-private-proof-r1')/'PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified'];refs[arm]=dict(privateCommit=proof['commit'],closedSha256=sha(case/'CLOSED.json'),assetManifestSha256=sha(case/'ASSET_MANIFEST.json'),assetId=proof['assetId'],assetBytes=proof['assetBytes'],assetSha256=proof['assetSha256'])
before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-comparison-reporting-and-private-proofs.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
review=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+chr(10));(A/'POINT_PRIVATE_REFERENCES.json').write_text(json.dumps(refs,indent=2,sort_keys=True)+chr(10));shutil.copy2(O/'RESULT.json',A/'RESULT.json')
for name,path in [('docs/EXACT_CUT_CAPACITY_RESULTS_V4.md',W/'docs/EXACT_CUT_CAPACITY_RESULTS_V4.md'),('evidence/index.json',W/'evidence/index.json'),('README.md',W/'README.md')]:
 dest=A/'published'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
(A/'README.md').write_text('# Exact-cut V4 paired finite capacity report: '+str(rate)+'/s'+2*chr(10)+'All four complete original native assets have committed private manifests and authenticated re-download/every-member verification. This archive preserves comparison derivation, console before/after records, the published report and private progression proofs. Every failed attempt remains separate; no historical incident is attributed to this new campaign.'+2*chr(10)+'RESULT.json records all finite and paired-direction decisions. POINT_PRIVATE_REFERENCES binds exact attachments. The next rate requires this report to be privately pushed and restored from actual Git. No default performance promotion, SLA, independent-host durability, continuous100M or funded trading claim.'+chr(10))
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+chr(10));(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),rate=rate,inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),everyOriginalMemberVerified=review,allFourFiniteGatesPassed=result['allFourFiniteGatesPassed'],registeredPairedDirectionCriterionPassed=result['registeredPairedDirectionCriterionPassed'],nextPreregisteredRate=result['nextPreregisteredRate'],privateGitRestorationRequiredBeforeEscalation=True),indent=2,sort_keys=True)+chr(10));print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=review['originalFiles'])))
