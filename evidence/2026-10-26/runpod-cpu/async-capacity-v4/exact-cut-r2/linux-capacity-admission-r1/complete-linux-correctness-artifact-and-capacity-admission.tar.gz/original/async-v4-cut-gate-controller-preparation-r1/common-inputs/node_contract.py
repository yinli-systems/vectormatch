"""Exact child argv derived from the actual qualified class origins used by the Java launcher."""
from pathlib import PurePosixPath
CLASSES=('io.vectormatch.cluster.RetentionNodeMainV3','io.vectormatch.core.MatchingEngine','io.aeron.driver.MediaDriver','org.agrona.DirectBuffer')
def child_classpath(origins,lib):
 paths={row['class']:row['path']for row in origins};ordered=[]
 for name in CLASSES:
  path=paths[name]
  if str(PurePosixPath(path).parent)!=lib or not path.endswith('.jar'):raise ValueError('class origin outside the qualified runtime')
  if path not in ordered:ordered.append(path)
 return ':'.join(ordered)
def expected_node_arguments(java,classpath,member,state,registration,profile,fingerprint):
 if type(member)is not int or member not in(0,1,2):raise ValueError('exact cluster member0..2 required')
 if registration['profile']!=profile or registration['code']!=fingerprint:raise ValueError('native profile/artifact registration differs')
 return [java,'--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m','-Daeron.cluster.appointed.leader.id=0','-cp',classpath,'io.vectormatch.cluster.RetentionNodeMainV3',str(member),state,str(registration['ports']),'2','finite-batch-load-v3-v1',registration['lineage'],profile,fingerprint,'bounded-maintenance-v1']
