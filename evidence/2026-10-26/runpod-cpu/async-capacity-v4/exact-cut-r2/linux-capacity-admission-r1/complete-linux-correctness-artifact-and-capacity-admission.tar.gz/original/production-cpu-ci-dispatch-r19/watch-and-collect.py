from pathlib import Path
import subprocess,json
B=Path(__file__).resolve().parent.parent;O=Path(__file__).resolve().parent
with(O/'watch.stdout').open('xb')as out,(O/'watch.stderr').open('xb')as err:r=subprocess.run(['gh','run','watch','40242409944','--repo','yinli-systems/vectormatch','--exit-status','--interval','10'],stdout=out,stderr=err,timeout=1800)
(O/'WATCH_EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode)))
for relative,args in [('production-ci-evidence-collection-preparation-r16/collect.py',['19']),('async-v4-cut-gate-forced-correctness-preparation-r4/review.py',[])]:
 p=B/relative
 with(O/(p.name+'.stdout')).open('xb')as out,(O/(p.name+'.stderr')).open('xb')as err:q=subprocess.run(['python3',str(p),*args],stdout=out,stderr=err,timeout=300)
 print(relative,q.returncode,flush=True)
 if q.returncode:break
