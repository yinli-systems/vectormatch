from pathlib import Path
import tarfile,json,re,xml.etree.ElementTree as E,hashlib,datetime
B=Path(__file__).resolve().parent.parent;P=B/'production-ci-attempt-19-collection-r1';O=B/'async-v4-cut-gate-forced-correctness-r4';assert not O.exists()
body=(P/'github-complete-job.log').read_text();tasks={}
for line in body.splitlines():
    m=re.search(r'> Task (:[^ ]+:test)(?: (.*))?$',line)
    if m:tasks[m.group(1)]=m.group(2)or'EXECUTED'
assert set(tasks)=={':core:test',':cluster:test',':server:test',':projector:test',':bench:test'}and set(tasks.values())=={'EXECUTED'}
assert 'GRADLE_USER_HOME: /opt/vectormatch-cpu/ci/production-correctness-r19/runner/_work/_temp/gradle-user-home'in body
with tarfile.open(P/'complete-code-compiled-tests-and-public-logs.tar.gz')as t:
    names={x.name:x for x in t};summary=json.load(t.extractfile(names['original/ci-results/SUMMARY.json']))
    assert summary['totals']==dict(tests=442,failures=0,errors=0,skipped=0)
    assert summary['sourceCommit']=='0c8303b250c61653eb1a0827ce54a67eab83e2a3'
    script=t.extractfile(names['original/source/scripts/ci-existing-cpu.sh']).read()
    assert b'gradle --no-daemon --no-build-cache --rerun-tasks check'in script
    assert 'bash scripts/ci-existing-cpu.sh'in body
    logs={n:t.extractfile(names['original/ci-results/'+n]).read().decode()for n in ['python-tests.log','failover.log','web.log']}
    assert re.search(r'Ran 197 tests',logs['python-tests.log'])and '\nOK\n'in logs['python-tests.log']and'skipped='not in logs['python-tests.log']
    smoke=json.loads(next(x.split('VECTOR_FAILOVER_PASS ',1)[1]for x in logs['failover.log'].splitlines()if x.startswith('VECTOR_FAILOVER_PASS ')));assert smoke['passed']
    name=next(k for k in names if k.endswith('TEST-io.vectormatch.projector.PostgresProjectorIntegrationTest.xml'));x=E.parse(t.extractfile(names[name])).getroot()
    pg={k:int(x.get(k,'0'))for k in ['tests','failures','errors','skipped']};assert pg==dict(tests=11,failures=0,errors=0,skipped=0)
O.mkdir()
for n,text in logs.items():(O/n).write_text(text)
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),runId=40242409944,sourceCommit=summary['sourceCommit'],junit=summary['totals'],postgresIntegration=pg,
    pythonTests=197,pythonSkipped=0,actualTestTasks=tasks,allTestTasksExecutedWithoutResultCache=True,newGradleUserHomeVerified=True,
    executedScriptSha256=hashlib.sha256(script).hexdigest(),fullRawGithubLogSha256=hashlib.sha256(body.encode()).hexdigest(),freshCiFailover=smoke,
    webBuildAndFormatPassed=True,hostedAccountBillingBlockNotResolved=True,notPerformanceOrProductionCertification=True)
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
