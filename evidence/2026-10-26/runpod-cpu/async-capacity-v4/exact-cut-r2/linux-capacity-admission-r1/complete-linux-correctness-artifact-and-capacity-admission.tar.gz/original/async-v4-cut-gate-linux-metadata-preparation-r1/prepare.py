from pathlib import Path
import hashlib,shutil,subprocess,tarfile,json,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;I=P/'inputs';assert not I.exists();I.mkdir();(I/'lib').mkdir();(I/'classes').mkdir()
qualification=json.loads((B/'async-v4-cut-gate-forced-correctness-r4/RESULT.json').read_text());assert qualification['passed']and qualification['sourceCommit']=='0c8303b250c61653eb1a0827ce54a67eab83e2a3'and qualification['junit']==dict(tests=442,failures=0,errors=0,skipped=0)
assert json.loads((B/'async-v4-cut-gate-artifact-preparation-r1/JDK_IMAGE_EQUIVALENCE.json').read_text())['passed']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in (B/'async-v4-cut-gate-artifact-preparation-r1/lib').glob('*.jar'):shutil.copy2(p,I/'lib'/p.name)
shutil.copy2(P/'AsyncV4DistributionObservation.java',I/'AsyncV4DistributionObservation.java');names=['aeron-all-1.53.3.jar','agrona-2.6.1.jar','cluster-0.1.0-SNAPSHOT.jar','core-0.1.0-SNAPSHOT.jar'];cp=':'.join(str((I/'lib'/n).resolve())for n in names)
args=[str(R/'.tools/jdk/bin/javac'),'-cp',cp,'-d',str(I/'classes'),str(I/'AsyncV4DistributionObservation.java')];r=subprocess.run(args,capture_output=True,text=True);(P/'javac.stdout').write_text(r.stdout);(P/'javac.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
command=[str(R/'.tools/jdk/bin/java'),'-Xmx128m','--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','-cp',str((I/'classes').resolve())+':'+cp,'io.vectormatch.cluster.AsyncV4DistributionObservation',str((P/'local-observation.json').resolve())];r=subprocess.run(command,capture_output=True,text=True);(P/'local-java.stdout').write_text(r.stdout);(P/'local-java.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
rows={}
for p in sorted(I.rglob('*')):
 if p.is_file():p.chmod(0o644);rows[p.relative_to(I).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p),mode=420)
bundle=P/'inputs.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for n in rows:t.add(I/n,arcname=n,recursive=False)
c=json.loads((B/'batch-wire-validation-linux-metadata-preparation-r1/metadata-config.json').read_text());c.update(root='/opt/vectormatch-cpu/tools/cpu-async-cut-gate-v4-metadata-r1',rows=rows,bundleSha256=sha(bundle),jarOrder=names);(P/'metadata-config.json').write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
s=(B/'batch-wire-validation-linux-metadata-preparation-r1/remote_metadata.py').read_text().replace('cpu-batch-wire-validation-metadata-r1','cpu-async-cut-gate-v4-metadata-r1').replace('io.vectormatch.cluster.Read128CapacityDistributionObservation','io.vectormatch.cluster.AsyncV4DistributionObservation');(P/'remote_metadata.py').write_text(s)
local=json.loads((P/'local-observation.json').read_text());assert len(local['actualClassOrigins'])==19
(P/'PREPARATION.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=qualification['sourceCommit'],actualCodeFingerprint=local['actualCodeFingerprint'],javacArguments=args,javaArguments=command,inputFiles=len(rows),metadataOnly=True),indent=2)+'\n');print(json.dumps(dict(passed=True,codeFingerprint=local['actualCodeFingerprint'],inputs=len(rows))))
