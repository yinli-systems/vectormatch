import json,sys,pathlib,subprocess,os,hashlib,pwd,time
c=json.load(sys.stdin);token=c.pop('registrationToken');root=pathlib.Path(c['root']);runner=root/'runner'
assert root==pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r19')
assert json.loads((root/'PREPARED.json').read_text())['passed']
assert not (root/'REGISTERED.json').exists() and not (runner/'.runner').exists()
u=pwd.getpwnam('vmci');home=root/'home';cache=root/'toolcache';cache.mkdir();os.chown(cache,u.pw_uid,u.pw_gid)
python=root/'python/python/bin/python3'
env=['HOME='+str(home),'RUNNER_TOOL_CACHE='+str(cache),'AGENT_TOOLSDIRECTORY='+str(cache),'VM_CI_PYTHON='+str(python),
     'PATH='+str(root/'tools/git-2.56.0/bin')+':'+str(python.parent)+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin']
args=['runuser','-u','vmci','--','env',*env,'./config.sh','--unattended','--url','https://github.com/yinli-systems/vectormatch',
      '--token',token,'--name',c['runnerName'],'--labels',c['runnerLabel'],'--work','_work','--ephemeral']
r=subprocess.run(args,cwd=runner,capture_output=True,text=True,timeout=90)
(root/'config.stdout').write_text(r.stdout.replace(token,'[REDACTED]'));(root/'config.stderr').write_text(r.stderr.replace(token,'[REDACTED]'))
assert r.returncode==0,'Runner configuration failed; inspect redacted local configuration logs'
assert (runner/'.runner').exists()
with (root/'listener.log').open('xb')as out:
    p=subprocess.Popen(['runuser','-u','vmci','--','env',*env,'./run.sh','--once'],cwd=runner,
                       stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
proc=pathlib.Path('/proc')/str(p.pid);raw=(proc/'stat').read_text();fields=raw[raw.rfind(')')+2:].split();argv=(proc/'cmdline').read_bytes()
record=dict(passed=True,runnerName=c['runnerName'],runnerLabel=c['runnerLabel'],oneJobOnly=True,pid=p.pid,startTicks=int(fields[19]),commandSha256=hashlib.sha256(argv).hexdigest(),registrationTokenRetained=False)
(root/'REGISTERED.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
