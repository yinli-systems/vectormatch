from pathlib import Path
import importlib.util,json,shlex,hashlib,datetime
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent
assert json.loads((B/'async-v4-cut-gate-forced-correctness-r4/RESULT.json').read_text())['passed']
source=(P/'verify_jdk_remote.py').read_text();assert not(P/'JDK_IMAGE_EQUIVALENCE.json').exists()
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
(P/'JDK_VERIFY_REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),readOnlyNoJava=True)))
r=m.run(shlex.join(['python3','-B','-c',source]),timeout=90);(P/'jdk-verify.stdout').write_text(r.stdout);(P/'jdk-verify.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
x=json.loads(r.stdout);assert x['passed']and x['files']==[454,454]and x['allActualCiAndBenchmarkImageFileBytesEqual'];(P/'JDK_IMAGE_EQUIVALENCE.json').write_text(json.dumps(x,indent=2,sort_keys=True)+chr(10));print(json.dumps(dict(passed=True,actualImageBodiesMatched=454)))
