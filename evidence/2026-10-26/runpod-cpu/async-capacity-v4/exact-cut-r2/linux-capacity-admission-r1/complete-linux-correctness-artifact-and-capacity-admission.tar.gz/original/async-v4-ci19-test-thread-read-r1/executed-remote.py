from pathlib import Path
import subprocess,hashlib,json,os
pid=161620;p=Path('/proc')/str(pid);raw=(p/'cmdline').read_bytes();stat=(p/'stat').read_text();assert b'GradleWorkerMain'in raw and b'java'in raw
assert b'/production-correctness-r19/'in raw
r=subprocess.run(['/opt/vectormatch-cpu/tools/jdk-21.0.13+9/bin/jcmd',str(pid),'Thread.print'],capture_output=True,text=True,timeout=20)
after=(p/'stat').read_text();assert stat[stat.rfind(')')+2:].split()[19]==after[after.rfind(')')+2:].split()[19]
print(json.dumps(dict(pid=pid,commandSha256=hashlib.sha256(raw).hexdigest(),exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr)))
