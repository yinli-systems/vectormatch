from pathlib import Path
import base64,json,sys,hashlib,subprocess,socket
c=json.load(sys.stdin);assert socket.gethostname()=='33ace3d92505'
root=Path('/opt/vectormatch-cpu/tools/cpu-async-cut-gate-v4-controller-qualification-r1');assert not root.exists();root.mkdir(mode=0o700)
for name,encoded in c.items():
 body=base64.b64decode(encoded)
 if name.endswith('.py'):compile(body,name,'exec')
 dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
r=subprocess.run([sys.executable,'-B',str(root/'test_node_contract.py')],capture_output=True,text=True,timeout=30)
(root/'stdout').write_text(r.stdout);(root/'stderr').write_text(r.stderr)
assert r.returncode==0 and 'Ran 9 tests'in r.stderr and chr(10)+'OK'+chr(10)in r.stderr and 'skipped'not in r.stderr
result=dict(passed=True,python=sys.version,syntaxCompiledFiles=sum(n.endswith('.py')for n in c),inputBodies={n:dict(bytes=len(base64.b64decode(v)),sha256=hashlib.sha256(base64.b64decode(v)).hexdigest())for n,v in c.items()},remoteNodeContractTests=9,skipped=0,noJavaBusinessOrBenchmarkStarted=True,stdout=r.stdout,stderr=r.stderr)
(root/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
