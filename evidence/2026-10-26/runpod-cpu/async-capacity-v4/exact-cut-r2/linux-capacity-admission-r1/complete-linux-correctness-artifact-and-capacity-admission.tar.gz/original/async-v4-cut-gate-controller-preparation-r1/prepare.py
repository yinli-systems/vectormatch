from pathlib import Path
import json,shutil,hashlib,datetime,importlib.util
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;I=P/'common-inputs';assert not I.exists();I.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ci=json.loads((B/'async-v4-cut-gate-forced-correctness-r4/RESULT.json').read_text());assert ci['passed']and ci['junit']==dict(tests=442,failures=0,errors=0,skipped=0)
meta=json.loads((B/'async-v4-cut-gate-linux-metadata-execution-r1/ROOT_REVIEW.json').read_text());assert meta['passed']and meta['allNineteenActualLoadedOriginsMatchStagedJars']
observation=json.loads((B/'async-v4-cut-gate-linux-metadata-execution-r1/actual-linux-observation.json').read_text());image=json.loads((B/'async-v4-cut-gate-artifact-preparation-r1/JDK_IMAGE_EQUIVALENCE.json').read_text());assert image['passed']and image['files']==[454,454]
for name in ['owned_linux_base_8eeb.py','owned_process_identity.py']:shutil.copy2(B/'process-identity-exit-wait-controller-bridge-preparation-r1/inputs'/name,I/name)
assert sha(I/'owned_process_identity.py')=='51ad33fc51a92cdb9041e78093d39e38a42191a9ec50ad9635fd7cc314ba7a1a'
for name in ['controller.py','node_contract.py','test_node_contract.py']:shutil.copy2(P/name,I/name)
shutil.copytree(P/'node-contract-fixtures',I/'node-contract-fixtures')
shutil.copy2(R/'runtime/cloud/cpu-20261024/async-maintenance-v4-worktree/scripts/audit-async-capacity-v4.py',I/'audit-async-capacity-v4.py')
shutil.copy2(B/'async-v4-cut-gate-analysis-preparation-r1/analyze.py',I/'analyze.py')
m=json.loads((B/'async-v4-cut-gate-linux-metadata-preparation-r1/metadata-config.json').read_text())
spec=importlib.util.spec_from_file_location('node_contract',P/'node_contract.py');contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
common=dict(sourceCommit=ci['sourceCommit'],artifactFingerprint=observation['actualCodeFingerprint'],profileFingerprint=observation['profileSha256'],baseline=m['baseline'],java=m['java'],javaSha256=m['javaSha256'],releaseSha256=m['releaseSha256'],lib='/opt/vectormatch-cpu/tools/cpu-async-cut-gate-v4-metadata-r1/lib',jarOrder=m['jarOrder'],jars={n[4:]:v for n,v in m['rows'].items()if n.startswith('lib/')},qualifiedBaseSha256=sha(I/'owned_linux_base_8eeb.py'),nodeContractSha256=sha(I/'node_contract.py'),oneAttemptOnly=True)
common['nodeClassPath']=contract.child_classpath(observation['actualClassOrigins'],common['lib']);assert len(common['nodeClassPath'].split(':'))==3
plans={p['arrivals']//20:p for p in observation['capacityPlans']};arms=[]
for rate in [500,1000,2000,4000,6000]:
 for arm in ['c1','d1','c2','d2']:
  path=P/('point-'+str(rate)+'-'+arm);path.mkdir();inputs=path/'inputs';shutil.copytree(I,inputs)
  c=dict(common,root='/opt/vectormatch-cpu/experiments/async-v4-cut-gate-'+str(rate)+'-'+arm+'-r1',rate=rate,arm=arm,policy='PAUSE'if arm.startswith('c')else'CONTINUE',plan=plans[rate]);(inputs/'config.json').write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
  rows={p.relative_to(inputs).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(inputs.rglob('*'))if p.is_file()}
  freeze=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=rows,sourceCommit=ci['sourceCommit'],artifactFingerprint=c['artifactFingerprint'],qualifiedCi=ci['runId'],rate=rate,arm=arm,policy=c['policy'],originalIdentityAndPidfdSourceBodiesReused=True)
  (path/'SOURCE_FREEZE.json').write_text(json.dumps(freeze,indent=2,sort_keys=True)+'\n');arms.append(dict(rate=rate,arm=arm,root=c['root'],freezeSha256=sha(path/'SOURCE_FREEZE.json')))
(P/'CAMPAIGN.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=ci['sourceCommit'],artifactFingerprint=common['artifactFingerprint'],rates=[500,1000,2000,4000,6000],order=['c1','d1','c2','d2'],points=arms,serialOnly=True,noCiOverlap=True,upwardEscalationRequiresPriorFullReview=True,firstFiniteGateFailureStopsEscalation=True,protocol='docs/EXACT_CUT_CAPACITY_PROTOCOL_V4.md',noCloudBenchmarkExecutedYet=True),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,registeredPoints=len(arms),fingerprint=common['artifactFingerprint'])))
