package io.vectormatch.cluster;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;
import io.vectormatch.core.MatchingEngine;
import io.vectormatch.core.RetentionEngineV3;
public final class AsyncV4DistributionObservation {
 public static void main(String[] args)throws Exception{
  var out=new LinkedHashMap<String,Object>();out.put("noDriverOrClusterStarted",true);out.put("performanceEvidence",false);
  out.put("sourceCommit","0c8303b250c61653eb1a0827ce54a67eab83e2a3");out.put("actualCodeFingerprint",RetentionNodeMainV3.codeFingerprint());
  var p=RetentionBatchProfilesV3.finiteLoadProfile();out.put("profileSha256",p.fingerprint());out.put("osName",System.getProperty("os.name"));out.put("javaRuntimeVersion",System.getProperty("java.runtime.version"));
  out.put("profileBounds",Map.of("historyCommands",p.core().maxPendingCommands(),"historyEvents",p.core().maxPendingEvents(),"historyBytes",p.core().maxPendingSerializedBytes(),"eventsPerCommand",p.core().maxEventsPerCommand(),"outboxEvents",p.outboxCapacity(),"journalRecords",p.maxMaintenanceJournalRecords(),"journalBytes",p.maxMaintenanceJournalBytes()));
  var unit=RetentionEngineV3.reservationBound(p.core(),RetentionEngineV3.place(2,"load-w1",2,MatchingEngine.Side.BUY,10,1,MatchingEngine.TimeInForce.IOC));
  var maker=RetentionEngineV3.reservationBound(p.core(),RetentionEngineV3.place(1,"maker",2,MatchingEngine.Side.SELL,10,1000,MatchingEngine.TimeInForce.GTC));
  out.put("reservationExamples",Map.of("unitEvents",unit.events(),"unitHistoryBytes",unit.historyBytes(),"makerEvents",maker.events(),"makerHistoryBytes",maker.historyBytes()));
  out.put("phases",Arrays.stream(RetentionAsyncMaintenanceV4.Phase.values()).map(Enum::name).toList());
  var plans=new ArrayList<Object>();for(int rate:new int[]{500,1000,2000,4000,6000}){var plan=RetentionCapacityPlanV4.plan(new RetentionCapacityPlanV4.Config(rate,true),p);plan.requireAdmitted();if(!plan.equals(RetentionCapacityPlanV4.plan(new RetentionCapacityPlanV4.Config(rate,false),p)))throw new IllegalStateException("policy budget differs");plans.add(plan.observation());}out.put("capacityPlans",plans);
  var gate=new RetentionCapacityCutGateV4();out.put("cutGateBoundary",List.of(gate.observe(1535,0,1,false).name(),gate.observe(1535,0,0,false).name(),gate.observe(1536,0,0,false).name(),Long.toString(gate.through())));
  var ports=RetentionLoopbackPortsV4.hostRange();out.put("serverEndpointPlan",Map.of("base",22000,"ephemeralFirst",ports.first(),"ephemeralLast",ports.last(),"allFifteenOutsideEphemeralRange",RetentionLoopbackPortsV4.allowed(22000,ports)));
  var origins=new ArrayList<Object>();for(Class<?> type:List.of(RetentionLoopbackPortsV4.class,RetentionCapacityCutGateV4.class,RetentionCapacityAeronV4.class,RetentionCapacityExperimentV4.class,RetentionCapacityPlanV4.class,RetentionCapacityDiskGuardV4.class,RetentionCapacityLedgerV4.class,RetentionAsyncMaintenanceV4.class,RetentionAsyncAeronSmokeV4.class,RetentionPrefixPersistenceV4.class,RetentionArchivePreparationV4.class,RetentionDurableWriterV3.class,RetentionBatchOwnerV3.class,RetentionBatchAeronTransportV3.class,RetentionNodeMainV3.class,RetentionEngineV3.class,MatchingEngine.class,io.aeron.driver.MediaDriver.class,org.agrona.DirectBuffer.class)){
   Path jar=Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI());byte[] bytes=Files.readAllBytes(jar);origins.add(Map.of("class",type.getName(),"path",jar.toString(),"bytes",bytes.length,"sha256",HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes))));
  }out.put("actualClassOrigins",origins);RetentionCapacityJsonV3.writeNew(Path.of(args[0]),out);
 }
}
