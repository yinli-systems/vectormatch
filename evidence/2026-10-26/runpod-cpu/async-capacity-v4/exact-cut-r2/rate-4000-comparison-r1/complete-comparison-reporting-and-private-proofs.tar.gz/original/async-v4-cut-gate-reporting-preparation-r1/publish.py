from pathlib import Path
import sys,json,datetime,shutil,copy,re
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';rate=int(sys.argv[1]);O=B/('async-v4-cut-gate-'+str(rate)+'-reporting-r1');assert not O.exists()
comparison=B/('async-v4-cut-gate-'+str(rate)+'-comparison-r1');result=json.loads((comparison/'RESULT.json').read_text());assert result['passed']
path=W/'evidence/index.json';before=json.loads(path.read_text());index=copy.deepcopy(before);old_runs=copy.deepcopy(before['runs']);old_cohorts=copy.deepcopy(before['capacityCohorts']);old_capacity=copy.deepcopy(before['capacity']);report='docs/EXACT_CUT_CAPACITY_RESULTS_V4.md'
for arm in ['c1','d1','c2','d2']:
 c=B/('async-v4-cut-gate-'+str(rate)+'-'+arm+'-closure-r1');a=json.loads((c/'ANALYSIS.json').read_text());s=json.loads((c/'SOURCE_RESULT.json').read_text());audit=json.loads((c/'AUDIT.json').read_text());p=result['points'][arm];rid='cpu-exact-cut-v4-'+str(rate)+'-'+arm;assert not any(r['id']==rid for r in index['runs'])
 run=dict(id=rid,label='V4 '+p['policy']+' · '+str(rate)+'/s · '+arm.upper(),scope=str(p['accepted'])+' unique one-unit IOC trades from '+str(p['planned'])+' independent scheduled arrivals;20 seconds;fixed1536-command archive cuts',model='One prepaid CPU host;three real JVMs;loopback UDP;leader0;sync2;127 active load producers/128 allocated slots',commands=p['accepted'],trades=audit['uniqueOneUnitTrades'],throughput=p['goodput'],unknown=p['unknownFinal'],correctnessPassed=True,timestamp=s['scheduledOriginUTC'],durability='Sync2;forced/full-readback archive and event prefixes plus original control intents before ACK;all three snapshot/cold-restore hashes match',artifactPath='evidence/2026-10-26/runpod-cpu/async-capacity-v4/exact-cut-r2/rate-'+str(rate)+'-'+arm+'-native-r1/README.md',limitations=['Finite20-second fresh lineage;no sustained capacity,SLA,independent physical hosts/storage failure,100M continuity or funded external trading.','Statistics count load orders and exclude three setup commands.127 active producers;worker0 remains the bootstrap maker.','notSent='+str(p['notSent'])+';observed/final unknown='+str(p['unknownObserved'])+'/'+str(p['unknownFinal'])+';rejected='+str(p['rejected'])+'.','Shared compiled artifact '+result['commonConfiguration']['code']+';PAUSE/CONTINUE policy only. A conditional percentile cannot replace undefined global p99.'])
 if p['p99Ns']is not None:run.update(p50Millis=p['p50Ns']/1e6,p99Millis=p['p99Ns']/1e6)
 index['runs'].append(run)
 policy=p['policy'];cohort_id='cpu-exact-cut-v4-'+policy.lower();matches=[c for c in index['capacityCohorts']if c['id']==cohort_id]
 if not matches:
  cohort=dict(id=cohort_id,title='V4 file-work dispatch · '+policy,updatedAt=result['atUTC'],reportPath=report,configurationFingerprint=result['commonConfiguration']['code'],scope='Finite20-second points with two repeats per policy;three JVMs on one physical CPU;127 active producers,128 allocated slots/Q64,leader0,sync2,batch4,cut1536,read32/page32/chunk6144,ports22000. Same compiled artifact and fixed defaults;only business admission during original verification/file work differs. Each point uses a fresh lineage. No sustained capacity,SLA,100M or independent-host claim. Conditional p99 remains separate from all-offered accepted p99.',points=[]);index['capacityCohorts'].append(cohort)
 else:assert len(matches)==1;cohort=matches[0]
 assert cohort['configurationFingerprint']==result['commonConfiguration']['code']and not any(p['id']==rid for p in cohort['points'])
 point=dict(id=rid,rate=rate,workers=127,goodput=p['goodput'],p99Millis=a['latencyDistributionsConditionalOnAccepted']['scheduledToReply']['p99Ns']/1e6,clientNotSent=p['notSent'],rejected=p['rejected'],serverErrors=0,unknown=p['unknownObserved'],unresolved=p['unknownFinal'],drainSeconds=s['totalSourceDrainNs']/1e9,classification='FINITE_ASYNC_V4_POLICY_COMPARISON',peakBacklog=a['backlog']['maximumSampledQueued'],valid=p['schedulerTimingValid'],stable=False if p['notSent']>0 else None,windowSeconds=20)
 if p['p99Ns']is not None:point['allOfferedAcceptedP99Millis']=p['p99Ns']/1e6
 cohort['points'].append(point);cohort['updatedAt']=result['atUTC']
assert index['runs'][:len(old_runs)]==old_runs and index['capacity']==old_capacity
for prior in old_cohorts:
 current=next(c for c in index['capacityCohorts']if c['id']==prior['id'])
 if prior['id'].startswith('cpu-exact-cut-v4-'):
  assert current['points'][:len(prior['points'])]==prior['points'] and all(current[k]==v for k,v in prior.items()if k not in ('points','updatedAt'))
 else:assert current==prior
O.mkdir();(O/'index-before.json').write_text(json.dumps(before,indent=2,ensure_ascii=False)+chr(10));(O/'index-derived.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+chr(10))
doc=W/report
intro='# Exact-cut V4 asynchronous-maintenance finite capacity results\n\nApplication source0c8303b250c61653eb1a0827ce54a67eab83e2a3; the exact Linux artifact is recorded in every common-configuration and original-point manifest. Full Linux correctness,442 Java/197 Python tests including11 PostgreSQL integration tests, actual compiled-body and454-file JDK equivalence, nineteen loaded origins and corrected checker qualification precede the fresh campaign. Hosted billing remains unresolved; the workflow uses the existing prepaid CPU.\n\n[Prospective protocol](EXACT_CUT_CAPACITY_PROTOCOL_V4.md) fixes rates, policies, bounds and acceptance criteria. Every full raw point is a private-repository attachment with committed SHA and member inventory, authenticated re-download and complete verification. All previous79 runs and34 cohorts remain unchanged at the start of this campaign. Earlier artifact2ea38974 capacity and the disqualified1535-command cut are separate evidence; no old performance result transfers to this artifact.\n\n'
body=(comparison/'REPORT.md').read_text();heading='# V4 common-artifact comparison:'+str(rate)+'/s';body=body.replace(heading,'## '+str(rate)+' scheduled arrivals/s',1)
if not doc.exists():doc.write_text(intro+body)
else:
 assert '## '+str(rate)+' scheduled arrivals/s'not in doc.read_text()
 doc.write_text(doc.read_text()+2*chr(10)+body)
if 'EXACT_CUT_QUEUE_DIAGNOSTIC_V4.md'not in doc.read_text():doc.write_text(doc.read_text()+2*chr(10)+'[Read-only queue-wait diagnosis at500/s](EXACT_CUT_QUEUE_DIAGNOSTIC_V4.md) separates recorded phase overlap from a causal or higher-rate bottleneck claim.'+chr(10))
readme=W/'README.md';text=readme.read_text()
old="The old-artifact 1,000/s CONTINUE measurement is excluded after the independent checker exposed a 1,535-command first cut instead of 1,536. The [exact-cut correction](docs/CAPACITY_CUT_GATE_CORRECTION_V4.md) has passed 74 local source tests and 14 actual CPU checker tests; full Linux application regression and fresh comparisons remain pending. Earlier 500/s latency results do not qualify the new artifact."
new="The old-artifact 1,000/s CONTINUE measurement remains excluded for its 1,535-command first cut. The [exact-cut correction](docs/CAPACITY_CUT_GATE_CORRECTION_V4.md) now has a successful full Linux regression:442 Java and197 Python tests,including11 PostgreSQL integration tests,zero failure/error/skip. CI17's procfs-reader regression and CI18's disk refusals remain archived. The [fresh exact-cut capacity campaign](docs/EXACT_CUT_CAPACITY_RESULTS_V4.md) uses its own qualified artifact and cohorts;earlier latency results do not transfer."
if old in text:text=text.replace(old,new,1)
text=text.replace('| Linux correctness |435 Java tests and 197 Python tests; zero failure/error/skip; 11 real PostgreSQL tests included |Source `6716f74a`; existing one-job CPU runner; hosted billing still blocked |','| Linux correctness |442 Java tests and197 Python tests;zero failure/error/skip;11 real PostgreSQL tests included |Source `0c8303b2`;existing one-job CPU runner;hosted billing still blocked |')
text=text.replace('| V4 paired capacity at 500/s |','| Original-artifact V4 paired capacity at500/s |').replace('The new finite comparison uses one qualified artifact (`2ea38974`)','The original finite comparison uses one qualified artifact (`2ea38974`)')
text=re.sub(r'The console contains \d+ runs and \d+ capacity cohorts;[^\n]*','The console contains '+str(len(index['runs']))+' runs and '+str(len(index['capacityCohorts']))+' capacity cohorts;all79 runs and34 cohorts present before the exact-cut campaign retain their original records. New exact-cut curves have separate configuration fingerprints.',text,count=1)
rows=[]
for arm in ['c1','d1','c2','d2']:
 point=result['points'][arm];latency='undefined'if point['p99Ns']is None else str(round(point['p99Ns']/1e6,3))+'ms'
 rows.append(arm.upper()+':'+str(point['accepted'])+'/'+str(point['planned'])+' accepted,p99 '+latency+',goodput '+str(point['goodput'])+'/s')
start='<!-- exact-cut-v4-status:start -->';end='<!-- exact-cut-v4-status:end -->'
status=start+2*chr(10)+'Latest exact-cut comparison:'+str(rate)+' scheduled arrivals/s,artifact `'+result['commonConfiguration']['code']+'`,source `0c8303b2`.'+2*chr(10)+'; '.join(rows)+'.'+2*chr(10)+'All four finite gates passed:'+str(result['allFourFiniteGatesPassed'])+'. Both preregistered pair directions passed:'+str(result['registeredPairedDirectionCriterionPassed'])+'. Both candidates meet10ms p99:'+str(result['tenMillisecondP99TargetMetForBothCandidates'])+'. These are two pairs of20-second fresh lineages on one physical host;no long-run SLA or default performance promotion. [Exact values and complete private raw references](docs/EXACT_CUT_CAPACITY_RESULTS_V4.md).'+2*chr(10)+end
if start in text:
 first=text.index(start);last=text.index(end,first)+len(end);text=text[:first]+status+text[last:]
else:text=text.replace('## Verified evidence',status+2*chr(10)+'## Verified evidence',1)
readme.write_text(text)

path.write_text(json.dumps(index,indent=2,ensure_ascii=False)+chr(10));shutil.copy2(doc,O/'PUBLISHED_REPORT.md')
(O/'RESULT.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),rate=rate,runs=len(index['runs']),capacityCohorts=len(index['capacityCohorts']),allPriorRunsAndOtherCohortsUnchanged=True,legacyCapacityObjectUnchanged=True,comparisonResult=result['registeredPairedDirectionCriterionPassed'],allFourFiniteGates=result['allFourFiniteGatesPassed'],nextPreregisteredRate=result['nextPreregisteredRate'],noDefaultPerformancePromotion=True),indent=2)+chr(10));print((O/'RESULT.json').read_text())
