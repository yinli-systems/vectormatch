from pathlib import Path
import subprocess,sys,json,datetime,hashlib
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';rate=int(sys.argv[1]);previous={500:None,1000:500,2000:1000,4000:2000,6000:4000}[rate]
if previous is None:
 prior=json.loads((B/'async-v4-cut-gate-linux-admission-private-proof-r1/PRIVATE_PUSH.json').read_text());assert prior['passed']and prior['private']and prior['qualifiedSource']=='0c8303b250c61653eb1a0827ce54a67eab83e2a3'
else:
 prior=json.loads((B/('async-v4-cut-gate-'+str(previous)+'-report-private-proof-r1')/'PRIVATE_PUSH.json').read_text());assert prior['passed']and prior['allFourFiniteGatesPassed']and prior['nextPreregisteredRate']==rate
O=B/('async-v4-cut-gate-'+str(rate)+'-rate-continuation-r1');assert not O.exists();O.mkdir();(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rate=rate,previousPrivateReportCommit=prior['commit'],arms=['c2','d2'],samePreviouslyFrozenPointInputs=True,priorC1AndD1NotRepeated=True,serialOnly=True,oneAttemptPerArm=True,noAutomaticNativeRetryOrResourceCreation=True),indent=2)+chr(10))
(O/'executed-rate-driver.py').write_bytes(Path(__file__).read_bytes())
step=0

def run(args):
 global step
 step+=1;path=O/('step-'+str(step).zfill(2)+'.log')
 with path.open('xb')as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=900)
 if r.returncode!=0:
  print(json.dumps(dict(passed=False,step=step,log=str(path),exitCode=r.returncode,tail=path.read_text()[-2000:])),flush=True)
  raise RuntimeError('Step failed;no automatic retry or next arm')
 return r

for arm in ['c2','d2']:
 if(O/'STOP_REQUESTED').exists():print('Requested stop observed before next native arm.',flush=True);break
 if arm!='c1':
  prev={'d1':'c1','c2':'d1','d2':'c2'}[arm];proof=json.loads((B/('async-v4-cut-gate-'+str(rate)+'-'+prev+'-private-proof-r1')/'PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']and proof['nextWithinRateArm']==arm
 for name in ['stage.py','launch.py']:run(['python3',str(B/'async-v4-cut-gate-controller-preparation-r1'/name),str(rate),arm])
 run(['python3',str(B/'async-v4-cut-gate-point-closure-preparation-r1/finish.py'),str(rate),arm])
 path=B/('async-v4-cut-gate-'+str(rate)+'-'+arm+'-closure-r1');v=json.loads((path/'VERIFIED.json').read_text());assert v['nativePassed']and v['independentAuditPassed']and v['analysisPassed']
 run(['python3',str(B/'async-v4-cut-gate-native-archive-preparation-r1/archive.py'),str(rate),arm])
 folder='evidence/2026-10-26/runpod-cpu/async-capacity-v4/exact-cut-r2/rate-'+str(rate)+'-'+arm+'-native-r1'
 for args in [['git','-C',str(W),'-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse',folder],['git','-C',str(W),'-c','gc.auto=0','-c','maintenance.auto=false','commit','-q','-m','Archive V4 '+str(rate)+'/s '+arm.upper()+' point with complete private raw evidence'],['python3',str(W/'scripts/check-new-git-blobs.py'),'--repo',str(W),'--base','HEAD^','--head','HEAD'],['git','-C',str(W),'-c','gc.auto=0','-c','maintenance.auto=false','push','-q']]:run(args)
 run(['python3',str(B/'async-v4-cut-gate-native-private-proof-preparation-r1/verify.py'),str(rate),arm])
 a=json.loads((path/'ANALYSIS.json').read_text());print(json.dumps(dict(arm=arm,rate=rate,completed=True,privateRawFullyVerified=True,finiteGate=a['finiteAcceptanceGate'],p99Ns=a['allArrivalAcceptedP99Ns'],postOfferP99Ns=a['latencyDistributionsConditionalOnAccepted']['firstPositiveOfferReturnToReply']['p99Ns'],goodput=a['arrivalWindowGoodputPerSecond'])),flush=True)
else:
 run(['python3',str(B/'async-v4-cut-gate-comparison-preparation-r1/compare.py'),str(rate)])
 result=json.loads((B/('async-v4-cut-gate-'+str(rate)+'-comparison-r1')/'RESULT.json').read_text());(O/'RESULT.json').write_text(json.dumps(dict(passed=True,allFourArmsClosed=True,allFourFiniteGatesPassed=result['allFourFiniteGatesPassed'],registeredPairedDirectionCriterionPassed=result['registeredPairedDirectionCriterionPassed'],nextRateNotStarted=True),indent=2)+chr(10));print(json.dumps(dict(comparisonReady=True,rate=rate,allFourFiniteGatesPassed=result['allFourFiniteGatesPassed'],pairedDirectionCriterion=result['registeredPairedDirectionCriterionPassed'])),flush=True)
