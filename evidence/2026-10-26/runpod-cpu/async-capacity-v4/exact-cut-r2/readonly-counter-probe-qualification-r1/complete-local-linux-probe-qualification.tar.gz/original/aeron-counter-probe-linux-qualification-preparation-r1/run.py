from pathlib import Path
import json,importlib.util,subprocess,shlex,hashlib,datetime,sys
P=Path(__file__).resolve().parent;B=P.parent;O=B/'aeron-counter-probe-linux-qualification-r1';assert not O.exists();O.mkdir();source=(P/'remote.py').read_text();config=json.loads((P/'CONFIG.json').read_text())
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),remoteSourceSha256=hashlib.sha256(source.encode()).hexdigest(),temporaryPinnedDriverSelfTestOnly=True,noBenchmarkOverlapOrBusiness=True),indent=2))
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);r=m.run(shlex.join(['python3','-B','-c',source]),input=json.dumps(config),timeout=150)
(O/'remote-manifest.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode)));assert r.returncode==0,r.stderr;x=json.loads(r.stdout);a=x['archive'];archive=O/'complete-counter-probe-qualification.tar.gz'
with archive.open('xb')as out,(O/'download.stderr').open('xb')as err:r=subprocess.run(m.sshargs()+[shlex.join(['cat',a['path']])],stdout=out,stderr=err,timeout=90)
assert r.returncode==0 and archive.stat().st_size==a['bytes']and hashlib.sha256(archive.read_bytes()).hexdigest()==a['sha256']
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import verify
review=verify(archive,x['sourceScopes']);assert review==x['everyOriginalMemberVerified'];(O/'VERIFIED.json').write_text(json.dumps(dict(passed=True,rootResult=x['rootResult'],everyOriginalMemberVerified=review,archive=a),indent=2));print(json.dumps(dict(passed=True,files=review['originalFiles'],archiveBytes=a['bytes'],strictOwnedProbeAbsent=True,osReadOnlyMappings=True,noClusterOrBusinessStarted=True)))
