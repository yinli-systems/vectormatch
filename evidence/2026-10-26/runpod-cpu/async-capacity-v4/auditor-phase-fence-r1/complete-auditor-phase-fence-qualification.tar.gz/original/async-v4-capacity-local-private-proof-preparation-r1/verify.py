from pathlib import Path
import sys,json,tarfile,subprocess,hashlib,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';A=W/'evidence/2026-10-26/runpod-cpu/async-capacity-v4/local-qualification-r1';O=B/'async-v4-capacity-local-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();assert head.startswith('6716f74a')and git('ls-remote','origin','refs/heads/codex/async-maintenance-capacity-v4').decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
closed=json.loads((A/'CLOSED.json').read_text());inv=json.loads((A/'INVENTORY.json').read_text());actual=tree(A);assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')and set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']}and git('hash-object','--',*[str(W/n)for n in paths]).decode().splitlines()==[blobs[n]for n in paths]
O.mkdir();archive=O/'actual-git.tar.gz'
with archive.open('xb')as f:subprocess.run(['git','-C',str(W),'cat-file','blob',head+':'+prefix+'/complete-local-qualification-and-main-linux-ci.tar.gz'],stdout=f,check=True)
assert archive.stat().st_size==closed['archiveBytes']and sha(archive)==closed['archiveSha256'];review=verify(archive,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert review==closed['everyOriginalMemberVerified']
with tarfile.open(archive)as t:
 reg=json.load(t.extractfile('original/async-v4-capacity-complete-local-tests-r2/REGISTRATION.json'))
 for name,pin in reg['allCoreAndClusterSourcePins'].items():assert hashlib.sha256(git('show',head+':'+name)).hexdigest()==pin
 assert git('show',head+':scripts/audit-async-capacity-v4.py')==t.extractfile('original/async-v4-capacity-independent-audit-preparation-r1/audit.py').read()
 stem='original/production-ci-attempt-14-collection-r1/';manifest=json.load(t.extractfile(stem+'remote-manifest.json'));nested=O/'actual-main-ci.tar.gz';nested.write_bytes(t.extractfile(stem+'complete-code-compiled-tests-and-public-logs.tar.gz').read())
 assert nested.stat().st_size==manifest['archive']['bytes']and sha(nested)==manifest['archive']['sha256']
 native=json.load(t.extractfile('original/async-v4-capacity-local-native-r1/completion.json'));assert native['passed']and native['allOwnedStopped']
assert git('show',head+':docs/ASYNC_CAPACITY_PROTOCOL_V4.md')==(A/'published/docs/ASYNC_CAPACITY_PROTOCOL_V4.md').read_bytes()
seen=set()
with tarfile.open(nested)as t:
 for item in t:
  assert item.isfile()and item.name.startswith('original/');name=item.name[9:];assert name not in seen and name in manifest['originalFiles'];seen.add(name);pin=manifest['originalFiles'][name]
  assert item.size==pin['bytes']and hashlib.sha256(t.extractfile(item).read()).hexdigest()==pin['sha256']and item.mode==pin['mode']and item.uid==pin['uid']and item.gid==pin['gid']
assert len(seen)==824 and seen==set(manifest['originalFiles'])
archive.unlink();nested.unlink()
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository='yinli-systems/vectormatch',branch='codex/async-maintenance-capacity-v4',commit=head,allGitMetadataBlobsVerified=len(paths),wholeActualGitTarRestored=True,everyOriginalMemberVerified=review,all824ActualMainCiMembersVerified=True,allRegisteredCoreAndClusterSourcesEqualActualGit=True,committedAuditorEqualsQualifiedBody=True,forcedLocalTests=71,localNativeTrades=10000,allSixIndependentAuditMutationsRejected=True,linuxCandidateQualificationAndCapacityStillPending=True,noCloudPerformanceClaim=True)
(O/'PRIVATE_PUSH.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
