from pathlib import Path
import subprocess,sys,json,struct,shutil,hashlib
P=Path(__file__).resolve().parent;B=P.parent;O=B/'async-v4-capacity-audit-negative-qualification-r2';assert not O.exists();O.mkdir()
prior=B/'async-v4-capacity-audit-negative-qualification-r1';cases=json.loads((prior/'RESULT.json').read_text())['cases'];results=[]
def run(state,name,expected):
 out=O/(name+'-audit');r=subprocess.run([sys.executable,str(P/'audit.py'),str(state),str(out)],capture_output=True,text=True,timeout=30);(out/'stdout').write_text(r.stdout);(out/'stderr').write_text(r.stderr);assert(r.returncode==0)==expected,(name,r.stderr);results.append(dict(name=name,expectedPass=expected,exitCode=r.returncode))
for case in cases:run(prior/case['name'],case['name'],case['expectedPass'])
state=O/'business-during-ack-drain';shutil.copytree(prior/'relocated-valid-original',state);path=state/'load/maintenance-v4.bin';body=path.read_bytes();pos=8;records=[]
while pos<len(body):
 kind,n,ns,length=struct.unpack_from('>iqqi',body,pos);pos+=24;records.append([kind,n,ns,body[pos:pos+length]]);pos+=length
phases=[(i,row,json.loads(row[3]))for i,row in enumerate(records)if row[0]==3 and 'from'in json.loads(row[3])];chosen=False
for k,(i,row,value)in enumerate(phases[:-1]):
 if value['to']!='FILE_WAIT':continue
 # The original validated run has accepted business inside this file-work interval.
 start=row[2];end=phases[k+1][1][2]
 import csv
 c=json.loads((state/'load/configuration.json').read_text());origin=c['scheduledOriginMonotonicNs']
 with(state/'load/arrivals.csv').open()as f:inside=any(r['status']=='APPLIED'and start<=origin+int(r['first_successful_offer_return_offset_ns'])<end for r in csv.DictReader(f))
 if not inside:continue
 value['to']='ACK_DRAIN';row[3]=json.dumps(value).encode();following=phases[k+1];v=following[2];v['from']='ACK_DRAIN';following[1][3]=json.dumps(v).encode();chosen=True;break
assert chosen
for row in records:
 if row[0]==5:
  value=json.loads(row[3]);value['path']=str((state/'load/writer'/Path(value['path']).name).resolve());value['receiptPath']=value['path']+'.verified.txt';row[3]=json.dumps(value).encode()
path.write_bytes(struct.pack('>Ii',0x564d5434,1)+b''.join(struct.pack('>iqqi',kind,n,ns,len(data))+data for kind,n,ns,data in records))
# This fixture must isolate the previously missing phase fence,not unrelated corruption.
old=B/'async-v4-capacity-independent-audit-preparation-r1/first-passed-audit.py';out=O/'old-auditor-accepts-ack-drain';r=subprocess.run([sys.executable,str(old),str(state),str(out)],capture_output=True,text=True,timeout=30);(out/'stdout').write_text(r.stdout);(out/'stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
run(state,'business-during-ack-drain',False)
result=dict(passed=True,tests=len(results),validOriginalPassed=True,allSevenIndependentCorruptionsRejected=True,newPhaseFixtureAcceptedByOldAuditorAndRejectedByNew=True,sourceSha256=hashlib.sha256((P/'audit.py').read_bytes()).hexdigest(),cases=results)
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
