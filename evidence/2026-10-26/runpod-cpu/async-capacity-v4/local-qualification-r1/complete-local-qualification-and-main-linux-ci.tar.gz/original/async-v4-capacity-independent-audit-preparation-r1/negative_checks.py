from pathlib import Path
import sys,subprocess,shutil,json,struct,hashlib,csv
P=Path(__file__).resolve().parent;B=P.parent;S=B/'async-v4-capacity-local-native-r1';O=B/'async-v4-capacity-audit-negative-qualification-r1';assert not O.exists();O.mkdir()
def read_records(path):
 body=path.read_bytes();assert body[:8]==struct.pack('>Ii',0x564d5434,1);pos=8;out=[]
 while pos<len(body):
  kind,n,ns,length=struct.unpack_from('>iqqi',body,pos);pos+=24;out.append([kind,n,ns,body[pos:pos+length]]);pos+=length
 assert pos==len(body);return out
def write_records(path,records):path.write_bytes(struct.pack('>Ii',0x564d5434,1)+b''.join(struct.pack('>iqqi',kind,n,ns,len(body))+body for kind,n,ns,body in records))
def fixture(name):
 state=O/name;state.mkdir()
 shutil.copy2(S/'registration.json',state/'registration.json');shutil.copytree(S/'load',state/'load');records=read_records(state/'load/maintenance-v4.bin')
 for row in records:
  if row[0]==5:
   value=json.loads(row[3]);value['path']=str((state/'load/writer'/Path(value['path']).name).resolve());value['receiptPath']=value['path']+'.verified.txt';row[3]=json.dumps(value,separators=(',',':')).encode()
 write_records(state/'load/maintenance-v4.bin',records);return state,records
def run(state,expected):
 output=O/(state.name+'-audit');args=[sys.executable,str(P/'audit.py'),str(state),str(output)];r=subprocess.run(args,capture_output=True,text=True,timeout=30)
 (output/'COMMAND.json').write_text(json.dumps(dict(arguments=args,expectedPass=expected,exitCode=r.returncode),indent=2)+'\n');(output/'stdout').write_text(r.stdout);(output/'stderr').write_text(r.stderr)
 assert (r.returncode==0)==expected,(state.name,r.stdout,r.stderr);return dict(name=state.name,expectedPass=expected,exitCode=r.returncode)
results=[];base,_=fixture('relocated-valid-original');results.append(run(base,True))
for field,changed in [('request_seq','999999'),('command_sha256','0'*64)]:
 state,records=fixture('forged-'+field);path=state/'load/arrivals.csv'
 with path.open()as f:rows=list(csv.DictReader(f));fields=list(rows[0])
 rows[0][field]=changed
 with path.open('w')as f:writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
 results.append(run(state,False))
state,records=fixture('forged-all-arrival-p99');path=state/'load/load-result.json';value=json.loads(path.read_text());value['allArrivalP99Ns']-=1;path.write_text(json.dumps(value));results.append(run(state,False))
state,records=fixture('reply-without-positive-admission');path=state/'load/physical-offer-codes.csv'
with path.open()as f:rows=list(csv.DictReader(f));fields=list(rows[0])
with(state/'load/arrivals.csv').open()as f:cid=next(csv.DictReader(f))['correlation_id']
assert any(row['correlation_id']==cid and int(row['return_code'])>=0 for row in rows)
for row in rows:
 if row['correlation_id']==cid:row['return_code']='-1'
with path.open('w')as f:writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
results.append(run(state,False))
state,records=fixture('unreleased-read-credit')
for row in records:
 if row[0]==4:
  value=json.loads(row[3])
  if value['readPhaseGeneration']is not None and value['consumed']:value['consumed']=False;row[3]=json.dumps(value).encode();break
write_records(state/'load/maintenance-v4.bin',records);results.append(run(state,False))
state,records=fixture('self-consistent-five-offer-intent');path=next((state/'load/writer').glob('*control-intent-v4.bin'));body=bytearray(path.read_bytes());struct.pack_into('>i',body,24,5);path.write_bytes(body);new_hash=hashlib.sha256(body).hexdigest();receipt=Path(str(path)+'.verified.txt');text=receipt.read_text();old_hash=next(line[7:]for line in text.splitlines()if line.startswith('sha256='));receipt.write_text(text.replace(old_hash,new_hash))
for row in records:
 if row[0]==5:
  value=json.loads(row[3])
  if value['path']==str(path.resolve()):value['sha256']=new_hash;row[3]=json.dumps(value).encode()
write_records(state/'load/maintenance-v4.bin',records);results.append(run(state,False))
(O/'RESULT.json').write_text(json.dumps(dict(passed=True,validRelocatedOriginalAccepted=True,allSixSemanticMutationsRejected=True,cases=results),indent=2)+'\n');print(json.dumps(dict(passed=True,cases=results)))
