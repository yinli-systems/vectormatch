from pathlib import Path
import subprocess,os,shutil,hashlib,json,datetime,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent.parent;R=B.parents[2];W=B/'async-maintenance-v4-worktree';O=B/'async-v4-capacity-complete-local-tests-r2';assert not O.exists();O.mkdir();(O/'inputs').mkdir()
classes=['RetentionBatchOwnerV3Test','RetentionReadBankV3Test','RetentionMaintenanceReservationV4Test','RetentionDurableWriterV3Test','RetentionArchivePreparationV4Test','RetentionPrefixPersistenceV4Test','RetentionAsyncMaintenanceV4Test','RetentionCapacityPlanV4Test','RetentionCapacityLedgerV4Test','RetentionCapacityDiskGuardV4Test','RetentionCapacityExperimentV4Test']
args=[str(W/'gradlew'),'--no-daemon','--no-build-cache','--rerun-tasks',':cluster:test']
for name in classes:args+=['--tests','io.vectormatch.cluster.'+name]
inputs={}
for module in ['core','cluster']:
 for folder in ['main','test']:
  for p in sorted((W/f'{module}/src/{folder}/java').rglob('*.java')):
   target=O/'inputs'/p.relative_to(W);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);inputs[p.relative_to(W).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),arguments=args,workingDirectory=str(W),allCoreAndClusterSourcePins=inputs,localMacOnly=True,noDeploymentOrPerformanceClaim=True),indent=2,sort_keys=True)+'\n')
env=os.environ.copy();env['JAVA_HOME']=str(R/'.tools/jdk');env['GRADLE_USER_HOME']=str(R/'.tools/gradle-user-home')
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:result=subprocess.run(args,cwd=W,env=env,stdout=out,stderr=err,timeout=180)
(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=result.returncode))+'\n')
shutil.copytree(W/'cluster/build/test-results/test',O/'junit')
for module in ['core','cluster']:shutil.copytree(W/f'{module}/build/classes',O/'compiled'/module)
totals=dict(tests=0,failures=0,errors=0,skipped=0);suites={}
for p in sorted((O/'junit').glob('TEST-*.xml')):
 x=E.parse(p).getroot();v={k:int(x.get(k,'0'))for k in totals};suites[x.get('name')]=v
 for k in totals:totals[k]+=v[k]
assert result.returncode==0 and set(suites)=={'io.vectormatch.cluster.'+n for n in classes}and totals==dict(tests=71,failures=0,errors=0,skipped=0),(result.returncode,totals)
for n,h in inputs.items():assert hashlib.sha256((W/n).read_bytes()).hexdigest()==h
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),junit=totals,suites=suites,allRegisteredSourceBodiesUnchanged=True,forcedLocalMacOnly=True,noNativeNetworkDeploymentOrPerformanceClaim=True)
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
