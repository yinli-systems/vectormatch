from pathlib import Path,PurePosixPath
import hashlib,tarfile,os,stat,json,shutil,time
base=Path('/opt/vectormatch-cpu/ci');out=base/'completed-python-cache-retirement-r1';assert not out.exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:argv=(p/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(argv[0])).name
 except(FileNotFoundError,ProcessLookupError):continue
 assert name not in('java','javaw','postgres','postmaster','Runner.Listener','Runner.Worker'),name
archive=base/'production-correctness-r1/python.tar.gz'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
assert archive.stat().st_size==67908973 and sha(archive)=='5ff9f0602ce964a529ed1e8555d3abab6341926d724402ba9a15e9e877191124'
expected={}
with tarfile.open(archive)as t:
 for member in t:
  name=PurePosixPath(member.name).as_posix();assert not PurePosixPath(name).is_absolute()and '..'not in PurePosixPath(name).parts
  if member.isdir():continue
  if member.isfile():expected[name]=dict(type='file',bytes=member.size,sha256=hashlib.sha256(t.extractfile(member).read()).hexdigest())
  elif member.issym():expected[name]=dict(type='symlink',target=member.linkname)
  else:raise AssertionError('Unexpected archive member kind')
assert len(expected)>100
selected=[]
for n in list(range(3,11))+list(range(12,19)):
 root=base/('production-correctness-r'+str(n));target=root/'python';assert not(root/'runner/.runner').exists()and not(root/'runner/.credentials').exists()
 assert target.is_dir()and not target.is_symlink();actual={};allocated=0;extra=[]
 for parent,dirs,files in os.walk(target,followlinks=False):
  for entry in list(dirs)+files:
   p=Path(parent)/entry;s=p.lstat();label=p.relative_to(target).as_posix()
   if stat.S_ISDIR(s.st_mode):continue
   if stat.S_ISLNK(s.st_mode):row=dict(type='symlink',target=os.readlink(p))
   else:assert stat.S_ISREG(s.st_mode);row=dict(type='file',bytes=s.st_size,sha256=sha(p));allocated+=s.st_blocks*512
   if label in expected:assert row==expected[label],label;actual[label]=row
   else:
    assert p.suffix=='.pyc'and p.parent.name=='__pycache__'and row['type']=='file',label
    origin=p.parent.parent/(p.name.split('.')[0]+'.py');assert origin.is_file(),label;extra.append(dict(path=label,pin=row,derivedFrom=str(origin.relative_to(target))))
 assert set(actual)==set(expected)
 selected.append(dict(attempt=n,path=str(target),allocatedBytes=allocated,allShippedMembersMatch=len(actual),onlyGeneratedPythonBytecodeExtras=extra))
protected={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in(base/'collections').glob('*/complete-code-compiled-tests-and-public-logs.tar.gz')};assert len(protected)==17
out.mkdir();before=dict(atUTC=time.time(),freeBytes=shutil.disk_usage(base).free,archiveSha256=sha(archive),shippedMemberPins=expected,selections=selected,all17OriginalCiCollections=protected,noWorktreeClassesJUnitLogsApplicationStateOrKeysSelected=True);(out/'BEFORE.json').write_text(json.dumps(before,indent=2,sort_keys=True)+chr(10))
for row in selected:
 target=Path(row['path']);assert target.name=='python'and target.parent.name=='production-correctness-r'+str(row['attempt'])and not target.is_symlink();shutil.rmtree(target)
for name,pin in protected.items():p=Path(name);assert p.stat().st_size==pin['bytes']and sha(p)==pin['sha256']
assert sha(archive)==before['archiveSha256']and(base/'production-correctness-r1/python/python/bin/python3').exists()
result=dict(passed=True,retiredDirectories=len(selected),retiredAllocatedBytes=sum(r['allocatedBytes']for r in selected),freeBefore=before['freeBytes'],freeAfter=shutil.disk_usage(base).free,allShippedMembersEqualRetainedPinnedArchive=True,all17OriginalCiCollectionsUnchanged=True,canonicalPythonAndPinnedArchiveRetained=True,noApplicationOrRawEvidenceDeleted=True,noDiskFloorLowered=True)
(out/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10));print(json.dumps(result))
