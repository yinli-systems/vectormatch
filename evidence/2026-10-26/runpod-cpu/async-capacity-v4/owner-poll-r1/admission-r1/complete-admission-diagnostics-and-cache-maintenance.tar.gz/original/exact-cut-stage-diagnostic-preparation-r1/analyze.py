from pathlib import Path
import json,sys,tarfile,hashlib,collections,csv,io,math,datetime
B=Path(__file__).resolve().parent.parent;O=B/'exact-cut-stage-diagnostic-r1';assert not O.exists();O.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def dist(v):
 if not v:return None
 v.sort();return dict(count=len(v),p50Ns=v[math.ceil(.5*len(v))-1],p99Ns=v[math.ceil(.99*len(v))-1],maxNs=v[-1],meanNs=sum(v)/len(v))
points={}
for rate in [500,1000,2000,4000,6000]:
 for arm in ['c1','d1','c2','d2']:
  root=B/f'async-v4-cut-gate-{rate}-{arm}-closure-r1';archive=root/'complete-native-point-and-independent-audit.tar.gz'
  manifest=json.loads((root/'remote-manifest.json').read_text());assert manifest['passed']and sha(archive)==manifest['archive']['sha256']
  proof=json.loads((B/f'async-v4-cut-gate-{rate}-{arm}-private-proof-r1/PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']and proof['assetSha256']==sha(archive)
  stages=collections.defaultdict(list);statuses=collections.Counter();codes=collections.Counter();fields=None
  selected={}
  with tarfile.open(archive,'r|gz')as tar:
   for member in tar:
    if not member.isfile():continue
    name=member.name
    if name in ['original/point/state/load/configuration.json','original/point/state/load/load-result.json']:
     selected[Path(name).name]=json.load(tar.extractfile(member))
    elif name=='original/point/state/load/arrivals.csv':
     for row in csv.DictReader(io.TextIOWrapper(tar.extractfile(member),encoding='ascii')):
      statuses[row['status']+':'+row['result_code']]+=1
      if row['status']!='APPLIED'or row['result_code']!='ACCEPTED':continue
      keys=['scheduled_offset_ns','arrival_offset_ns','dispatch_offset_ns','submit_offset_ns','first_wire_offer_call_offset_ns','first_successful_offer_return_offset_ns','reply_completion_offset_ns']
      values=[int(row[k])for k in keys];assert values==sorted(values)
      for label,a,b in [('scheduledToObservedArrival',0,1),('observedArrivalToDispatch',1,2),('dispatchToSubmit',2,3),('submitToFirstPhysicalCall',3,4),('firstPhysicalCallToPositiveReturn',4,5),('positiveReturnToReply',5,6),('scheduledToReply',0,6)]:stages[label].append(values[b]-values[a])
    elif name=='original/point/state/load/physical-offer-codes.csv':
     reader=csv.DictReader(io.TextIOWrapper(tar.extractfile(member),encoding='ascii'));fields=reader.fieldnames
     for row in reader:
      key=next(k for k in row if 'code'in k or k in ('result','return_value'));value=int(row[key]);codes[str(value)if value<=0 else 'positive']+=1
  assert selected['configuration.json']['actualCodeSha256']=='65c41d519ea78af9ba14d8b4a878adefc2cc388f6682f4ae6dea513351e40e69'
  summary=selected['load-result.json'];d={k:dist(v)for k,v in stages.items()};assert d['scheduledToReply']['count']==summary['confirmedAcceptedUniqueOrders']
  if summary['allArrivalP99Ns']is not None:assert d['scheduledToReply']['p99Ns']==summary['allArrivalP99Ns']
  original=json.loads((root/'ANALYSIS.json').read_text())
  points[f'{rate}-{arm}']=dict(rate=rate,arm=arm,accepted=d['scheduledToReply']['count'],planned=rate*20,globalP99Ns=summary['allArrivalP99Ns'],conditionalOnAccepted=d,statuses=dict(statuses),physicalOfferCodeCountsIncludingMaintenance=dict(codes),physicalOfferFields=fields,cpu=original['cpuInsideArrivalWindow'],archiveSha256=sha(archive),privateAssetId=proof['assetId'])
  print(json.dumps(dict(point=f'{rate}-{arm}',accepted=d['scheduledToReply']['count'],firstCallToPositiveP99Ns=d['firstPhysicalCallToPositiveReturn']['p99Ns'],postOfferP99Ns=d['positiveReturnToReply']['p99Ns'],codeCounts=dict(codes))),flush=True)
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=sha(Path(__file__)),points=points,scope='Read-only derivation from original timestamps. Stage percentiles are distinct distributions and cannot be subtracted or added. Missing originals keep global p99 undefined; stage percentiles at those points are conditional on accepted orders. Physical offer is local publication admission, not a remote network RTT. Post-offer includes replication, execution, reply transport and client observation. Offer-code counts include maintenance/control. Aggregate CPU cannot prove or exclude single-thread saturation.')
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
