from pathlib import Path
import json,hashlib,shutil,datetime
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent;W=B/'async-maintenance-v4-worktree'
old='async-v4-cut-gate';new='async-v4-owner-poll'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def transform(s):return s.replace(old,new).replace('codex/async-capacity-cut-gate-v4','codex/v4-owner-poll-abab').replace('async-capacity-v4/exact-cut-r2','async-capacity-v4/owner-poll-r1')
parents=['controller','point-closure','native-archive','native-private-proof']
for part in parents:
 source=B/(old+'-'+part+'-preparation-r1');target=B/(new+'-'+part+'-preparation-r1');assert not target.exists();target.mkdir()
 names={'controller':['stage.py','launch.py','node_contract.py','test_node_contract.py'],'point-closure':['finish.py','remote.py'],'native-archive':['archive.py'],'native-private-proof':['verify.py']}[part]
 for name in names:(target/name).write_text(transform((source/name).read_text()))
controller=(B/(old+'-controller-preparation-r1/controller.py')).read_text()
needle="C['policy']==('PAUSE'if C['arm'].startswith('c')else'CONTINUE')"
assert controller.count(needle)==1
controller=controller.replace(needle,"C['policy']=='CONTINUE' and C['rate']==4000 and C['ownerPollMaxParkNs']==(1000000 if C['arm'].startswith('c') else 100000)")
needle="'-Xmx768m','-cp'";assert controller.count(needle)==1
controller=controller.replace(needle,"'-Xmx768m','-Dvectormatch.retention.ownerPollMaxParkNs='+str(C['ownerPollMaxParkNs']),'-cp'")
needle="result=json.loads((ROOT/'state/capacity-correctness-result.json').read_text());"
assert controller.count(needle)==1
controller=controller.replace(needle,"summary=json.loads((ROOT/'state/load/load-result.json').read_text());require(summary['ownerPollSelection']['maximumParkNs']==C['ownerPollMaxParkNs'] and summary['ownerPollActual']['available'] and summary['ownerPollActual']['ownerPollMaxParkNs']==C['ownerPollMaxParkNs'],'actual constructed owner cap differs');\n "+needle)
target=B/(new+'-controller-preparation-r1');(target/'controller.py').write_text(transform(controller))
shutil.copytree(B/(old+'-controller-preparation-r1/node-contract-fixtures'),target/'node-contract-fixtures')
common_source=B/(old+'-controller-preparation-r1/point-4000-d1/inputs')
points=[]
for arm in ['c1','d1','c2','d2']:
 point=target/('point-4000-'+arm);point.mkdir();inputs=point/'inputs';shutil.copytree(common_source,inputs)
 for name in ['controller.py','node_contract.py','test_node_contract.py']:shutil.copy2(target/name,inputs/name)
 c=json.loads((inputs/'config.json').read_text());c.update(root='/opt/vectormatch-cpu/experiments/'+new+'-4000-'+arm+'-r1',arm=arm,policy='CONTINUE',ownerPollMaxParkNs=1000000 if arm.startswith('c')else 100000)
 write(inputs/'config.json',c)
 rows={p.relative_to(inputs).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(inputs.rglob('*'))if p.is_file()}
 freeze=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=rows,sourceCommit=c['sourceCommit'],artifactFingerprint=c['artifactFingerprint'],qualifiedCi=40242409944,rate=4000,arm=arm,policy='CONTINUE',ownerPollMaxParkNs=c['ownerPollMaxParkNs'],originalIdentityAndPidfdSourceBodiesReused=True)
 write(point/'SOURCE_FREEZE.json',freeze);points.append(dict(arm=arm,maximumParkNs=c['ownerPollMaxParkNs'],freezeSha256=sha(point/'SOURCE_FREEZE.json')))
 # Syntax validation and an exact one-property parent argv difference; child contract is unchanged.
 for path in inputs.rglob('*.py'):compile(path.read_bytes(),str(path),'exec')
assert sha(target/'node_contract.py')==sha(B/(old+'-controller-preparation-r1/node_contract.py'))
write(target/'CAMPAIGN.json',dict(passed=True,points=points,rate=4000,policy='CONTINUE',sameBackendArtifact=True,sourceCommit=c['sourceCommit'],artifactFingerprint=c['artifactFingerprint'],onlyFactor='actual owner requested poll park cap 1000000 versus 100000 ns',serialOnly=True,noNativeRunYet=True))
doc='''# V4 owner-poll A/B/A/B protocol

Registered before native execution. This is a new same-artifact experiment, separate from the completed coarse capacity curve. Both arms use CONTINUE file-work dispatch; C1/D1/C2/D2 differ only in the owner polling requested park cap: explicit 1,000,000 ns versus 100,000 ns. Backend source 0c8303b250c61653eb1a0827ce54a67eab83e2a3 and actual artifact 65c41d519ea78af9ba14d8b4a878adefc2cc388f6682f4ae6dea513351e40e69 are unchanged and already qualified by Linux CI19. Node argv and Aeron agent settings are unchanged. Requested sleep does not bound OS scheduling delay.

Fixed: 4,000 independently scheduled arrivals/s for 20 seconds, 80,000 original IOC orders, fresh lineage per arm, leader 0, sync 2, three actual UDP JVMs on one prepaid CPU host, node heap 256 MiB/parent 768 MiB, 127 active producers, Q64, batch4, exact1536-command cuts, read32/page32/chunk6144. Both original-process readiness gates and setup/warm-up, full physical tape, finite disk/raw/credit/deadline bounds, full canonical replay, receipt audit, three snapshots and three cold restores remain unchanged. No profiler/observer JVM is added. No new paid resources.

Run C1,D1,C2,D2 serially; archive and privately re-download/verify each full point before the next. A correctness, ownership, disk, identity, raw-audit or cleanup failure stops execution without native retry. A finite performance failure remains a reported result; all four arms at this one fixed rate may finish if the safety/correctness gates pass. No upward rate escalation.

Each finite gate requires all scheduled originals accepted, zero notSent/reject/duplicate/observed or final UNKNOWN, valid arrival timing, and at least99% of scheduled throughput confirmed inside the arrival window. A favorable paired direction requires both finite gates, global p99 reduction of at least10%, no higher post-offer p99 and no lower in-window goodput. Report every stage, queue high water and process CPU, and all negative results. Two pairs do not establish significance, long-run SLA, hard realtime, HFT approval or100M continuity. No default change follows automatically.

Verify explicit selection against the actual constructed owner's final snapshot in every native arm. The fixed child argv contract excludes the owner-only property. Full raw and controller/config freezes remain in the private evidence package. The earlier V3 owner-poll comparison had mixed directions and is not evidence for this V4 workload.
'''
(W/'docs/OWNER_POLL_PROTOCOL_V4.md').write_text(doc)
print(json.dumps(dict(passed=True,points=4,controllerSha256=sha(target/'controller.py'),unchangedChildContract=True)))
