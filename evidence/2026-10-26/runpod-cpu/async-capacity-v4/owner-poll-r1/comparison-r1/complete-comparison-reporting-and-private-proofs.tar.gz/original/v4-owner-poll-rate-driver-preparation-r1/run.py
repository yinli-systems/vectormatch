from pathlib import Path
import sys,json,datetime,subprocess,hashlib
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';O=B/'v4-owner-poll-rate-driver-r1';assert not O.exists();O.mkdir()
prior=json.loads((B/'async-v4-owner-poll-linux-admission-private-proof-r1/PRIVATE_PUSH.json').read_text());assert prior['passed']and prior['private']
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),privateAdmission=prior['commit'],rate=4000,allArmsContinue=True,arms=['c1','d1','c2','d2'],c1AlreadyLaunchedAndClosedExactlyOnce=True,noAutomaticNativeRetry=True,archiveHelperR2FixesOnlyInheritedPausePolicyAssertion=True),indent=2)+'\n');(O/'executed-rate-driver.py').write_bytes(Path(__file__).read_bytes())
step=0
def run(args):
 global step
 step+=1;p=O/f'step-{step:02}.log'
 with p.open('xb')as f:x=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 if x.returncode:raise RuntimeError(f'step {step} failed;no retry or next arm;'+p.read_text()[-2000:])
for arm in ['c1','d1','c2','d2']:
 if (O/'STOP_REQUESTED').exists():raise RuntimeError('Explicit stop before next arm')
 if arm!='c1':
  prev={'d1':'c1','c2':'d1','d2':'c2'}[arm];proof=json.loads((B/f'async-v4-owner-poll-4000-{prev}-private-proof-r1/PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']and proof['nextWithinRateArm']==arm
  for name in ['stage.py','launch.py']:run(['python3',str(B/'async-v4-owner-poll-controller-preparation-r1'/name),'4000',arm])
  run(['python3',str(B/'async-v4-owner-poll-point-closure-preparation-r1/finish.py'),'4000',arm])
 path=B/f'async-v4-owner-poll-4000-{arm}-closure-r1';v=json.loads((path/'VERIFIED.json').read_text());assert v['nativePassed']and v['independentAuditPassed']and v['analysisPassed']
 run(['python3',str(B/'async-v4-owner-poll-native-archive-preparation-r2/archive.py'),'4000',arm])
 folder=f'evidence/2026-10-26/runpod-cpu/async-capacity-v4/owner-poll-r1/rate-4000-{arm}-native-r1'
 for args in [['git','-C',str(W),'add','--sparse',folder],['git','-C',str(W),'-c','gc.auto=0','-c','maintenance.auto=false','commit','-q','-m',f'Archive V4 owner-poll {arm.upper()} with complete private raw evidence'],['python3',str(W/'scripts/check-new-git-blobs.py'),'--repo',str(W),'--base','HEAD^','--head','HEAD'],['git','-C',str(W),'-c','gc.auto=0','push','-q']]:run(args)
 run(['python3',str(B/'async-v4-owner-poll-native-private-proof-preparation-r1/verify.py'),'4000',arm])
 a=json.loads((path/'ANALYSIS.json').read_text());s=json.loads((path/'SOURCE_RESULT.json').read_text());assert s['ownerPollActual']['ownerPollMaxParkNs']==(1000000 if arm.startswith('c')else 100000)
 print(json.dumps(dict(completed=arm,privateRawFullyVerified=True,actualOwnerParkNs=s['ownerPollActual']['ownerPollMaxParkNs'],finiteGate=a['finiteAcceptanceGate'],globalP99Ns=a['allArrivalAcceptedP99Ns'],postOfferP99Ns=a['latencyDistributionsConditionalOnAccepted']['firstPositiveOfferReturnToReply']['p99Ns'],goodput=a['arrivalWindowGoodputPerSecond'])),flush=True)
(O/'RESULT.json').write_text(json.dumps(dict(passed=True,allFourRawPrivatelyVerified=True,noComparisonConclusionYet=True),indent=2)+'\n')
