package io.vectormatch.cluster;
import java.net.*;
public class ActualPortRangeProbe {public static void main(String[] a)throws Exception {
 var range=RetentionLoopbackPortsV4.hostRange();
 if(range.first()!=32768||range.last()!=60999)throw new AssertionError(range);
 try(var socket=new DatagramSocket(0,InetAddress.getByName("127.0.0.1"))){
  if(socket.getLocalPort()<range.first()||socket.getLocalPort()>range.last())throw new AssertionError("assigned port outside range");
  System.out.println("actualAssignedClientPort="+socket.getLocalPort());
 }
 RetentionLoopbackPortsV4.verifyFixed(22000);
 int available=RetentionLoopbackPortsV4.availableBase();
 if(!RetentionLoopbackPortsV4.allowed(available,range))throw new AssertionError("unsafe range");
 System.out.println("PASS range="+range+" fixedBase=22000 randomBase="+available+" all15Probed=true");
}}
