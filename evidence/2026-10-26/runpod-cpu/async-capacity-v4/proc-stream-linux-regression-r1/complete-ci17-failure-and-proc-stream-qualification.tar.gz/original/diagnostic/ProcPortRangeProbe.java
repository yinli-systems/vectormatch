import java.nio.file.*;import java.io.*;import java.util.*;
class ProcPortRangeProbe { public static void main(String[] args)throws Exception {
 var p=Path.of("/proc/sys/net/ipv4/ip_local_port_range");
 System.out.println("size="+Files.size(p));
 System.out.println("readString="+Arrays.toString(Files.readString(p).getBytes()));
 try(var in=Files.newInputStream(p)){System.out.println("stream="+Arrays.toString(in.readNBytes(129)));}
}}
