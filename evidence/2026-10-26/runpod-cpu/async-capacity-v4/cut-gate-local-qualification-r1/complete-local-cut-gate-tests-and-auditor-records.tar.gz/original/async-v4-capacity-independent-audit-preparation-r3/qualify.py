from pathlib import Path
import sys,subprocess,shutil,json,struct,hashlib,csv
P=Path(__file__).resolve().parent;S500=Path(sys.argv[1]).resolve();S1000=Path(sys.argv[2]).resolve();O=Path(sys.argv[3]).resolve();assert not O.exists();O.mkdir()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def records(path):
 data=path.read_bytes();assert data[:8]==struct.pack('>Ii',0x564d5434,1);out=[];pos=8
 while pos<len(data):
  kind,n,ns,size=struct.unpack_from('>iqqi',data,pos);pos+=24;out.append([kind,n,ns,data[pos:pos+size]]);pos+=size
 assert pos==len(data);return out
def save_records(path,rows):path.write_bytes(struct.pack('>Ii',0x564d5434,1)+b''.join(struct.pack('>iqqi',k,n,ns,len(body))+body for k,n,ns,body in rows))
def fixture(name,source):
 root=O/name;root.mkdir();shutil.copy2(source/'registration.json',root/'registration.json');shutil.copytree(source/'load',root/'load');rows=records(root/'load/maintenance-v4.bin')
 for row in rows:
  if row[0]==5:
   value=json.loads(row[3]);value['path']=str(root/'load/writer'/Path(value['path']).name);value['receiptPath']=value['path']+'.verified.txt';row[3]=json.dumps(value).encode()
 save_records(root/'load/maintenance-v4.bin',rows);return root,rows
def read_csv(path):
 with path.open()as f:rows=list(csv.DictReader(f));fields=list(rows[0])
 return fields,rows
def save_csv(path,fields,rows):
 with path.open('w')as f:writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
checks=[]
def run(root,name,expected,checker='audit.py'):
 out=O/name;r=subprocess.run([sys.executable,'-B',str(P/checker),str(root),str(out)],capture_output=True,text=True,timeout=90);(out/'stdout').write_text(r.stdout);(out/'stderr').write_text(r.stderr);assert(r.returncode==0)==expected,(name,r.stderr);checks.append(dict(name=name,checker=checker,expectedPass=expected,exitCode=r.returncode));return out
root,_=fixture('valid-500-original',S500);run(root,'valid-500-audit',True)
for field,value in [('request_seq','999999'),('command_sha256','0'*64)]:
 root,_=fixture('forged-'+field,S500);path=root/'load/arrivals.csv';fields,rows=read_csv(path);rows[0][field]=value;save_csv(path,fields,rows);run(root,field+'-audit',False)
root,_=fixture('forged-p99',S500);path=root/'load/load-result.json';value=json.loads(path.read_text());value['allArrivalP99Ns']-=1;path.write_text(json.dumps(value));run(root,'p99-audit',False)
root,_=fixture('reply-without-admission',S500);_,arrivals=read_csv(root/'load/arrivals.csv');cid=arrivals[0]['correlation_id'];path=root/'load/physical-offer-codes.csv';fields,rows=read_csv(path)
for row in rows:
 if row['correlation_id']==cid:row['return_code']='-1'
save_csv(path,fields,rows);run(root,'no-positive-admission-audit',False)
root,rows=fixture('unreleased-read-credit',S500)
for row in rows:
 if row[0]==4:
  value=json.loads(row[3])
  if value['readPhaseGeneration']is not None and value['consumed']:value['consumed']=False;row[3]=json.dumps(value).encode();break
save_records(root/'load/maintenance-v4.bin',rows);run(root,'read-credit-audit',False)
root,rows=fixture('five-offer-intent',S500);path=next((root/'load/writer').glob('*control-intent-v4.bin'));body=bytearray(path.read_bytes());struct.pack_into('>i',body,24,5);path.write_bytes(body);new=sha(path);receipt=Path(str(path)+'.verified.txt');text=receipt.read_text();old=next(line[7:]for line in text.splitlines()if line.startswith('sha256='));receipt.write_text(text.replace(old,new))
for row in rows:
 if row[0]==5:
  value=json.loads(row[3])
  if value['path']==str(path):value['sha256']=new;row[3]=json.dumps(value).encode()
save_records(root/'load/maintenance-v4.bin',rows);run(root,'five-offer-audit',False)
root,rows=fixture('new-admissions-in-forged-drain',S500);c=json.loads((root/'load/configuration.json').read_text());_,arrivals=read_csv(root/'load/arrivals.csv');phases=[(row,json.loads(row[3]))for row in rows if row[0]==3 and 'from'in json.loads(row[3])];changed=False
for i,(row,value)in enumerate(phases[:-1]):
 if value['to']!='FILE_WAIT':continue
 start=row[2];end=phases[i+1][0][2]
 if not any(r['submit_offset_ns']and start<=c['scheduledOriginMonotonicNs']+int(r['submit_offset_ns'])<end for r in arrivals):continue
 value['to']='ACK_DRAIN';row[3]=json.dumps(value).encode();following=phases[i+1];v=following[1];v['from']='ACK_DRAIN';following[0][3]=json.dumps(v).encode();changed=True;break
assert changed;save_records(root/'load/maintenance-v4.bin',rows);run(root,'forged-drain-audit',False)
root,_=fixture('valid-1000-drain-original',S1000);out=run(root,'native-1000-short-cut-rejected',False);assert 'fixed-cut-contract'in(out/'stderr').read_text();result=json.loads((out/'PHASE_CHECKPOINT.json').read_text());assert result['phaseChecksPassed']and result['priorOriginalPublicationsDuringDrain']
# The previous strict checker must reject this same valid drain,isolating the correction.
run(root,'previous-strict-rejects-valid-drain',False,'previous-strict-audit.py')
root,_=fixture('forged-new-admission-inside-real-drain',S1000);path=root/'load/arrivals.csv';fields,rows=read_csv(path);legitimate=result['priorOriginalPublicationsDuringDrain'][0];c=json.loads((root/'load/configuration.json').read_text());selected=[r for r in rows if r['correlation_id']==str(legitimate['correlationId'])];assert selected
for row in selected:row['submit_offset_ns']=str(legitimate['phaseStartedNs']+1-c['scheduledOriginMonotonicNs'])
save_csv(path,fields,rows);bad=run(root,'forged-real-drain-admission-audit',False);assert not(bad/'PHASE_CHECKPOINT.json').exists()
# The original permissive checker accepts this forged admission;the new rule rejects it.
run(root,'previous-permissive-accepts-forged-admission',True,'previous-permissive-audit.py')
root,phase_records=fixture('forged-new-admission-during-read',S500);path=root/'load/arrivals.csv';fields,rows=read_csv(path);c=json.loads((root/'load/configuration.json').read_text());phase_rows=[(row[2],json.loads(row[3]))for row in phase_records if row[0]==3 and 'from'in json.loads(row[3])];changed=False
for i,(start,value)in enumerate(phase_rows[:-1]):
 if value['to']!='EVENT_READ':continue
 end=phase_rows[i+1][0]
 for row in rows:
  arrival=c['scheduledOriginMonotonicNs']+int(row['arrival_offset_ns']);submit=c['scheduledOriginMonotonicNs']+int(row['submit_offset_ns']);fake=max(start+2,arrival+2)
  if fake>=end or submit<end:continue
  row['dispatch_offset_ns']=str(fake-1-c['scheduledOriginMonotonicNs']);row['submit_offset_ns']=str(fake-c['scheduledOriginMonotonicNs']);changed=True;break
 if changed:break
assert changed;save_csv(path,fields,rows);bad=run(root,'new-logical-admission-during-read-rejected',False);assert not(bad/'PHASE_CHECKPOINT.json').exists();run(root,'previous-permissive-accepts-read-phase-admission',True,'previous-permissive-audit.py')
result=dict(passed=True,checks=len(checks),semanticCases=11,valid500OriginalAccepted=True,allExpectedOutcomesVerified=True,legitimateNative1000DrainPassesPhaseChecks=True,native1000ShortFirstCutCorrectlyRejected=True,newLogicalAdmissionDuringDrainAndReadRefused=True,previousStrictFalsePositiveReproduced=True,previousPermissiveGapsReproduced=True,auditorSha256=sha(P/'audit.py'),cases=checks,scope='Read-only checker qualification using explicit relocated copies;no benchmark replay or business command issued')
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10));print(json.dumps(result))
