from pathlib import Path
import sys,json,base64,hashlib,subprocess,socket,os
c=json.load(sys.stdin);assert socket.gethostname()=='33ace3d92505';root=Path('/opt/vectormatch-cpu/tools/cpu-capacity-drain-audit-r3');assert not root.exists()
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:name=Path(os.fsdecode((proc/'cmdline').read_bytes().split(b'\0')[0])).name
 except(FileNotFoundError,ProcessLookupError):continue
 assert name not in('java','javaw','postgres','postmaster','Runner.Listener','Runner.Worker')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sources=[Path('/opt/vectormatch-cpu/experiments/async-v4-capacity-'+n+'-r1/state')for n in ['500-d1','1000-d1']];before={}
for source in sources:
 assert source.is_dir()and not source.is_symlink()
 for file in [source/'registration.json',*sorted((source/'load').rglob('*'))]:
  if file.is_file():assert not file.is_symlink();before[str(file)]=pin(file)
for n,body in c['files'].items():
 raw=base64.b64decode(body);assert len(raw)==c['pins'][n]['bytes']and hashlib.sha256(raw).hexdigest()==c['pins'][n]['sha256'];compile(raw,n,'exec')
root.mkdir(mode=0o700)
for n,body in c['files'].items():(root/n).write_bytes(base64.b64decode(body))
(root/'SOURCE_PINS.json').write_text(json.dumps(c['pins'],indent=2,sort_keys=True)+chr(10));(root/'ORIGINAL_INPUTS_BEFORE.json').write_text(json.dumps(before,indent=2,sort_keys=True)+chr(10))
with(root/'qualification.stdout').open('xb')as out,(root/'qualification.stderr').open('xb')as err:r=subprocess.run([sys.executable,'-B',str(root/'qualify.py'),str(sources[0]),str(sources[1]),str(root/'qualification')],stdout=out,stderr=err,timeout=180)
assert r.returncode==0,'semantic qualification failed;preserve original scope'
result=json.loads((root/'qualification/RESULT.json').read_text());assert result['passed']and result['checks']==14 and result['native1000ShortFirstCutCorrectlyRejected']and result['legitimateNative1000DrainPassesPhaseChecks']
assert all(pin(Path(n))==value for n,value in before.items());result=dict(passed=True,root=str(root),systemPython=sys.version,checks=14,semanticCases=11,originalSourceInputsUnchanged=True,sourcePins=c['pins'],noJavaOrBusinessCommandIssued=True,qualification=result)
(root/'LINUX_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10));print(json.dumps(result))
