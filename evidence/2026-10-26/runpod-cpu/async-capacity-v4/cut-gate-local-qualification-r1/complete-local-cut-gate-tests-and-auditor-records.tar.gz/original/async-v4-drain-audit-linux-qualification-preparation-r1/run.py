from pathlib import Path
import json,base64,hashlib,importlib.util,shlex,datetime
P=Path(__file__).resolve().parent;B=P.parent;S=B/'async-v4-capacity-independent-audit-preparation-r3';O=B/'async-v4-drain-audit-linux-qualification-r1';assert not O.exists();O.mkdir()
local=json.loads((B/'async-v4-capacity-drain-audit-local-qualification-r2/RESULT.json').read_text());assert local['passed']and local['checks']==14
files={n:base64.b64encode((S/n).read_bytes()).decode()for n in ['audit.py','qualify.py','previous-strict-audit.py','previous-permissive-audit.py']};pins={n:dict(bytes=len(base64.b64decode(v)),sha256=hashlib.sha256(base64.b64decode(v)).hexdigest())for n,v in files.items()}
script=r"""from pathlib import Path
import sys,json,base64,hashlib,subprocess,socket,os
c=json.load(sys.stdin);assert socket.gethostname()=='33ace3d92505';root=Path('/opt/vectormatch-cpu/tools/cpu-capacity-drain-audit-r3');assert not root.exists()
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:name=Path(os.fsdecode((proc/'cmdline').read_bytes().split(b'\0')[0])).name
 except(FileNotFoundError,ProcessLookupError):continue
 assert name not in('java','javaw','postgres','postmaster','Runner.Listener','Runner.Worker')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sources=[Path('/opt/vectormatch-cpu/experiments/async-v4-capacity-'+n+'-r1/state')for n in ['500-d1','1000-d1']];before={}
for source in sources:
 assert source.is_dir()and not source.is_symlink()
 for file in [source/'registration.json',*sorted((source/'load').rglob('*'))]:
  if file.is_file():assert not file.is_symlink();before[str(file)]=pin(file)
for n,body in c['files'].items():
 raw=base64.b64decode(body);assert len(raw)==c['pins'][n]['bytes']and hashlib.sha256(raw).hexdigest()==c['pins'][n]['sha256'];compile(raw,n,'exec')
root.mkdir(mode=0o700)
for n,body in c['files'].items():(root/n).write_bytes(base64.b64decode(body))
(root/'SOURCE_PINS.json').write_text(json.dumps(c['pins'],indent=2,sort_keys=True)+chr(10));(root/'ORIGINAL_INPUTS_BEFORE.json').write_text(json.dumps(before,indent=2,sort_keys=True)+chr(10))
with(root/'qualification.stdout').open('xb')as out,(root/'qualification.stderr').open('xb')as err:r=subprocess.run([sys.executable,'-B',str(root/'qualify.py'),str(sources[0]),str(sources[1]),str(root/'qualification')],stdout=out,stderr=err,timeout=180)
assert r.returncode==0,'semantic qualification failed;preserve original scope'
result=json.loads((root/'qualification/RESULT.json').read_text());assert result['passed']and result['checks']==14 and result['native1000ShortFirstCutCorrectlyRejected']and result['legitimateNative1000DrainPassesPhaseChecks']
assert all(pin(Path(n))==value for n,value in before.items());result=dict(passed=True,root=str(root),systemPython=sys.version,checks=14,semanticCases=11,originalSourceInputsUnchanged=True,sourcePins=c['pins'],noJavaOrBusinessCommandIssued=True,qualification=result)
(root/'LINUX_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10));print(json.dumps(result))
"""
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(script.encode()).hexdigest(),inputPins=pins,oneAttemptOnly=True,onlyReadOriginalNativeInputs=True),indent=2)+chr(10));(P/'executed-remote.py').write_text(script)
spec=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);r=m.run(shlex.join(['python3','-B','-c',script]),input=json.dumps(dict(files=files,pins=pins)),timeout=300);(O/'stdout.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode))+chr(10));assert r.returncode==0,r.stderr;assert json.loads(r.stdout)['passed'];print(r.stdout)
