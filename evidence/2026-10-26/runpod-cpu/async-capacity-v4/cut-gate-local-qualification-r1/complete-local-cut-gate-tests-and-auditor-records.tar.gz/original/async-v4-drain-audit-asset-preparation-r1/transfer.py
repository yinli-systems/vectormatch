from pathlib import Path
import sys,json,subprocess,os,shutil,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;C=B/'async-v4-drain-audit-linux-complete-collection-r1';T=B/'async-v4-drain-audit-linux-private-transfer-r1';assert not T.exists();T.mkdir()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import sha,verify
manifest=json.loads((C/'remote-manifest.json').read_text());verified=json.loads((C/'VERIFIED.json').read_text());assert verified['passed'];original=C/'complete-linux-drain-audit-qualification.tar.gz';assert sha(original)==verified['archiveSha256'];review=verify(original,manifest['sourceScopes']);assert review==manifest['everyOriginalMemberVerified']and review['originalFiles']==951
bundle=T/'async-v4-drain-audit-r3-linux-complete-qualification.tar.gz';shutil.copy2(original,bundle);repo='yinli-systems/vectormatch';tag='evidence-private-20261025'
def api(path):return json.loads(subprocess.check_output(['gh','api',path],env={**os.environ,'GODEBUG':'http2client=0'}))
assert api('repos/'+repo)['private'];release=api('repos/'+repo+'/releases/423510304');assert release['draft']and release['tag_name']==tag and not any(a['name']==bundle.name for a in release['assets'])
(T/'UPLOAD_REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),oneUploadOnly=True,bytes=bundle.stat().st_size,sha256=sha(bundle),all951OriginalFixtureAndResultFilesVerified=True),indent=2)+chr(10))
with(T/'upload.stdout').open('xb')as out,(T/'upload.stderr').open('xb')as err:r=subprocess.run(['gh','release','upload',tag,str(bundle),'--repo',repo],stdout=out,stderr=err,timeout=600)
assert r.returncode==0,'Inspect remote metadata;no blind retry';release=api('repos/'+repo+'/releases/423510304');assets=[a for a in release['assets']if a['name']==bundle.name];assert len(assets)==1;a=assets[0];assert a['state']=='uploaded'and a['size']==bundle.stat().st_size and a['digest']=='sha256:'+sha(bundle)
download=T/'authenticated-full-download.tar.gz'
with download.open('xb')as out,(T/'download.stderr').open('xb')as err:r=subprocess.run(['gh','api','repos/'+repo+'/releases/assets/'+str(a['id']),'-H','Accept: application/octet-stream'],stdout=out,stderr=err,timeout=600,env={**os.environ,'GODEBUG':'http2client=0'})
assert r.returncode==0 and download.stat().st_size==a['size']and sha(download)==sha(bundle);assert verify(download,manifest['sourceScopes'])==review;download.unlink()
result=dict(passed=True,private=True,draft=True,repository=repo,releaseId=423510304,releaseTag=tag,assetId=a['id'],assetName=a['name'],assetApiUrl=a['url'],bytes=a['size'],sha256=sha(bundle),serverDigest=a['digest'],completeAuthenticatedDownloadVerified=True,everyOriginalMemberVerified=review,actualSystemPythonChecks=14,semanticCases=11,noJavaOrBusinessCommandIssued=True)
(T/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10));print(json.dumps(result))
