from pathlib import Path
import importlib.util, json, hashlib, base64, shlex, datetime
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent
O=B/'production-cpu-ci-environment-r22';assert not O.exists();O.mkdir()
source=(P/'prepare_remote.py').read_text();config=json.loads((P/'CONFIG.json').read_text())
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),configSha256=hashlib.sha256((P/'CONFIG.json').read_bytes()).hexdigest(),oneAttemptOnly=True,noRunnerRegistrationOrWorkload=True),indent=2)+'\n')
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.run(shlex.join(['python3','-B','-c',source,base64.b64encode(json.dumps(config).encode()).decode()]),timeout=600)
(O/'stdout.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n');assert r.returncode==0,r.stderr
assert json.loads(r.stdout)['passed'];print(r.stdout)
