from pathlib import Path
import sys,json,subprocess,hashlib,datetime
B=Path(__file__).resolve().parent.parent;W=B/'interbank-v4-worktree';A=W/'evidence/2026-10-26/runpod-cpu/v4-latency-r1/linux-admission-r1';O=B/'v4-latency-linux-admission-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,sha
git=lambda *args:subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/v4-agent-idle-propagation').decode().split()[0]==head
repo='yinli-systems/vectormatch';api=lambda p:json.loads(subprocess.check_output(['gh','api',p]));assert api('repos/'+repo)['private']
c=json.loads((A/'CLOSED.json').read_text());inv=json.loads((A/'INVENTORY.json').read_text());actual=tree(A);assert c['passed']and c['inventorySha256']==sha(A/'INVENTORY.json')and set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix()
for name in actual['files']:assert hashlib.sha256(git('show',head+':'+prefix+'/'+name)).hexdigest()==sha(A/name)
asset=json.loads((A/'ASSET_MANIFEST.json').read_text());assert asset==json.loads((B/'v4-latency-linux-admission-r1/RESULT.json').read_text())and asset['passed']and asset['completeAuthenticatedDownloadVerified']and asset['allNineFrozenPointInputsVerified']
remote=api('repos/'+repo+'/releases/assets/'+str(asset['assetId']));assert remote['id']==c['assetId']and remote['size']==c['assetBytes']==asset['bytes']and remote['digest']=='sha256:'+c['assetSha256']and remote['state']=='uploaded'
campaign=json.loads((A/'CAMPAIGN.json').read_text());assert len(campaign['points'])==9
for point in campaign['points']:
 name=f"point-{point['factor']}-{point['rate']}-{point['arm']}";p=B/'v4-latency-controller-preparation-r1'/name;freeze=json.loads((p/'SOURCE_FREEZE.json').read_text());assert sha(p/'SOURCE_FREEZE.json')==point['freezeSha256']and freeze==json.loads((A/'frozen-points'/(name+'.json')).read_text())
 for n,pin in freeze['files'].items():assert (p/'inputs'/n).stat().st_size==pin['bytes']and sha(p/'inputs'/n)==pin['sha256']
O.mkdir();proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository=repo,commit=head,qualifiedSource=asset['sourceCommit'],artifactFingerprint=asset['artifactFingerprint'],allNineGitFrozenInputsAndAssetMembersVerified=True,completeAuthenticatedAssetDownloadPreviouslyVerified=True,assetId=asset['assetId'],assetBytes=asset['bytes'],assetSha256=asset['sha256'],qualifiedCi=40249048617,nativeNotYetStarted=True,noPerformanceOrDefaultPromotion=True)
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
