from pathlib import Path
import sys,json,datetime,hashlib
B=Path(__file__).resolve().parent.parent;factor=sys.argv[1];assert factor in ('agent-idle','read-bank');O=B/f'v4-latency-{factor}-comparison-r1';assert not O.exists()
points={};refs={};common=None;source_pins=None
for arm in ['c1','d1','c2','d2']:
 root=B/f'v4-latency-{factor}-4000-{arm}-closure-r1';a=json.loads((root/'ANALYSIS.json').read_text());s=json.loads((root/'SOURCE_RESULT.json').read_text());audit=json.loads((root/'AUDIT.json').read_text());v=json.loads((root/'VERIFIED.json').read_text());idle=json.loads((root/'ACTUAL_IDLE_PROOF.json').read_text());proof=json.loads((B/f'v4-latency-{factor}-4000-{arm}-private-proof-r1/PRIVATE_PUSH.json').read_text());point=B/'v4-latency-controller-preparation-r1'/f'point-{factor}-4000-{arm}';freeze=json.loads((point/'SOURCE_FREEZE.json').read_text());c=json.loads((point/'inputs/config.json').read_text())
 assert v['nativePassed']and v['independentAuditPassed']and v['analysisPassed']and idle['passed']and audit['passed']and proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']
 assert proof['factor']==c['factor']==factor and c['artifactFingerprint']==a['configuration']['code']=='dcfeeb81e4d837bf1290ee7fd1792dfbfdd36b708fd45da4fd088908a6473bfa'
 assert s['ownerPollActual']['ownerPollMaxParkNs']==1000000 and s['retentionIdleSelection']['maximumParkNs']==idle['configuredMaximumParkNs']==c['agentIdleMaxParkNs']
 assert s['readBankDispatchSelection']['policy']==c['readBankDispatch']and audit['readYieldEnabled']==(c['readBankDispatch']=='BOUNDED_TURN')
 if audit['readYieldEnabled']:assert audit['readYieldTurns']>0
 varied='agentIdleMaxParkNs'if factor=='agent-idle'else'readBankDispatch';normalized={k:v for k,v in c.items()if k not in ('root','arm',varied)}
 pins={n:p for n,p in freeze['files'].items()if n!='config.json'}
 if common is None:common=normalized;source_pins=pins
 assert common==normalized and source_pins==pins
 expected_cap=(1000000 if arm.startswith('c')else 100000)if factor=='agent-idle'else 100000
 expected_read='CLOSED'if factor=='agent-idle'or arm.startswith('c')else'BOUNDED_TURN'
 assert c['agentIdleMaxParkNs']==expected_cap and c['readBankDispatch']==expected_read
 finite=s['scheduledArrivals']==s['releasedArrivals']==s['confirmedAcceptedUniqueOrders']==80000 and all(s[k]==0 for k in ['notSent','unknownObserved','unknownFinal','serverRejected','duplicateOrOutOfRangeAcceptedOrderIds'])and s['schedulerTimingValid']and s['acceptedOrdersInArrivalWindow']*100>=80000*99
 assert finite==a['finiteAcceptanceGate']and a['allArrivalAcceptedP99Ns']==audit['allArrivalP99Ns']
 d=a['latencyDistributionsConditionalOnAccepted'];points[arm]=dict(accepted=s['confirmedAcceptedUniqueOrders'],planned=80000,inWindowAccepted=s['acceptedOrdersInArrivalWindow'],goodput=a['arrivalWindowGoodputPerSecond'],globalP99Ns=a['allArrivalAcceptedP99Ns'],acceptedConditionalP50Ns=d['scheduledToReply']['p50Ns'],postOfferP99Ns=d['firstPositiveOfferReturnToReply']['p99Ns'],finiteGate=finite,notSent=s['notSent'],unknownObserved=s['unknownObserved'],unknownFinal=s['unknownFinal'],rejected=s['serverRejected'],schedulerTimingValid=s['schedulerTimingValid'],actualAgentMaxParkNs=c['agentIdleMaxParkNs'],actualReadBankDispatch=c['readBankDispatch'],readYieldTurns=audit['readYieldTurns'],cpu=a['cpuInsideArrivalWindow'],backlog=a['backlog'],sourceSummarySha256=hashlib.sha256((root/'SOURCE_RESULT.json').read_bytes()).hexdigest())
 refs[arm]=proof
pairs=[]
for control,candidate in [('c1','d1'),('c2','d2')]:
 a,z=points[control],points[candidate];defined=a['globalP99Ns']is not None and z['globalP99Ns']is not None
 passed=defined and a['finiteGate']and z['finiteGate']and 10*z['globalP99Ns']<=9*a['globalP99Ns']and z['postOfferP99Ns']<=a['postOfferP99Ns']and z['inWindowAccepted']>=a['inWindowAccepted']
 pairs.append(dict(control=control,candidate=candidate,globalP99ChangeFraction=z['globalP99Ns']/a['globalP99Ns']-1 if defined else None,postOfferP99ChangeFraction=z['postOfferP99Ns']/a['postOfferP99Ns']-1,inWindowAcceptedDifference=z['inWindowAccepted']-a['inWindowAccepted'],registeredDirectionPassed=passed))
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),factor=factor,commonFrozenConfiguration=common,commonSourceFilePins=source_pins,points=points,pairs=pairs,allFourSafetyAndCorrectnessGatesPassed=True,allFourFiniteGatesPassed=all(p['finiteGate']for p in points.values()),registeredBothPairsPassed=all(p['registeredDirectionPassed']for p in pairs),bothCandidatesMeetTenMillisecondGlobalP99=all(points[a]['globalP99Ns']is not None and points[a]['globalP99Ns']<=10000000 for a in ['d1','d2']),defaultPromoted=False,scope='Two pairs of20-second fresh lineages,one physical host,one compiled artifact;no significance,endurance,SLA,hard-realtime,HFT,100M or funded external trading claim')
O.mkdir();(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');(O/'PRIVATE_POINT_REFERENCES.json').write_text(json.dumps(refs,indent=2,sort_keys=True)+'\n')
title='Agent requested park1ms versus100us,read-bank CLOSED'if factor=='agent-idle'else'Closed versus bounded inter-bank dispatch,agent100us fixed'
lines=['# '+title,'','All four safety/correctness gates passed. All finite gates passed: '+str(result['allFourFiniteGatesPassed'])+'. Both registered pair directions passed: '+str(result['registeredBothPairsPassed'])+'. Both candidates meet the10ms global p99 target: '+str(result['bothCandidatesMeetTenMillisecondGlobalP99'])+'. No default promotion.','','| Arm | Actual agent cap ns | Actual read-bank policy | Accepted/planned | In-window goodput/s | Global p99 ms | Post-offer p99 ms | Read-yield turns |','| --- | --- | --- | --- | --- | --- | --- | --- |']
for arm,p in points.items():
 latency='undefined'if p['globalP99Ns']is None else f"{p['globalP99Ns']/1e6:.3f}";lines.append(f"| {arm.upper()} | {p['actualAgentMaxParkNs']} | {p['actualReadBankDispatch']} | {p['accepted']}/{p['planned']} | {p['goodput']} | {latency} | {p['postOfferP99Ns']/1e6:.3f} | {p['readYieldTurns']} |")
lines+=['','Each finite arm retains all arrivals,physical publications/replies,trade/event prefixes,original permits,forced/readback receipts,three matching snapshots and actual cold restores. All six original/cold node processes and owner driver configured objects/factory consumptions are checked;these are not measured OS sleeps or private-agent-field readbacks. All recorded leader/term observations are0 and no client-observed leadership change occurs.','']
for p in pairs:lines.append(p['control'].upper()+'/'+p['candidate'].upper()+': '+json.dumps(p,sort_keys=True))
lines+=['','The criterion uses exact integer nanoseconds and in-window acceptance counts:both finite gates,at least10% lower global p99,no worse post-offer p99,and no lower in-window goodput. Conditional percentiles never replace undefined global p99. CPU is recorded separately per process over observed in-window samples;backlog sampling can miss short queues. Two repeats do not establish statistical significance or a sustained service level.','']
(O/'REPORT.md').write_text('\n'.join(lines));print(json.dumps({k:v for k,v in result.items()if k not in ['commonFrozenConfiguration','commonSourceFilePins','points']}))
