from pathlib import Path
import sys,json,subprocess,datetime,hashlib,tarfile
B=Path(__file__).resolve().parent.parent;W=B/'interbank-v4-worktree';factor=sys.argv[1];assert factor in ('agent-idle','read-bank');A=W/f'evidence/2026-10-26/runpod-cpu/v4-latency-r1/{factor}-comparison-r1';O=B/f'v4-latency-{factor}-comparison-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,sha,verify
git=lambda *args:subprocess.check_output(['git','-C',str(W),*args]);api=lambda p:json.loads(subprocess.check_output(['gh','api',p]));head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/v4-agent-idle-propagation').decode().split()[0]==head and api('repos/yinli-systems/vectormatch')['private']
c=json.loads((A/'CLOSED.json').read_text());inv=json.loads((A/'INVENTORY.json').read_text());actual=tree(A);assert c['passed']and c['factor']==factor and c['inventorySha256']==sha(A/'INVENTORY.json')and set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix()
for n in actual['files']:assert hashlib.sha256(git('show',head+':'+prefix+'/'+n)).hexdigest()==sha(A/n)
archive=A/'complete-comparison-reporting-and-private-proofs.tar.gz';assert archive.stat().st_size==c['archiveBytes']and sha(archive)==c['archiveSha256'];review=verify(archive,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert review==c['everyOriginalMemberVerified']
doc='V4_AGENT_IDLE_RESULTS.md'if factor=='agent-idle'else'INTERBANK_DISPATCH_RESULTS_V4.md'
for name,path in [('README.md','README.md'),('index.json','evidence/index.json'),(doc,'docs/'+doc)]:assert git('show',head+':'+path)==(A/'published'/name).read_bytes()
with tarfile.open(archive)as t:
 before=json.load(t.extractfile(f'original/v4-latency-{factor}-reporting-r1/index-before.json'));after=json.load(t.extractfile(f'original/v4-latency-{factor}-reporting-r1/index-derived.json'));assert after==json.loads(git('show',head+':evidence/index.json'))and after['runs'][:len(before['runs'])]==before['runs']and after['capacityCohorts'][:len(before['capacityCohorts'])]==before['capacityCohorts']and after['capacity']==before['capacity']
refs=json.loads((A/'PRIVATE_POINT_REFERENCES.json').read_text())
for arm,p in refs.items():
 assert p['passed']and p['completeAuthenticatedAssetDownloadVerified'];remote=api('repos/yinli-systems/vectormatch/releases/assets/'+str(p['assetId']));assert remote['state']=='uploaded'and remote['size']==p['assetBytes']and remote['digest']=='sha256:'+p['assetSha256']
 native=f'evidence/2026-10-26/runpod-cpu/v4-latency-r1/{factor}-4000-{arm}-native-r1/ASSET_MANIFEST.json';assert git('show',p['commit']+':'+native)==git('show',head+':'+native)
result=json.loads((A/'RESULT.json').read_text());assert result['passed']and result['allFourSafetyAndCorrectnessGatesPassed']and not result['defaultPromoted'];O.mkdir();proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,commit=head,factor=factor,allFourRawPrivatelyVerified=True,allFourSafetyAndCorrectnessGatesPassed=True,allFourRemoteAssetDigestsUnchanged=True,allActualGitPackageBytesVerified=True,everyOriginalScopeMemberVerified=review,allPreviousIndexRecordsUnchanged=True,runs=len(after['runs']),cohorts=len(after['capacityCohorts']),registeredBothPairsPassed=result['registeredBothPairsPassed'],allFourFiniteGatesPassed=result['allFourFiniteGatesPassed'],defaultPromoted=False)
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
