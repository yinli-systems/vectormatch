# Source-only fixed-page32 read-window8/32 ABAB controller

This preparation does not stage, launch or qualify a native run. Default controller execution is readonly preflight. A root-reviewed release3, explicit release SHA, actual metadata/source/parser proofs and sufficient disk/memory are required even for preflight; --start-new is a separate one-shot root action.

The exact605/d0 application artifact fixes page32, owner1ms, server/driver100us, LONG33792@500/s, cut3072, business batch4, archive chunk6144, leader0/term0/sync2 and existing finite profile. READ_WINDOW_ORDER=(8,32,8,32); configure_arm sets one dynamic WINDOWS entry. All node roles, prior-arm configuration paths, CLI arguments and observed selected fields use that arm's actual read window.

The actual Linux metadata observation has exactly two original Plan keys8/32, SHA b9217e7d2adc2e0f1fea742c32fc56ed46984881b2f5405839f23595263efa9f. Each entire row equals the corresponding page32-window8/32 row in the original four-plan local observation212a58. No Linux four-plan observation is fabricated. The exact strict parser freeze766ef61 is distinct from the outer collector source freeze that will be produced separately.

Both windows share raw182433396B/growth754102673B/staging1984256B/failure1073760B, logical5131/event2113/chunk2982/journal96+117792B. The initial free floor is max(2116076873, allocation+16MiBwrapper+256MiBarchive+1GiB), so the original floor never falls. Runtime1GiB,8GiB initial memory,4MiB logs,256MiB archive,8192 paths,12GiB logical files,240/360s execution/total and all old ownership/stop/retry/protected-state/egress rules remain. No automatic cleanup is enabled.

Per-arm admission is not a promise that all four retained-native arms fit. After only old87a-native retirement, historical projected free2583056384B leaves466979511B above the unchanged floor for all preceding arm allocations. A conservative four-launch bound retaining previous native requires at least4428716540B before additional staged-source/cumulative archive allocation. Every arm must recheck actual free space and fail closed; insufficient space or timing never weakens the gate or permits reusing/reissuing an attempt.

Arm1 read8 must qualify the NEW artifact with complete original tapes/CSVs/canonical/three-node checkpoint closure, strict scheduler, stopped owner identities and private push before arm2. Metadata and previous87a native runs do not confer this qualification. Native snapshot bytes remain retained; the inherited checkpoint proof is not a new independent snapshot-record decoder/recovery claim.

Schema3 prior collection gates require selected readWindow, fixedpage32 and common32 flags alongside all old full-original/native inventory/private push bindings. All new outcomes contain readWindow; physical registry129, maximum4 offers/RPC, absolute deadlines, UNKNOWN retention, force/full readback-before-either-ACK and business/control/read exclusion are unchanged in the application.

Pure guard attempt1 had one synthetic fixture error: its lineage omitted the mandatory capacity-pilot prefix. Production correctly rejected it. It is preserved fully; correcting only that synthetic fixture yielded20 passing controller guards. The authoritative parser's51 existing guards also pass on the copied exact bodies. These simulated declarations never become actual release qualification.
