from pathlib import Path
import json,hashlib,copy,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'dispatch-capacity-repeat-2-reporting-r1';assert not O.exists()
pins={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    pins[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));return json.loads(p.read_text())
base=read(B/'dispatch-capacity-first-5-curve-analysis-r1/CURVE.json');assert base['passed']
old=read(R/'evidence/index.json');assert len(old['runs'])==49 and len(old['capacityCohorts'])==20
observations=[]
for rate in (7500,8000):
    P=B/f'dispatch-capacity-repeat-2-{rate}-root-review-r1'
    proof=read(B/f'dispatch-capacity-repeat-2-{rate}-private-proof-r1/PRIVATE_PUSH.json')
    root=read(P/'ROOT_REVIEW.json');raw=read(P/'RAW_AUDIT.json');ready=read(P/'READINESS_REVIEW.json')
    cut=read(B/f'dispatch-capacity-repeat-2-{rate}-cut-recovery-r1/RECOVERY.json')
    diag=read(B/f'dispatch-capacity-repeat-2-{rate}-bottleneck-r1/DIAGNOSIS.json')
    phases=read(B/f'dispatch-capacity-repeat-2-{rate}-maintenance-phases-r1/PHASES.json')
    cfg=read(P/f'materialized/attempt-{rate}/idle-arm/load/configuration.json')
    result=read(P/f'materialized/attempt-{rate}/idle-arm/load/load-result.json')
    assert all(x['passed']for x in (proof,root,raw,ready,cut,diag,phases))
    assert proof['private']and proof['allOriginalNativeAndRawEvidencePushed']and proof['boundaryRepeatQualified']
    assert proof['repeatOrdinal']==2 and not proof['higherLoadPermitted']
    assert proof['codeFingerprint']==base['codeFingerprint']==raw['codeFingerprint']
    assert root['unknownObserved']==root['unknownFinal']==root['notSent']==root['serverRejected']==0
    assert root['confirmedAcceptedUniqueOrders']==rate*20
    observations.append(dict(rate=rate,repeat=2,planned=root['plannedArrivals'],accepted=root['confirmedAcceptedUniqueOrders'],
        goodput=root['arrivalWindowGoodputPerSecond'],p50Ns=root['allArrivalP50Ns'],p99Ns=root['allArrivalP99Ns'],
        finiteGateMet=proof['finiteGateMet'],windowConfirmationFraction=root['windowConfirmationFraction'],
        fullOfferedCutIntervals=cut['fullOfferedEquivalentCutIntervals'],clearingIntervals=cut['intervalsReachingZeroRecordedWaiting'],
        firstWaiting=cut['firstWaiting'],lastWaiting=cut['lastWaiting'],sampledQueueHigh=diag['sampledQueueHighWater'],
        perWorkerQueueHigh=diag['maximumObservedQueueSizePerWorker'],afterOfferP99Ns=diag['afterFirstPositiveOfferReturnP99Ns'],
        maintenanceWallNs=diag['maintenanceWallNs'],maintenanceCycles=root['maintenanceCycles'],privateCommit=proof['commit'],
        scheduledOriginUTC=cfg['scheduledOriginUTC'],drainNs=result['lastKnownReplyDrainNs']))
data=copy.deepcopy(old)
cohort=next(c for c in data['capacityCohorts']if c['id']=='cpu-rotating-fine-566dd2fa-20s')
for r in observations:
    rate=r['rate'];identity=f'cpu-rotating-fine-{rate}-repeat-2'
    timestamp=r['scheduledOriginUTC']
    data['runs'].append(dict(id=identity,label=f'CPU rotating dispatch · {rate:,}/s · repeat 2',
        scope=f"{r['planned']:,} planned · all accepted · finite 20s boundary repeat",model='One CPU host · three JVMs · loopback UDP · one physical session',
        commands=r['planned'],throughput=r['goodput'],p50Millis=r['p50Ns']/1e6,p99Millis=r['p99Ns']/1e6,unknown=0,correctnessPassed=True,
        durability='sync2 replicated log; exact-prefix force and full readback before both ACKs',timestamp=timestamp,
        artifactPath=f'evidence/2026-10-24/runpod-cpu/retention-dispatch-capacity-v3/repeat-2-native-{rate}-r1/README.md',
        limitations=[f"Same source566dd2fa/code2b8d7594 as the first observation. Finite20s;all{r['planned']} accepted;notSent/rejected/observed UNKNOWN/final UNKNOWN=0/0/0/0.",
            f"Window confirmation={r['windowConfirmationFraction']*100:.4f}%;finite gate {'met'if r['finiteGateMet']else'not met'}. Recorded waiting clears in {r['clearingIntervals']}/{r['fullOfferedCutIntervals']} offered cut intervals;first/last cut-end waiting={r['firstWaiting']}/{r['lastWaiting']}.",
            'All prior observations retained,including the earlier 8000/s gate miss. Two short observations per boundary rate do not establish significance,sustained capacity,an SLA or any100M target.',
            'Leader0/sync2/ROTATING_CONTINUE/read128/page32/batch4/chunk6144/owner1ms/driver100us/W128Q64. Two original-PID2s readiness gates and5s warm-up;no JFR.128 logical workers are one physical session.',
            f"Full original native/raw/CSV/wire/offer/identity/readiness evidence privately verified at {r['privateCommit']}. Candidate-codec/reference checks are not an independent matching oracle or cold binary recovery."]))
    cohort['points'].append(dict(id=identity,rate=rate,workers=128,goodput=r['goodput'],p99Millis=r['p99Ns']/1e6,
        clientNotSent=0,rejected=0,serverErrors=0,unknown=0,unresolved=0,allOfferedAcceptedP99Millis=r['p99Ns']/1e6,
        drainSeconds=r['drainNs']/1e9,classification='FINITE_20S_GATE_MET'if r['finiteGateMet']else'FINITE_20S_GATE_NOT_MET',
        peakBacklog=r['sampledQueueHigh'],valid=True,stable=None,windowSeconds=20))
cohort['scope']+=' Same-artifact boundary repeat2 at7500/8000 is appended;original five observations remain unchanged. Two repeats per boundary rate are not statistical significance or sustained capacity.'
cohort['reportPath']='docs/CAPACITY_BOUNDARY_REPEATS_V3.md'
assert data['runs'][:49]==old['runs']and data['capacity']==old['capacity']
assert data['capacityCohorts'][:19]==old['capacityCohorts'][:19]and cohort['points'][:5]==old['capacityCohorts'][-1]['points']
assert all(Path(n).stat().st_size==p['bytes']and sha(Path(n))==p['sha256']for n,p in pins.items())
O.mkdir();(O/'index-before.json').write_bytes((R/'evidence/index.json').read_bytes());(O/'index-derived.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
(O/'COMPARISON.json').write_text(json.dumps(dict(passed=True,observations=observations,originalBoundaryObservations=[v for v in base['observations']if v['rate']in(7500,8000)],
    inputs=pins,sourceSha256=sha(Path(__file__)),allInputBodiesUnchanged=True,all49PriorRunsAndOriginalFivePointsPreserved=True,records=51,cohorts=20),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,records=51,cohorts=20,observations=observations)))
