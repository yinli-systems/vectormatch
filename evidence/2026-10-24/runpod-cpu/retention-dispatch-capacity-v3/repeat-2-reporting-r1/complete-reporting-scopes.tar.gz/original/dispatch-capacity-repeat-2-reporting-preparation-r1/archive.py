from pathlib import Path
import sys,json,tarfile,shutil,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024'
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=R/'evidence/2026-10-24/runpod-cpu/retention-dispatch-capacity-v3/repeat-2-reporting-r1';assert not O.exists()
report=B/'dispatch-capacity-repeat-2-reporting-r1';comparison=json.loads((report/'COMPARISON.json').read_text());applied=json.loads((report/'APPLIED.json').read_text())
assert comparison['passed']and applied['passed']and applied['indexSha256']==sha(R/'evidence/index.json')
sources={n:n for n in ['dispatch-capacity-repeat-2-reporting-r1','dispatch-capacity-repeat-2-reporting-preparation-r1',
    'dispatch-capacity-repeat-2-bottleneck-preparation-r1','dispatch-capacity-repeat-2-recovery-preparation-r1','dispatch-capacity-repeat-2-maintenance-phases-preparation-r1']}
for rate in (7500,8000):
    for suffix in ('private-proof','bottleneck','cut-recovery','maintenance-phases'):sources[f'repeat-{rate}-{suffix}']=f'dispatch-capacity-repeat-2-{rate}-{suffix}-r1'
scopes={label:tree(B/n)for label,n in sources.items()}
O.mkdir();archive=O/'complete-reporting-scopes.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for label,n in sources.items():t.add(B/n,arcname='original/'+label)
review=verify(archive,scopes);assert all(tree(B/n)==scopes[label]for label,n in sources.items())
(O/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(scopes,indent=2,sort_keys=True)+'\n')
(O/'SOURCE_MIRRORS.json').write_text(json.dumps(sources,indent=2,sort_keys=True)+'\n')
for n in ['docs/CAPACITY_BOUNDARY_REPEATS_V3.md','docs/DISPATCH_CAPACITY_RESULTS.md','evidence/index.json']:
    p=O/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p);assert sha(p)==sha(R/n)
shutil.copy2(report/'COMPARISON.json',O/'COMPARISON.json')
(O/'README.md').write_text('''# Same-artifact boundary repeats: complete reporting

Two fresh20s repeat lineages at7500/s and8000/s,identical source566dd2fa/code2b8d7594 to the first fine curve. Every original order accepted,zero notSent/rejected/observed or final UNKNOWN.7500/s p99=263.319874ms and27/46 clearing intervals;8000/s p99=580.140180ms and2/48 clearing intervals. The latter again misses the finite99% in-window confirmation gate. No higher load or optimization was executed. Two observations per boundary rate do not establish sustained capacity,significance,hard real time or any100M proof.

Complete native/raw evidence remains in sibling repeat-2-native-7500-r1 and repeat-2-native-8000-r1,including lossless whole compressed scope archives,original member inventories,CSV,wire/offer/identity/result/readiness and lifecycle evidence. This package retains the complete analysis sources,inputs/proofs,per-worker and interval analysis,derived index,previous index,application/HTTP receipts and exact published files. All49 earlier UI records and all original five-point values are retained;51 records/20 cohorts. HTTP response equals the local derived index;no browser-render claim.
''')
inv=tree(O);(O/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(O/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(O/'INVENTORY.json'),scopeReview=review,records=51,cohorts=20,observations=2,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,payloadFiles=len(inv['files']),originalReportingFiles=review['originalFiles'],archiveBytes=archive.stat().st_size,inventorySha256=sha(O/'INVENTORY.json'))))
