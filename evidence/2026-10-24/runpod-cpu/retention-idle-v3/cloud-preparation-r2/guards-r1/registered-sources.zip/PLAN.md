# Revision2: exact retained shutdown-warning taxonomy

Revision1 remains frozen byte-for-byte. This revision binds the same corrected7aa
artifact, actual Linux metadata/plan and root-accepted narrow warning predicate.
The original local native outer wrapper FAILED its broad ERROR-string assertion;
both Java parents exited0 with6400accepted/three cycles/final checkpoints/owned
stop. A separate post-close raw audit passed. Both local schedulerTimingValid
flags remain false, so no valid performance point or speedup is claimed.

The new controller, native auditor and raw auditor call the exact same pure
`shutdown_warning.py` (bb8725c5...). Every full log remains stored. Each report
includes warning count, exact marker/event text and SHA, byte/line positions,
matching final checkpoint and phase `AFTER_MATCHING_FINAL_CHECKPOINT_BY_NODE_LOG_ORDER`.
Only one terminal exact EOS-WARN pair per follower1/2 is accepted. Leader0,
before-checkpoint, otherWARN/error/exception/stack, duplicate/truncated pairs or
any unclassified line fail. No SIGTERM walltime or harmless-election claim is
made; the underlying source event can initiate election and remains counted.
The original failed gate is never overwritten or retroactively changed.

`release.logClassification` and runtime classifier SHA are strict fixed identity.
Both arms share one new4JAR artifact, one actual readWindow8 plan, fixed source
and all other operational bounds. Per-arm full independent raw/byte/owned-stop
closure and root signed collection gate remain required. This source freeze is
local preparation only; `candidate/release/release.json` remains releaseReadyfalse
until a separate root freeze. No Java/SSH/stage/benchmark has run for this revision.

# CPU idle policy ABAB — local preparation only

This is a new finite experiment on the already prepaid CPU Pod. It does not
deploy anything, allocate a resource, change the stopped original application,
or authorize a benchmark merely by existing. `release.template.json` is
`releaseReady:false`; no new JAR fingerprint or plan has been invented.

The initial93ca0f source had a real local startup failure: Archive consumed its
idle-strategy supplier more than once. The failed native evidence belongs to
the source author. This preparation cannot be promoted until the corrected
source, actual4JAR distribution, bounded factory-consumption schema, local
native result and root review have all been pinned. The corrected source is7aa3e98ccc77c4be89f9f4b98c98d688c18e5d23. Its source-only
review/frozen policy is6962da296ab29b8b80865b71c9a60fd890a9dbaf4a56dfbca03078cf16b8e2dd;
new native/JAR plan binding remains pending, so this is not a runnable release.

## Registered dimensions

One new artifact in all four arms, with explicit property
`-Dvectormatch.retention.idleMaxParkNs=N` immediately after the Java executable
in both parent and child-node argv. The order is exactly:

| Arm | N, nanoseconds | Fresh root under canonical PREP |
|---|---:|---|
| 1 | 1,000,000 | arm-1/idle-arm |
| 2 | 100,000 | arm-2/idle-arm |
| 3 | 1,000,000 | arm-3/idle-arm |
| 4 | 100,000 | arm-4/idle-arm |

Canonical PREP is `/opt/vectormatch-cpu/preparation/cpu-idle-cloud-abab-r1`.
Each parent uses `RetentionCapacityAeronPilotV3 <freshRoot> idle-window8 42000`.
There is no automatic four-arm loop, resume, rerun, alternate ID or random-port
fallback. Default controller invocation is a read-only preflight; actual start
requires `--arm N --release-sha256 SHA --start-new`. Arms2–4 additionally require
`--prior-collection-sha256` for the immediate previous arm. Existing job roots
are always rejected.

Fixed configuration: readWindow8, cap4, chunk6144, eventFetch16,6400 arrivals at
500/s (12.8-second exposure), W128, external taskQ64 per worker, one owner/session,
appointed leader0, sync2/force(true), MTU1248, original profile and maintenance
cut. Arrivals continue during maintenance. The logical owner business wait loop
remains the existing deadline-aware park up to1ms. The factor changes configured
maximum requested park of the selected node driver/archive/consensus/service
strategies and the measured owner's shared MediaDriver; it is not a guarantee
about actual kernel wake-up/sleep duration. Supplier consumption count is not
the number of runner threads and must not be called a sleep measurement.

## Exact release and closure

The version2 release freezes the new source commit, code/profile fingerprints,
canonical Java21 executable/release SHA, all four JAR paths/bytes/SHA, and the
actual three-JAR node class-source closure (Agrona DirectBuffer comes from
aeron-all in the pinned distribution). `derivedPlan` is the actual frozen-JAR
readWindow8 plan shared by all arms, not a hand-written workload witness.
All plan keys, operational limits, maximum4offers, raw2GiB and growth2.5GiB hard
ceilings remain unchanged. Root must compare actual new plans to the expected
common plan before approving the release. A conservative reply upper bound
does not require a measured reply to reach that size.

Each arm owns exactly one parent and three node JVMs. The unchanged reviewed
Linux ownership helper checks PID, `/proc` startTicks and full NUL-delimited argv
SHA before pidfd-based TERM and during closure. No broad kills, numeric-PID
fallback or automatic KILL is introduced. Parent is stopped/reaped before final
node discovery. Unconfirmed owned stop blocks active-native hashing/archiving
and every later arm. Java/PG absence checks are sampled facts, not an exclusive
host reservation. All successful and failed partial CSV/tapes/logs/source and
process identities are retained; a failed arm cannot satisfy a next-arm gate.

The original three native trees57 files and stopped PostgreSQL989 files are
protected by SHA/bytes/owners/modes/directories before and after each arm, using
the immutable6769aa… manifest. No SQL or original-state writes are performed.

Node actual attestation files, matching startup logs, reserved intents and PID
records must agree. Load config/summary and every measured-owner transport
observation must agree with the selected explicit property. Every consumed
strategy instance must have a distinct recorded ordinal, a supported role,
correct actual Backoff class/description and tuple (spins10, driver yields5 or
agent yields20, min1000ns, selected maximum). Finalv2 schema binds exactly7 fresh factory creations per node (driver1 and
archive/consensus/service2 each) plus1 owner driver, with per-role consumption
ordinals, distinct per-process instance ordinals and bounded caller diagnostics.
It does not equate22 factory creations with22 running agent threads. Native
confirmation and actual new-JAR binding remain pending.
Missing/unknown evidence fails; no requested property is substituted for an
actual observation. No claim is made about inaccessible private runner fields.

## Collection and next-arm gate

`build_config.py` is local only and requires the actual root stage receipt,
release SHA, protected reference SHA and every preceding root collection gate.
Its exact source allowlist comes from staged rows, plus explicit preceding gate
files and exactly three current-arm opaque execution files:
`arm-N-execution-register.json`, `arm-N-execution.stdout`,
`arm-N-execution.stderr`. The register may be JSONL and is never parsed as one
JSON object. PREP is never recursively collected.

`collect_and_audit.py` defaults to local validation. Explicit read-only SSH
collection additionally requires the exact root-frozen controller-closed
receipt and frozen preparation SHA. The required receipt has schemaVersion2,
scope `ROOT_VERIFIED_CLOSED_CPU_IDLE_CONTROLLER`, arm/N/release/controller/job
binding, `controllerIdentityGone:true`, `allOwnedStopped:true` and actual
inspection source/result SHA. Parent exit alone does not satisfy it.

The existing full byte-stream collector, correlation-map raw validator,
actual Header/Image lifecycle checks, per-arrival CSV semantics, six read phases,
three cycles, serial ACK/durable-prefix fences and positive-offer overlap audits
are reused with the single flat arm path. Outer and inner gzip members are read
in full and checked for SHA/bytes/modes/uid/gid/empty-directory closure without
materializing sparse files. All outcomes get generic byte closure; strict
functional success additionally requires6400 distinct accepted identities,
zero final UNKNOWN/notSent/rejections and actual window8 overlap. Undefined
all-arrival accepted p99 remains null on any nonaccepted/unknown arrival.

Local finalization can produce only an explicitly unapproved gate candidate.
Root must independently verify the full archive/raw receipts and sign a new
`ROOT_VERIFIED_CLOSED_CPU_IDLE_ARM_COLLECTION` receipt for each preceding arm.
That gate binds its archive/inventory, same release/controller, actual park
selection and complete retained failures. The remote controller rechecks the
compressed SHA and streams the complete prior native archive. It does not
delete files. Four finite observations remain a latency/configuration
experiment, not a stable/sustained capacity or100M claim.

## Space and the one authorized read-only inspection

The one actual metadata inspection ran2026-10-24T07:52:11Z and exited0. Its exact
source/SSH argv/remote helper SHA/stdout/stderr are in `resource-inspection-r1`.
Observed free overlay3,254,255,616B, no Java/PG,32 allowed logical CPUs,
cpu.max=max, memory.max64,000,000,000B, current20,726,407,168B including cache.
These are one-time observations, not future guarantees. No further SSH was run.

Each arm requires free >= actual plan allocated-growth +16MiB monitor reserve
+256MiB archive reserve +1GiB free floor. With the previous plan's589,327,865B
growth this is1,948,282,361B, pending verification against the new JAR plan.
During runtime the same1GiB floor and derived single-arm growth cap apply.
The four-arm prospective growth plus floor exceeds current free space; no
unconditional claim that all four fit is made. Per-arm checks can block.

If a later arm does not fit, root may separately review removal of *only* a
completed owned `arm-N/idle-arm` tree after independent local full readback,
exact native file/directory manifest comparison, stopped identity proof and
preservation of both local full archives and the remote compressed archive.
Any such separate cleanup must bind exact path, manifest SHA, modes/owners and
archive SHA, never touch original/restorations/PG/JDK/releases/other jobs, and
retain before/after receipts. The next gate must explicitly attest
`rootReviewedExactOwnedNativeRemoval:true` if its owned native is absent.
This preparation implements no deletion or cleanup launcher and authorizes no
mutation merely because space is insufficient.

## Local validation

First registered guard attempt:12 meaningful delta guards and122 exact frozen
baseline guards passed. `guards-r1` contains exact commands/interpreter, source
ZIP, input hashes and full stdout/stderr. These are local Python fixtures, not
Linux execution, actual artifact/native proof or performance results. After the correctedv2 source handoff, guards-r2 ran13 delta tests successfully,
including a single-flat-arm process-registry test. The original122 tests were
not repeated because their exact frozen inputs are unchanged. Python3.8 syntax
parsing also passed; actual Linux execution remains a future root stage gate.
