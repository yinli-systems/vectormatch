from pathlib import Path
import json,shutil,hashlib,xml.etree.ElementTree as E,datetime,re,zipfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'startup-readiness-unit-r3';assert not(O/'VALIDATION.json').exists();assert json.loads((O/'EXECUTION.json').read_text())['exitCode']==0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,destination):
 source,destination=Path(source),Path(destination)
 if destination.exists():
  if source.is_dir():
   a={str(p.relative_to(source)):(p.stat().st_size,sha(p))for p in source.rglob('*')if p.is_file()};z={str(p.relative_to(destination)):(p.stat().st_size,sha(p))for p in destination.rglob('*')if p.is_file()};assert a==z
  else:assert source.read_bytes()==destination.read_bytes()
 elif source.is_dir():shutil.copytree(source,destination)
 else:destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)

pins=json.loads((O/'SOURCE_INPUTS.json').read_text())
for n,row in pins.items():assert(R/n).stat().st_size==row['bytes']and sha(R/n)==row['sha256']and sha(O/'source-inputs'/n)==row['sha256']
copy(R/'cluster/build/test-results/test',O/'junit');copy(R/'cluster/build/reports/tests/test',O/'html-report');x=json.loads((O/'ACTUAL_TEST_INPUTS.json').read_text());classpath=[]
for i,n in enumerate(x['classpath']):
 p=Path(n);row=dict(original=n,exists=p.exists())
 if p.exists():
  q=O/'actual-classpath'/str(i)/p.name;q.parent.mkdir(parents=True,exist_ok=True)
  if p.is_dir():copy(p,q)
  else:copy(p,q)
  row['copy']=str(q.relative_to(O))
 else:assert n.endswith('/resources/main')or n.endswith('/resources/test');row['reason']='Registered NO-SOURCE resource directory absent'
 classpath.append(row)
java=Path(x['javaExecutable']);(O/'jdk').mkdir(exist_ok=True);copy(java,O/'jdk/java');copy(java.parents[1]/'release',O/'jdk/release');copy(R/'cluster/build/install/cluster',O/'installed');tests=[];temps=set();identities=set()
for p in sorted((O/'junit').glob('TEST-*.xml')):
 v=E.parse(p).getroot();tests.append(dict(name=v.attrib['name'],tests=int(v.attrib['tests']),failures=int(v.attrib['failures']),errors=int(v.attrib['errors']),skipped=int(v.attrib.get('skipped',0))))
 for c in v.findall('testcase'):
  identity=(c.attrib['classname'],c.attrib['name']);assert identity not in identities;identities.add(identity)
 for n in re.findall(r'/[^\s<>]+/junit[^\s<>]+',p.read_text()):
  q=Path(n.rstrip('.,:;"'+chr(39)))
  if q.is_dir():temps.add(q.resolve())
# Never follow a fixture's deliberately hostile/self-referential symlink.
import os,stat
fixtureTrees={};entryCount=0;totalBytes=0
for q in sorted(temps):
 dst=O/'retained-unit-temp-r3'/q.name;dst.mkdir(parents=True);entries={}
 for directory,dirs,files in os.walk(q,followlinks=False):
  here=Path(directory);relative=here.relative_to(q);target=dst/relative;target.mkdir(exist_ok=True)
  for path in [here,*[here/n for n in dirs+files]]:
   n=path.relative_to(q).as_posix();info=path.lstat();row=dict(mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid)
   if path.is_symlink():row.update(kind='symlink',target=os.readlink(path))
   elif path.is_dir():row.update(kind='directory');(dst/path.relative_to(q)).mkdir(parents=True,exist_ok=True)
   else:
    assert path.is_file();row.update(kind='file',bytes=info.st_size,sha256=sha(path));totalBytes+=info.st_size;assert totalBytes<=512*1024**2;copy(path,dst/path.relative_to(q));assert sha(dst/path.relative_to(q))==row['sha256']
   entries[n]=row;entryCount+=1;assert entryCount<=8192
 fixtureTrees[str(q)]=dict(copy=str(dst.relative_to(O)),entries=entries)
(O/'FIXTURE_TREE.json').write_text(json.dumps(fixtureTrees,indent=2,sort_keys=True)+'\n')
links={n:entry for root in fixtureTrees.values()for n,entry in root['entries'].items()if entry['kind']=='symlink'}
assert len(identities)==73 and len(tests)==15 and sum(t['tests']for t in tests)==73 and all(t['failures']==t['errors']==t['skipped']==0 for t in tests)
classes={}
for name,root in [('cluster',R/'cluster/build/classes/java/main'),('core',R/'core/build/classes/java/main')]:
 jar=O/'installed/lib'/(name+'-0.1.0-SNAPSHOT.jar')
 with zipfile.ZipFile(jar)as z:
  expected={p.relative_to(root).as_posix():p for p in root.rglob('*.class')};assert set(expected)=={n for n in z.namelist()if n.endswith('.class')}
  for n,p in expected.items():assert z.read(n)==p.read_bytes()
  classes[name]=len(expected)
assert any(n.endswith('RetentionStartupReadinessV3.class')for n in zipfile.ZipFile(O/'installed/lib/cluster-0.1.0-SNAPSHOT.jar').namelist())
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),distinctTests=len(identities),junitSuites=tests,registeredClasspathEntries=classpath,retainedTempRoots=len(temps),fixtureSymlinkTargetsRecordedWithoutFollowing=len(links),faithfulRegularFixtureBodiesAndAllEntryMetadataRetained=True,collectionRevision="Earlier collectors stopped on var/private-var alias duplicates and a deliberately cyclic POSIX fixture symlink. Both sources and partial copies retained. Final collector uses bounded no-follow traversal, retains lexical links as metadata and copies each regular file once.",allSourceInputsMatchBeforeBuildAndAfterClosure=True,allExistingClasspathBodiesCopied=True,installedJarClassesEqualActualTestCompiledMainClasses=classes,jdkExecutableSha256=sha(O/'jdk/java'),jdkReleaseSha256=sha(O/'jdk/release'),newReadinessTests=9,priorRegressionTests=64,firstFailedFixtureAttemptRetained='startup-readiness-unit-r1',noNativePerformanceClaim=True)
(O/'VALIDATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,tests=len(identities),suites=len(tests),retainedTempRoots=len(temps),fixtureSymlinkTargetsRecordedWithoutFollowing=len(links),faithfulRegularFixtureBodiesAndAllEntryMetadataRetained=True,collectionRevision="Earlier collectors stopped on var/private-var alias duplicates and a deliberately cyclic POSIX fixture symlink. Both sources and partial copies retained. Final collector uses bounded no-follow traversal, retains lexical links as metadata and copies each regular file once.",installedClasses=classes)))
