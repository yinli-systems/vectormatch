from pathlib import Path
import json,shutil,hashlib,xml.etree.ElementTree as E,datetime,re,zipfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'startup-readiness-unit-r2';assert not(O/'VALIDATION.json').exists();assert json.loads((O/'EXECUTION.json').read_text())['exitCode']==0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((O/'SOURCE_INPUTS.json').read_text())
for n,row in pins.items():assert(R/n).stat().st_size==row['bytes']and sha(R/n)==row['sha256']and sha(O/'source-inputs'/n)==row['sha256']
shutil.copytree(R/'cluster/build/test-results/test',O/'junit');shutil.copytree(R/'cluster/build/reports/tests/test',O/'html-report');x=json.loads((O/'ACTUAL_TEST_INPUTS.json').read_text());classpath=[]
for i,n in enumerate(x['classpath']):
 p=Path(n);row=dict(original=n,exists=p.exists())
 if p.exists():
  q=O/'actual-classpath'/str(i)/p.name;q.parent.mkdir(parents=True,exist_ok=True)
  if p.is_dir():shutil.copytree(p,q)
  else:shutil.copy2(p,q)
  row['copy']=str(q.relative_to(O))
 else:assert n.endswith('/resources/main')or n.endswith('/resources/test');row['reason']='Registered NO-SOURCE resource directory absent'
 classpath.append(row)
java=Path(x['javaExecutable']);(O/'jdk').mkdir();shutil.copy2(java,O/'jdk/java');shutil.copy2(java.parents[1]/'release',O/'jdk/release');shutil.copytree(R/'cluster/build/install/cluster',O/'installed');tests=[];temps=set();identities=set()
for p in sorted((O/'junit').glob('TEST-*.xml')):
 v=E.parse(p).getroot();tests.append(dict(name=v.attrib['name'],tests=int(v.attrib['tests']),failures=int(v.attrib['failures']),errors=int(v.attrib['errors']),skipped=int(v.attrib.get('skipped',0))))
 for c in v.findall('testcase'):
  identity=(c.attrib['classname'],c.attrib['name']);assert identity not in identities;identities.add(identity)
 for n in re.findall(r'/[^\s<>]+/junit[^\s<>]+',p.read_text()):
  q=Path(n.rstrip('.,:;"'+chr(39)))
  if q.is_dir():temps.add(q)
for q in sorted(temps):
 dst=O/'retained-unit-temp'/q.name;dst.parent.mkdir(exist_ok=True);shutil.copytree(q,dst)
assert len(identities)==72 and len(tests)==15 and sum(t['tests']for t in tests)==72 and all(t['failures']==t['errors']==t['skipped']==0 for t in tests)
classes={}
for name,root in [('cluster',R/'cluster/build/classes/java/main'),('core',R/'core/build/classes/java/main')]:
 jar=O/'installed/lib'/(name+'-0.1.0-SNAPSHOT.jar')
 with zipfile.ZipFile(jar)as z:
  expected={p.relative_to(root).as_posix():p for p in root.rglob('*.class')};assert set(expected)=={n for n in z.namelist()if n.endswith('.class')}
  for n,p in expected.items():assert z.read(n)==p.read_bytes()
  classes[name]=len(expected)
assert any(n.endswith('RetentionStartupReadinessV3.class')for n in zipfile.ZipFile(O/'installed/lib/cluster-0.1.0-SNAPSHOT.jar').namelist())
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),distinctTests=len(identities),junitSuites=tests,registeredClasspathEntries=classpath,retainedTempRoots=len(temps),allSourceInputsMatchBeforeBuildAndAfterClosure=True,allExistingClasspathBodiesCopied=True,installedJarClassesEqualActualTestCompiledMainClasses=classes,jdkExecutableSha256=sha(O/'jdk/java'),jdkReleaseSha256=sha(O/'jdk/release'),newReadinessTests=8,priorRegressionTests=64,firstFailedFixtureAttemptRetained='startup-readiness-unit-r1',noNativePerformanceClaim=True)
(O/'VALIDATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,tests=len(identities),suites=len(tests),retainedTempRoots=len(temps),installedClasses=classes)))
