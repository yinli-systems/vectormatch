from pathlib import Path
import json,hashlib,datetime,subprocess,os,sys,shutil,xml.etree.ElementTree as E
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';attempt=int(sys.argv[1]);O=B/('dispatch-fairness-unit-r%d'%attempt);O.mkdir();source=(B/'read128-capacity-unit-r1/capture.gradle').read_text().replace('read128-capacity-unit-r1','dispatch-fairness-unit-r%d'%attempt);(O/'capture.gradle').write_text(source)
patterns=sorted({E.parse(p).getroot().attrib['name']for p in(B/'read128-capacity-unit-r1/junit').glob('TEST-*.xml')}|{'io.vectormatch.cluster.RetentionStartupReadinessV3Test','io.vectormatch.cluster.RetentionCapacityDispatchOrderV3Test'});args=['./gradlew','--no-daemon','--console=plain','-I',str(O/'capture.gradle'),':cluster:test']
for name in patterns:args+=['--tests',name]
args.append(':cluster:installDist');(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),arguments=args,patterns=patterns,sourceCaptureTiming='Before actual Gradle launch',noCloudWorkload=True),indent=2)+'\n');files=[]
for name in ['core','cluster']:files.extend(p for p in(R/name/'src').rglob('*.java')if p.is_file())
files.extend(R/x for x in ['build.gradle.kts','settings.gradle.kts','core/build.gradle.kts','cluster/build.gradle.kts','gradle.properties']);pins={}
for p in files:
 dst=O/'source-inputs'/p.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);pins[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(O/'SOURCE_INPUTS.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n');env=os.environ.copy();env['JAVA_HOME']=str((R/'.tools/jdk').resolve());env['PATH']=str((R/'.tools/jdk/bin').resolve())+':'+env['PATH']
with(O/'gradle.stdout').open('xb')as stdout,(O/'gradle.stderr').open('xb')as stderr:result=subprocess.run(args,env=env,stdout=stdout,stderr=stderr)
(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=result.returncode,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');print(json.dumps(dict(exitCode=result.returncode)));assert result.returncode==0
