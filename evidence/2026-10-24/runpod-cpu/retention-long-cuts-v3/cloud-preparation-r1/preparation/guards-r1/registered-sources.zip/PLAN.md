# Draft: one fixed CPU long-cut observation

No cloud staging, SSH, Java, benchmark, new resource, original-state/PG mutation, deletion or prune was performed for this preparation.
Canonical future namespace: `/opt/vectormatch-cpu/preparation/cpu-long-cuts-cloud-r1/arm-1/idle-arm`.
Only manual `--arm 1` is accepted. Default behavior is read-only preflight; `--start-new` remains a separate root-controlled one-shot action.
There is no ABAB, prior-arm gate, alternate rate/duration/idle setting or automatic retry.

The new controller is adapted from frozen cpu-idle-cloud-preparation-r2. Linux process identity/pidfd cleanup,
registry persistence, strict owned-idle preflight, telemetry, protected-state scans, actual egress Header/Image association/lifecycle checks,
TAR readback and TERM-only no-escalation cleanup bodies are unchanged. Deltas are source-bound in BASELINE_AND_PLAN_PROVENANCE.json and pure guards.
The copied baseline controller is historical source for comparison only; no old raw parser is used or modified here.

Fixed release: source bcf49c10b77a14708b53d3fc6c115a6a3b834408, actual JAR fingerprint6033c9ebfc2a7b1836c45f858784a4930540b469eb136635761fd3217733edc8.
33792 arrivals at500/s for67.584s, single lineage/owner/session, cap4/chunk6144/Fetch16/read8/100us requested maximum park,
leader0/term0/sync2/MTU1248/fixed42000 with no fallback. Parent CLI is `idle-window8-long-cuts`.
All3setup commands share the first full command cut:11full command cuts + final3-command partial;
cuts2–11 are the10equivalent setup-free3072-order cuts. Source registration must contain the exact workloadPreset and this cut declaration.
The controller requires every planned order, all12cycles, zero observed/finalUNKNOWN, zero notSent/rejection/duplicate, and a valid actual scheduler.
The local native's diagnostic timing-invalid qualification is not available in this CPU controller or CLI.

Actual local installed-JAR prospective Plan:7243maintenance RPCs,2982archive chunks,4225FetchEvents,
96reserved ACK journal records/117792B,185514924B raw trace and757122377B allocated growth.
The profile4096-record journal and RunBudget1024-record effective limit are unchanged, as are all source hard limits:
2GiB raw,2.5GiB allocated growth,1MiB-character transport document,256source samples/2048source-owned paths,
90s task lifetime/2s dispatch permit/90s drain and four offers per logical RPC.
The controller retains240s execution/360s total,512telemetry samples/8MiB,256MiB archive,
8192wrapper archive paths/12GiB logical bytes. These wrapper bounds do not replace or raise the source's narrower caps.
The existing allocated-monitor360samples at0.5s are retained; expected67.584s+90s drain fits without truncation,
while1Hz telemetry is independently bounded512. sampled CPU/I/O/UTC phase observations are not pure fsync or validated cross-clock timing.

Current stopped originals remain the exact6769aa2590668ba69692b17565c3463cc274b1fa2a777129d742c1e04899f753 protected manifest:
57native files across3original trees plus separately referenced989PG files. No fresh baseline is accepted.
Exact node startup/factory evidence remains7creations per node +1owner =22configured objects, not22threads or measured sleeps.
The existing pinned narrow post-checkpoint follower EOS WARN classifier is unchanged; originals and strict failures are retained,
and no after-SIGTERM wall-time causality is claimed.

`release.template.json` remains releaseReady=false. Null proof reference bytes/SHA block promotion by merely flipping that boolean.
Required immutable references are the authoritative long raw audit, its parser freeze, new actual Linux metadata observation/receipt,
and root's evidence review. The authoritative long parser is owned separately by capacity_telemetry and is not forked here.
Only that approved source may supply the24phase/12cycle/33792arrival audit. Do not alter the old8phase auditor.
The local source/native/metadata already obtained are functional/prospective evidence; the local scheduler was invalid.
No stable500/s, maximum throughput, zero-latency, independent-host UDP or100M claim follows from this draft.

Metadata staging draft uses the already compiled no-network LongCutsDistributionObservation source/class +4exactJARs (six explicit input files).
Its default invocation only builds the local bundle/config; that was performed without running Java or SSH.
Future root execution requires the exact reviewed config SHA and a fresh separate
`/opt/vectormatch-cpu/preparation/cpu-long-cuts-release-metadata-r1` namespace. It verifies host/Linux/root/JDK, six file SHA/modes,
direct metadata child identity/exit, actual long/short Plan and actual class sources; no driver/controller/business RPC is launched.
New actual Linux metadata is still pending. After all proof references exist, root must independently freeze ready bytes,
perform exclusive canonical staging, run actual Linux pure guards and default read-only arm1preflight, then explicitly launch once.
