package io.vectormatch.cluster;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RetentionEgressBoundsV3Test {
    private RetentionEgressBoundsV3.ImageMetadata image(long correlation,int session,int term){
        return new RetentionEgressBoundsV3.ImageMetadata(correlation,session,102,term,1248);
    }
    @Test void completeSixKiBReplyFitsActualMinimumTermAndHeadersBindAllImages(){
        var bounds=new RetentionEgressBoundsV3(RetentionReplyV3.maxEncodedArchiveChunkReplyBytes(6144));
        var first=image(7,31,65536);var second=image(8,-32,1024*1024);
        bounds.observe(List.of(first,second));
        bounds.reply(7,31,102,65536,1248,6919);bounds.reply(8,-32,102,1024*1024,1248,4315);
        bounds.observe(List.of(second,first));var view=bounds.snapshot();
        assertEquals(6951,view.get("requiredCompleteMessageBytes"));assertEquals(8192,view.get("minimumActualDerivedMaxMessageLength"));
        assertEquals(2L,view.get("replyHeaderImageAssociations"));assertEquals(2,((List<?>)view.get("images")).size());
        assertEquals(false,view.get("defaultMetadataSubstituted"));
    }
    @Test void missingDriftingOrUnsupportedActualMetadataNeverFallsBackToDefaults(){
        var bounds=new RetentionEgressBoundsV3(6919);
        assertThrows(IllegalStateException.class,()->bounds.observe(List.of()));assertThrows(IllegalStateException.class,bounds::snapshot);
        assertThrows(IllegalArgumentException.class,()->image(7,1,32768));
        assertThrows(IllegalArgumentException.class,()->new RetentionEgressBoundsV3.ImageMetadata(7,1,102,65536,1408));
        var first=image(7,1,65536);bounds.observe(List.of(first));
        assertThrows(IllegalStateException.class,()->bounds.observe(List.of(image(7,1,131072))));
        assertThrows(IllegalStateException.class,()->bounds.observe(List.of(first,image(8,2,65536))));
        assertThrows(IllegalStateException.class,()->bounds.observe(List.of(first,first)));
    }
    @Test void mismatchedReplyAndCompleteMessageOverflowFailWithoutAssociating(){
        var bounds=new RetentionEgressBoundsV3(6919);bounds.observe(List.of(image(7,31,65536)));
        assertThrows(IllegalStateException.class,()->bounds.reply(8,31,102,65536,1248,6919));
        assertThrows(IllegalStateException.class,()->bounds.reply(7,32,102,65536,1248,6919));
        assertThrows(IllegalStateException.class,()->bounds.reply(7,31,103,65536,1248,6919));
        assertThrows(IllegalStateException.class,()->bounds.reply(7,31,102,131072,1248,6919));
        assertThrows(IllegalStateException.class,()->bounds.reply(7,31,102,65536,1408,6919));
        assertThrows(IllegalStateException.class,()->bounds.reply(7,31,102,65536,1248,8161));
        assertEquals(0L,bounds.snapshot().get("replyHeaderImageAssociations"));
        bounds.reply(7,31,102,65536,1248,8160);assertEquals(1L,bounds.snapshot().get("replyHeaderImageAssociations"));
    }
}
