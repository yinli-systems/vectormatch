from pathlib import Path
import datetime,hashlib,json,subprocess
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;O=B/'batch-wire-validation-parity-r1';assert not O.exists();O.mkdir();(O/'classes').mkdir()
W=B/'batch-wire-validation-worktree';lib=B/'verified-archive-handoff-artifact-preparation-r1/lib';baseline=':'.join(str(lib/n)for n in('cluster-0.1.0-SNAPSHOT.jar','core-0.1.0-SNAPSHOT.jar','aeron-all-1.53.3.jar','agrona-2.6.1.jar'))
args=[str(R/'.tools/jdk/bin/javac'),'-cp',baseline,'-d',str(O/'classes'),str(P/'BatchWireParity.java')];r=subprocess.run(args,capture_output=True,text=True);(O/'compile.stdout').write_text(r.stdout);(O/'compile.stderr').write_text(r.stderr);assert r.returncode==0
registration=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256((P/'BatchWireParity.java').read_bytes()).hexdigest(),baselineJarPins={n:dict(bytes=(lib/n).stat().st_size,sha256=hashlib.sha256((lib/n).read_bytes()).hexdigest())for n in('cluster-0.1.0-SNAPSHOT.jar','core-0.1.0-SNAPSHOT.jar')},runs=[])
for label,cp in [('baseline',baseline),('candidate',str(W/'cluster/build/classes/java/main')+':'+baseline)]:
 args=[str(R/'.tools/jdk/bin/java'),'-Xmx256m','-cp',str(O/'classes')+':'+cp,'io.vectormatch.cluster.BatchWireParity',str(O/(label+'.csv'))];registration['runs'].append(dict(label=label,arguments=args))
 with(O/(label+'.stdout')).open('xb')as out,(O/(label+'.stderr')).open('xb')as err:r=subprocess.run(args,stdout=out,stderr=err,timeout=90)
 (O/(label+'.execution.json')).write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n');assert r.returncode==0
(O/'REGISTRATION.json').write_text(json.dumps(registration,indent=2,sort_keys=True)+'\n');a=(O/'baseline.csv').read_bytes();z=(O/'candidate.csv').read_bytes();assert a==z
result=dict(passed=True,allRowsByteIdentical=True,rows=len(a.splitlines()),bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),validBatches=4096,mutatedWires=4096,truncations=2639,oversizeWires=2,invalidConstructors=6,fixtureSeed='0x564d5733',noApplicationOrders=True,noPerformanceClaim=True,sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
