package io.vectormatch.cluster;
import io.vectormatch.core.MatchingEngine.*;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import static io.vectormatch.cluster.RetentionWireV3.*;
public final class BatchWireParity {
 static final Scope SCOPE=new Scope("a".repeat(64),"parity-v3");
 static String digest(byte[] bytes)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
 static void decoded(PrintWriter out,String label,byte[] bytes)throws Exception{
  try{var request=decode(bytes);if(!Arrays.equals(bytes,encode(request)))throw new AssertionError("noncanonical decoder acceptance");out.println(label+",ACCEPT,"+digest(encode(request)));}
  catch(IllegalArgumentException refused){out.println(label+",REFUSE,"+refused.getClass().getName()+","+refused.getMessage());}
 }
 public static void main(String[] args)throws Exception{
  try(var out=new PrintWriter(Files.newBufferedWriter(Path.of(args[0]),StandardOpenOption.CREATE_NEW))){
   var random=new Random(0x564d5733L);
   for(int i=0;i<4096;i++){
    int n=1+i%4;var input=new ArrayList<Command>();
    for(int j=0;j<n;j++){
     long account=j+1,seq=Long.MAX_VALUE-i;String producer="p"+j;
     Command c=switch((i+j)%3){case 0->new Deposit(account,producer,seq,i%5==0?null:Asset.BASE,random.nextLong());case 1->new Place(account,producer,seq,i%7==0?"界".repeat(120):"order-"+i+"-"+j,i%5==0?null:Side.BUY,random.nextLong(),random.nextLong(),i%11==0?null:TimeInForce.IOC);default->new Cancel(account,producer,seq,random.nextLong());};input.add(c);
    }
    var batch=new BusinessBatch(input);input.clear();if(batch.commands().size()!=n)throw new AssertionError("input alias");
    var request=new Request(SCOPE,i-2048,batch);byte[] bytes=encode(request),operation=encodeOperation(batch);
    if(!batch.equals(decodeOperation(operation))||!request.equals(decode(bytes)))throw new AssertionError("semantic parity");
    out.println("valid-"+i+","+bytes.length+","+digest(bytes)+","+digest(operation));
    byte[] mutated=bytes.clone();int at=random.nextInt(bytes.length);mutated[at]^=(byte)(1+random.nextInt(255));decoded(out,"mutated-"+i,mutated);
   }
   var maximum=new ArrayList<Command>();for(int j=0;j<4;j++)maximum.add(new Place(Long.MAX_VALUE,"p".repeat(47)+j,Long.MAX_VALUE,"x".repeat(512),Side.BUY,Long.MAX_VALUE,Long.MAX_VALUE,TimeInForce.GTC));
   byte[] full=encode(new Request(new Scope("a".repeat(64),"l".repeat(64)),Long.MAX_VALUE,new BusinessBatch(maximum)));if(full.length!=2639)throw new AssertionError("maximum fixture");
   for(int n=0;n<full.length;n++)decoded(out,"truncated-"+n,Arrays.copyOf(full,n));
   for(int n:new int[]{4096,4097})decoded(out,"oversize-"+n,Arrays.copyOf(full,n));
   for(int i=0;i<6;i++){
    Command command=switch(i){case 0->new Deposit(0,"p",1,Asset.BASE,1);case 1->new Deposit(1,"p",0,Asset.BASE,1);case 2->new Deposit(1,"界",1,Asset.BASE,1);case 3->new Place(1,"p",1,"\uD800",Side.BUY,1,1,TimeInForce.GTC);case 4->new Place(1,"p",1,"界".repeat(512),Side.BUY,1,1,TimeInForce.GTC);default->new Deposit(1,"p".repeat(49),1,Asset.BASE,1);};
    try{encode(new Request(SCOPE,1,new BusinessBatch(List.of(command))));throw new AssertionError("invalid constructor accepted");}catch(IllegalArgumentException refused){out.println("invalid-constructor-"+i+",REFUSE,"+refused.getClass().getName()+","+refused.getMessage());}
   }
  }
 }
}
