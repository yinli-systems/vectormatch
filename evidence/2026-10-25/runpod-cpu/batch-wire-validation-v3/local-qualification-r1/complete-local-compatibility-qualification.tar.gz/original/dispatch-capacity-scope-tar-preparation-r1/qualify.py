from pathlib import Path
import sys,tarfile,io,json,datetime
from scope_tar import tree,verify,sha

O=Path(__file__).resolve().parent.parent/'dispatch-capacity-scope-tar-validation-r1'
assert not O.exists();O.mkdir();source=O/'fixture';source.mkdir();(source/'empty').mkdir()
(source/'body.bin').write_bytes(bytes(range(256))*19+b'original\x00tail')
inventory={'fixture':tree(source)}
good=O/'valid.tar.gz'
with tarfile.open(good,'w:gz')as t:t.add(source,arcname='original/fixture')
result=verify(good,inventory);assert result['originalFiles']==1
cases=[]
for label in ('changed-body','missing-body','duplicate-member','link-member','parent-traversal'):
    p=O/(label+'.tar.gz')
    with tarfile.open(good,'r:gz')as original,tarfile.open(p,'w:gz')as target:
        for member in original:
            data=original.extractfile(member).read()if member.isfile()else None
            if label=='missing-body'and member.isfile():continue
            if label=='changed-body'and member.isfile():data=bytes([data[0]^1])+data[1:]
            target.addfile(member,io.BytesIO(data)if data is not None else None)
            if label=='duplicate-member'and member.isfile():target.addfile(member,io.BytesIO(data))
        if label=='link-member':
            m=tarfile.TarInfo('original/fixture/hostile');m.type=tarfile.SYMTYPE;m.linkname='/outside';target.addfile(m)
        if label=='parent-traversal':
            m=tarfile.TarInfo('original/fixture/../escape');m.size=0;target.addfile(m,io.BytesIO())
    try:verify(p,inventory)
    except (AssertionError,KeyError)as e:cases.append(dict(case=label,rejected=True,errorType=type(e).__name__,archiveSha256=sha(p)))
    else:raise AssertionError(label)
assert len(cases)==5 and tree(source)==inventory['fixture']
(O/'VALIDATION.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    validArchiveReview=result,validArchiveSha256=sha(good),rejectedCases=cases,
    allOriginalFixtureBodiesAndMetadataRetained=True,sourceSha256=sha(Path(__file__).with_name('scope_tar.py')),
    fixtureInventory=inventory),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,validRoundTrip=True,rejectedCases=len(cases))))
