from pathlib import Path
import datetime,json,shutil,subprocess,sys,tarfile,zipfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'batch-wire-validation-worktree';P=Path(__file__).resolve().parent;A=W/'evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/local-qualification-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
unit=json.loads((B/'batch-wire-validation-local-tests-r1/RESULT.json').read_text());parity=json.loads((B/'batch-wire-validation-parity-r1/RESULT.json').read_text());classes=json.loads((B/'batch-wire-validation-local-tests-r1/CLASS_COMPARISON.json').read_text())
assert unit['passed']and unit['junit']==dict(tests=39,failures=0,errors=0,skipped=0)and parity['passed']and parity['allRowsByteIdentical']and parity['rows']==10839 and classes['onlyIntendedClassChanges']
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()=='b5ce776efd23566f18f7c5344ad551cc341c1036'
source=W/'cluster/src/main/java/io/vectormatch/cluster/RetentionWireV3.java';assert sha(source)==unit['sourceSha256']
inputs=B/'batch-wire-validation-qualification-inputs-r1';assert not inputs.exists();inputs.mkdir()
for n in('RetentionWireV3.java',):shutil.copy2(W/'cluster/src/main/java/io/vectormatch/cluster'/n,inputs/n)
shutil.copy2(W/'core/src/main/java/io/vectormatch/core/MatchingEngine.java',inputs/'MatchingEngine.java')
shutil.copy2(W/'cluster/build/classes/java/main/io/vectormatch/cluster/RetentionWireV3.class',inputs/'candidate-RetentionWireV3.class')
jar=B/'verified-archive-handoff-artifact-preparation-r1/lib/cluster-0.1.0-SNAPSHOT.jar'
with zipfile.ZipFile(jar)as z:(inputs/'baseline-RetentionWireV3.class').write_bytes(z.read('io/vectormatch/cluster/RetentionWireV3.class'))
(inputs/'source.diff').write_bytes(subprocess.check_output(['git','-C',str(W),'diff','HEAD^','HEAD','--','cluster/src/main/java/io/vectormatch/cluster/RetentionWireV3.java']))
names=[P.name,'batch-wire-validation-local-tests-r1','batch-wire-validation-parity-preparation-r1','batch-wire-validation-parity-r1',inputs.name,'dispatch-capacity-scope-tar-preparation-r1'];before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-local-compatibility-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for n in('README.md','docs/BATCH_WIRE_VALIDATION_CANDIDATE_V3.md'):
 if n=='README.md':continue
 p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/n,p)
(A/'README.md').write_text('''# Immutable business-batch encoding:local compatibility qualification

Candidate sourceb5ce776e removes one redundant construction of an already validated immutable BusinessBatch. Existing constructor,nested canonical encoding and complete decode/re-encoding guards remain. No shared mutable cache,trusted-wire bypass or wire format change.

Complete actual Mac forced test sources/commands/logs/JUnit:39 tests,zero failure/error/skip. Full differential harness/source/class/commands and both CSV bodies:10,839 byte-identical result rows covering4,096 valid batches,4,096 deterministic mutated wires,2,639 truncations,2 oversized wires and6 invalid constructors. All227 application class pins match the baseline except RetentionWireV3.class;the full before/after class bytes and actual source diff are included. Baseline complete JAR/class bodies remain in the already qualified handoff/CI archives;their SHA identities are pinned here. This finite compatibility evidence is not an independent matching algorithm,Linux CI or a performance improvement. No new application order or workload was executed. The candidate remains separate from the deployed benchmark artifact and undeployed V4 branch.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,candidateSourceCommit='b5ce776efd23566f18f7c5344ad551cc341c1036',junit=unit['junit'],parity=parity,all227ClassBodiesCompared=True,onlyChangedClass='io/vectormatch/cluster/RetentionWireV3.class',localMacOnly=True,noPerformanceClaim=True),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
