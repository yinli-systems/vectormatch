from pathlib import Path
import ast,hashlib,json,shutil,sys,tarfile
B=Path(__file__).resolve().parent.parent;case=sys.argv[1];cases=('c1','d1','c2','d2');assert case in cases;prefix='batch-wire-6000';candidate=case.startswith('d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qpath=B/'batch-wire-validation-qualification-private-proof-r1/PRIVATE_PUSH.json';q=json.loads(qpath.read_text());assert q['passed']and q['private']and q['restoredWholeScopeArchiveFromActualGitBlob']and q['allNestedOriginalCiFilesVerified']==786 and q['fixedPlanComparisonRate']==6000 and q['onlyRegisteredCases']==list(cases)
previous=cases[cases.index(case)-1]if case!='c1'else None
prior=None
if previous:
 prior=B/f'{prefix}-{previous}-private-proof-r1/PRIVATE_PUSH.json';p=json.loads(prior.read_text());assert p['passed']and p['private']and p['completeAuthenticatedAssetDownloadVerified']and p['comparisonContinuationPermitted']and p['nextRegisteredCase']==case
S=B/'verified-handoff-capacity-6000-d1-controller-preparation-r1';O=B/f'{prefix}-{case}-controller-preparation-r1';assert not O.exists();shutil.copytree(S,O)
metaPrefix='batch-wire-validation'if candidate else'verified-archive-handoff';M=B/(metaPrefix+'-linux-metadata-execution-r1');meta=json.loads((M/'actual-linux-observation.json').read_text());review=json.loads((M/'ROOT_REVIEW.json').read_text());assert review['passed']and meta['actualCodeFingerprint']==(q['codeFingerprint']if candidate else q['baselineCodeFingerprint'])
ci=qpath if candidate else B/'verified-archive-handoff-qualification-private-proof-r1/PRIVATE_PUSH.json'
for p,n in[(qpath,'comparison-qualification-private.json'),(ci,'ci-private-proof.json'),(M/'actual-linux-observation.json','linux-metadata.json'),(M/'ROOT_REVIEW.json','linux-metadata-root-review.json')]:shutil.copy2(p,O/n)
if prior:shutil.copy2(prior,O/'preceding-arm-private.json')
r=json.loads((O/'release.json').read_text());r.update(caseId=case,sourceCommit=meta['sourceCommit'],codeFingerprint=meta['actualCodeFingerprint'],scope='IMMUTABLE_BATCH_ENCODER_'+case.upper()+'_6000_20S',ciPrivateProofSha256=sha(O/'ci-private-proof.json'),comparisonQualificationPrivateSha256=sha(O/'comparison-qualification-private.json'),verifiedArchiveHandoffExpected=True,writerPhaseTimingsExpected=True,higherLoadPermitted=False,instrumentationEnabled=False)
assert r['derivedPlan']==meta['dispatchCapacityConfigs']['6000']['rotating']['plan']and r['parentJvmArguments']==['--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m']
if candidate:
 old='/opt/vectormatch-cpu/tools/cpu-verified-archive-handoff-metadata-r1';new='/opt/vectormatch-cpu/tools/cpu-batch-wire-validation-metadata-r1';r['artifacts']={p.replace(old,new):row for p,row in r['artifacts'].items()}
 for key in('classPath','nodeClassPath'):r[key]=[p.replace(old,new)for p in r[key]]
 pins=json.loads((B/'batch-wire-validation-linux-metadata-preparation-r1/metadata-config.json').read_text())['rows']
 r['artifacts']={p:dict(bytes=pins['lib/'+Path(p).name]['bytes'],sha256=pins['lib/'+Path(p).name]['sha256'])for p in r['artifacts']}
if prior:r.update(precedingCase=previous,precedingPrivateSha256=sha(O/'preceding-arm-private.json'))
(O/'release.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
s=(O/'first_pilot.py').read_text().replace('verified-handoff-capacity-6000-d1-r1',prefix+'-'+case+'-r1').replace("CASE='d1';CAPSULE=True","CASE="+repr(case)+";CAPSULE=True;CODECOPT="+repr(candidate))
needle='        idle=m.strict_idle(b);protected=m.protected_state(b,r)'
gate="""        comparison=json.loads((HERE/'comparison-qualification-private.json').read_text())
        require(digest(HERE/'comparison-qualification-private.json')==r['comparisonQualificationPrivateSha256']and comparison['passed']and comparison['private']and comparison['restoredWholeScopeArchiveFromActualGitBlob']and comparison['allNestedOriginalCiFilesVerified']==786 and comparison['fixedPlanComparisonRate']==6000 and comparison['onlyRegisteredCases']==['c1','d1','c2','d2']and comparison['samplerSevenBodiesUnchanged'],'Exact actual CI9/artifact/Linux and registered fixed comparison qualification required')
        require(r['parentJvmArguments']==['--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m']and r['instrumentationEnabled']is False,'Fixed uninstrumented256MiB parent required')
"""
assert s.count(needle)==1;s=s.replace(needle,gate+needle)
s=s.replace("'79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'if CAPSULE else'f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca'","'337dcfcd0a2373a5cfa394583669f3dcf7e53c9d6437bd17f0b78c96a54c50df'if CODECOPT else'79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'")
s=s.replace("previous['knownOutcomeQualified']","previous['comparisonContinuationPermitted']")
s=s.replace('Fresh120000@6000 registered common-sampler handoff retest','Fresh120000@6000 fixed immutable-batch encoder comparison')
(O/'first_pilot.py').write_text(s)
sampler=json.loads((O/'sampler-qualification-private.json').read_text());assert sampler['newComparisonPrefix']=='verified-handoff-capacity-6000'
for name,pin in q['controllerInputRows'].items():assert sha(O/name)==pin['sha256']and(O/name).stat().st_size==pin['bytes']
files={}
for p in sorted(O.iterdir()):
 if p.name in('FROZEN.json','source-package.tar.gz')or not p.is_file():continue
 if p.suffix=='.py':ast.parse(p.read_text())
 p.chmod(0o644);files[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p),mode=420)
(O/'FROZEN.json').write_text(json.dumps(dict(schemaVersion=1,files=files,caseId=case,onlySelectedOfferedRate=6000,predecessorCase=previous,encoderCandidate=candidate,verifiedArchiveHandoffExpected=True,writerPhaseTimingsExpected=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
with tarfile.open(O/'source-package.tar.gz','w:gz')as t:
 for name in list(files)+['FROZEN.json']:t.add(O/name,arcname=name,recursive=False)
print(json.dumps(dict(passed=True,caseId=case,codeFingerprint=r['codeFingerprint'],sourceFreezeSha256=sha(O/'FROZEN.json'),allSevenSamplerBodiesUnchanged=True)))
