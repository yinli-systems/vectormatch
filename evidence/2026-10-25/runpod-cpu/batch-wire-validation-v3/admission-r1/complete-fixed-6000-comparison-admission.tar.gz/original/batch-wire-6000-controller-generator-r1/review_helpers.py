from pathlib import Path
import ast,hashlib,json
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent
p=B/'batch-wire-6000-native-archive-preparation-r1/archive.py';s=p.read_text().replace("if case=='c1':names.append('batch-wire-6000-c1-archive-space-guard-r1')","if (B/f'batch-wire-6000-{case}-archive-space-guard-r1').is_dir():names.append(f'batch-wire-6000-{case}-archive-space-guard-r1')");p.write_text(s)
p=B/'batch-wire-6000-runner-r1/stage.py';s=p.read_text();needle='O.mkdir();assert json.loads';assert s.count(needle)==1;s=s.replace(needle,"O.mkdir();assert json.loads((B/'batch-wire-6000-admission-private-proof-r1/PRIVATE_PUSH.json').read_text())['passed'];assert json.loads");p.write_text(s)
rows={};families=json.loads((P/'HELPERS.json').read_text())['helperFamilies']
for suffix in families:
 for p in sorted((B/('batch-wire-6000-'+suffix)).rglob('*')):
  if not p.is_file()or'__pycache__'in p.parts:continue
  if p.suffix=='.py':ast.parse(p.read_text())
  rows[str(p.relative_to(B))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
q=json.loads((B/'batch-wire-validation-qualification-private-proof-r1/PRIVATE_PUSH.json').read_text());assert q['passed']and q['fixedPlanComparisonRate']==6000
controller=B/'batch-wire-6000-c1-controller-preparation-r1';release=json.loads((controller/'release.json').read_text());assert release['codeFingerprint']==q['baselineCodeFingerprint']and release['verifiedArchiveHandoffExpected']and not release['instrumentationEnabled']
for n,pin in q['controllerInputRows'].items():assert hashlib.sha256((controller/n).read_bytes()).hexdigest()==pin['sha256']
# Both binary plans agree before C1;the helper never picks a faster resource profile for D.
metas=[json.loads((B/(prefix+'-linux-metadata-execution-r1/actual-linux-observation.json')).read_text())for prefix in('verified-archive-handoff','batch-wire-validation')]
assert metas[0]['dispatchCapacityConfigs']==metas[1]['dispatchCapacityConfigs']and metas[0]['profileSha256']==metas[1]['profileSha256']and metas[0]['readinessContract']==metas[1]['readinessContract']
result=dict(passed=True,allPythonSourcesParse=True,helperFamilies=len(families),sourcePins=rows,allSevenControllerSamplerBodiesUnchanged=True,baselineAndCandidatePlansAndReadinessIdentical=True,optionalSpaceFailureReceiptOnlyWhenItExists=True,nativeFreeSpaceFloorsUnchanged=True,bothArtifactsVerifiedArchiveHandoff=True,stageRequiresActualPrivateAdmissionRestoration=True,onlyRate6000=True,cases=['c1','d1','c2','d2'],noNativeOrOrdersExecuted=True,sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(P/'HELPER_REVIEW.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='sourcePins'}))
