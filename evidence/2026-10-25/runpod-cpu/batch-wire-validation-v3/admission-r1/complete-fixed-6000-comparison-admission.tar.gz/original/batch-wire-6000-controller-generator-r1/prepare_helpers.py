from pathlib import Path
import ast,json,shutil
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent;old='verified-handoff-capacity-6000';new='batch-wire-6000'
suffixes=['controller-review-preparation-r1','runner-r1','root-review-preparation-r1','schema-audit-preparation-r1','workload-audit-preparation-r1','bottleneck-preparation-r1','recovery-preparation-r1','maintenance-phases-preparation-r1','native-archive-preparation-r1','native-private-proof-preparation-r2','local-duplicate-retirement-preparation-r1','cache-precondition-preparation-r1']
for suffix in suffixes:
 dst=B/(new+'-'+suffix);assert not dst.exists();shutil.copytree(B/(old+'-'+suffix),dst)
 for p in dst.rglob('*.py'):
  s=p.read_text().replace(old,new).replace('verified-archive-handoff-v3/capacity-6000-arm-','batch-wire-validation-v3/arm-').replace('handoff-capacity-6000-','batch-wire-6000-')
  # Decoder artifacts track the actual compared C/D distributions,with the same public wire API.
  s=s.replace('verified-archive-handoff-artifact-preparation-r1/lib','batch-wire-validation-artifact-preparation-r1/lib').replace('writer-phase-timing-artifact-preparation-r1/lib','verified-archive-handoff-artifact-preparation-r1/lib')
  if suffix=='root-review-preparation-r1'and p.name=='review.py':
   s=s.replace("'79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'if case.startswith('d')else'f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca'","'337dcfcd0a2373a5cfa394583669f3dcf7e53c9d6437bd17f0b78c96a54c50df'if case.startswith('d')else'79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'")
  if suffix=='controller-review-preparation-r1':s=s.replace("sampler['newComparisonPrefix']=='"+new+"'","sampler['newComparisonPrefix']=='"+old+"'")
  if suffix=='native-archive-preparation-r1':
   s=s.replace("names.extend(['exitwait-local-sparse-cache-r1','verified-handoff-capacity-admission-preparation-r1',f'{prefix}-admission-private-proof-r1'])","names.extend(['batch-wire-validation-qualification-private-proof-r1','verified-handoff-capacity-6000-admission-private-proof-r1'])")
   s=s.replace("'verified-archive-handoff-qualification-private-proof-r1','verified-archive-handoff-qualification-private-proof-preparation-r1'","'batch-wire-validation-qualification-private-proof-r1','batch-wire-validation-qualification-private-proof-preparation-r1'")
   s=s.replace("R/'docs/VERIFIED_HANDOFF_CAPACITY_V3.md'","R/'docs/BATCH_WIRE_VALIDATION_COMPARISON_V3.md'")
   s=s.replace("Fresh120,000 IOC arrivals@6000/s", "Fresh120,000 IOC arrivals@6000/s")
  if suffix=='native-private-proof-preparation-r2':
   s=s.replace("cases=('d1',)","cases=('c1','d1','c2','d2')")
   s=s.replace("permitted=known and root['windowConfirmationFraction']>=.99 and root['allArrivalP99Ns']is not None and root['allArrivalP99Ns']<=1000000000","permitted=False # Fixed comparison never authorizes capacity escalation\ncontinuation=root['nativeControlPassed']and root['schedulerTimingValid']and root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0 and root['confirmedAcceptedUniqueOrders']+root['notSent']==120000")
   s=s.replace('nextRegisteredRate=7000 if permitted else None','nextRegisteredRate=None').replace('nextRegisteredCase=nextCase if known else None','nextRegisteredCase=nextCase if continuation else None,comparisonContinuationPermitted=continuation')
  # Both artifacts use the verified archive handoff;only the encoder differs.
  s=s.replace("schema['verifiedArchiveHandoffExpected']==case.startswith('d')","schema['verifiedArchiveHandoffExpected']is True").replace("r['verifiedArchiveHandoffExpected']==case.startswith('d')","r['verifiedArchiveHandoffExpected']is True").replace("verifiedArchiveHandoffExpected=case.startswith('d')","verifiedArchiveHandoffExpected=True")
  p.write_text(s);ast.parse(s)
(P/'HELPERS.json').write_text(json.dumps(dict(passed=True,prefix=new,helperFamilies=suffixes,fixedRate=6000,baselineCodeFingerprint='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f',candidateCodeFingerprint='337dcfcd0a2373a5cfa394583669f3dcf7e53c9d6437bd17f0b78c96a54c50df',noNativeOrdersExecuted=True),indent=2)+'\n');print('twelve fixed comparison helper families prepared')
