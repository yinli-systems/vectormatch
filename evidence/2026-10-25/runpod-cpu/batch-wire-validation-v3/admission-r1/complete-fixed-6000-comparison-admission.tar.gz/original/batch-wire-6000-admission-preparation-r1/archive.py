from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;A=R/'evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/admission-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
G=B/'batch-wire-6000-controller-generator-r1';h=json.loads((G/'HELPER_REVIEW.json').read_text());assert h['passed']and h['allSevenControllerSamplerBodiesUnchanged']
for name,pin in h['sourcePins'].items():assert(B/name).stat().st_size==pin['bytes']and sha(B/name)==pin['sha256']
review=json.loads((B/'batch-wire-6000-c1-controller-review-r1/SOURCE_REVIEW.json').read_text());assert review['passed']and review['pureFixtureGuards']==26
names=[P.name,G.name,'batch-wire-6000-c1-controller-preparation-r1','batch-wire-6000-c1-controller-review-r1','batch-wire-validation-qualification-private-proof-r1','verified-handoff-client-jfr-7500-reporting-private-proof-r1','dispatch-capacity-scope-tar-preparation-r1'];names.extend('batch-wire-6000-'+suffix for suffix in json.loads((G/'HELPERS.json').read_text())['helperFamilies'])
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-fixed-6000-comparison-admission.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(G/'HELPER_REVIEW.json',A/'HELPER_REVIEW.json')
p=A/'published/docs/BATCH_WIRE_VALIDATION_COMPARISON_V3.md';p.parent.mkdir(parents=True);shutil.copy2(R/'docs/BATCH_WIRE_VALIDATION_COMPARISON_V3.md',p)
(A/'README.md').write_text('''# Fixed6000/s C1/D1/C2/D2 admission

Baseline79e5a932 versus actual CI9 candidate337dcfcd;both verified archive handoff.120,000 scheduled synthetic IOC buys over20s per fresh lineage. Fixed leader0,sync2,W128/Q64,read128/page32/batch4/chunk6144,owner1ms/driver100us,256MiB heaps,readiness,cache preconditioning,JDK/host/cgroups and all seven qualified control/lifecycle bodies. No JFR or resource-profile change. Failed7500 progression stays closed;no higher load.

Full original admission sources include C1 frozen controller/source package,strict26-guard fixture review,all12 helper families and their source pins,actual CI9/artifact/Linux/private proof and previous diagnostic closure. Actual qualification TAR and all786 nested CI9 files are already restored from private Git and verified;the sibling qualification package retains those complete bodies. Every next arm requires full actual native/raw private-asset/member closure and known partition reconciliation;valid overload is retained,UNKNOWN/control failures stop. Only C1 is frozen at admission;later controllers must bind the preceding exact private proof before generation. All native/raw free-space floors remain. Optional space-failure receipts are included only when they exist. Stage requires restoration of this exact private admission package. This is prospective registration,no new workload or performance claim.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,cases=['c1','d1','c2','d2'],rate=6000,noNativeOrOrdersExecuted=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
