"""One fresh rotating fine-capacity native qualification; reviewed ownership/closure machinery reused byte-for-byte."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,platform,shutil,socket,stat,sys
HERE=Path(__file__).resolve().parent
CASE='c1';CAPSULE=True;CODECOPT=False
PREP=Path('/opt/vectormatch-cpu/experiments/batch-wire-6000-c1-r1')

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(value,message):
    if not value:raise RuntimeError(message)

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--freeze-sha256',required=True);p.add_argument('--start-new',action='store_true');a=p.parse_args()
    require(HERE==PREP,'Exact new synthetic namespace required')
    frozen=HERE/'FROZEN.json';require(digest(frozen)==a.freeze_sha256,'Root-frozen source manifest differs')
    pins=json.loads(frozen.read_text())
    for n,row in pins['files'].items():
        q=HERE/n;require(q.is_file()and not q.is_symlink()and q.stat().st_size==row['bytes']and digest(q)==row['sha256']and stat.S_IMODE(q.stat().st_mode)==row['mode'],'Source/package body differs: '+n)
    spec=importlib.util.spec_from_file_location('cpu_read_window32_abab',HERE/'cpu_read_window32_abab.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    require(digest(m.__file__)=='11d189a72db4de10177015cd1fbab760d73a71d18c979327135ce3a8d7764330','Original reviewed lifecycle source differs')
    m.JOB=PREP/'attempt-6000';m.PAIR=m.JOB/'idle-arm';m.ARM=1;m.WINDOWS=[128];m.READ_WINDOW_ORDER=(128,);m.OWNER_PARK_ORDER=(1000000,)
    # PREP inside the original module remains its original path solely for the original absence/boot baseline.
    exec(compile((HERE/'capacity_validators.py').read_text(),str(HERE/'capacity_validators.py'),'exec'),m.__dict__)
    release_path=HERE/'release.json';release=json.loads(release_path.read_text());m.FROZEN_RELEASE_SHA=digest(release_path)
    m.SOURCE_COMMIT=release['sourceCommit'];m.CODE_FINGERPRINT=release['codeFingerprint']
    from readiness_validation import validate_readiness
    original_validate=m.validate_result
    def validate_with_readiness(b,registry,r):
        result=original_validate(b,registry,r)
        cfg=m.json_bounded(b,m.PAIR/'load/configuration.json');warm=m.json_bounded(b,m.PAIR/'preload-warmup.json');reg=m.json_bounded(b,m.PAIR/'registration.json')
        require(reg['allMemberStartupReadinessRequired']is True and reg['allMemberPreloadReadinessRequired']is True and reg['readinessQuietPeriodNs']==2000000000 and reg['readinessDeadlineNs']==45000000000,'Actual application readiness registration differs')
        nodes={member:next(row['identity']['pid']for row in registry.records.values()if row['role']=='window-128-node-'+str(member))for member in range(3)}
        first=m.json_bounded(b,m.PAIR/'startup-readiness.json');last=m.json_bounded(b,m.PAIR/'preload-readiness.json');reports=[validate_readiness(doc,nodes,cfg['scheduledOriginMonotonicNs'])for doc in [first,last]]
        require(first['endedMonotonicNs']<=warm['startedMonotonicNs']and warm['endedMonotonicNs']<=last['startedMonotonicNs'],'Actual startup/setup/warmup/preload readiness order differs')
        for value in [reg,cfg,m.json_bounded(b,m.PAIR/'capacity-correctness-result.json')]:require(value['fineDispatchCapacityPreset']is True and value['dispatchOrderPolicy']=='ROTATING_CONTINUE','Actual fine dispatch configuration differs')
        require(m.json_bounded(b,m.PAIR/'load/load-result.json')['dispatchOrderPolicy']=='ROTATING_CONTINUE','Actual source policy differs')
        result['actualAllMemberReadinessGates']=reports;return result
    m.validate_result=validate_with_readiness
    base=m.load_base()
    def parent_argv(r):
        return [r['java'],'-Dvectormatch.retention.idleMaxParkNs=100000','-Dvectormatch.retention.ownerPollMaxParkNs=1000000']+r['parentJvmArguments']+['-cp',':'.join(r['classPath']),m.MAIN,str(m.PAIR),'read128-dispatch-capacity','rotating','6000','42000']
    def preflight(b,r):
        require(platform.system()=='Linux'and platform.machine()=='x86_64'and socket.gethostname()=='33ace3d92505'and os.geteuid()==0,'Exact Linux/root/current CPU required')
        b.no_links(PREP);require(not m.JOB.exists()and not m.PAIR.exists(),'Fresh only; no rerun or resume')
        for n,row in pins['files'].items():
            q=HERE/n;b.no_links(q);require(q.stat().st_size==row['bytes']and digest(q)==row['sha256'],'Staged source changed before launch')
        require(digest(r['java'])==r['javaExecutableSha256']and digest(Path(r['java']).parents[1]/'release')==r['jdkReleaseSha256'],'Actual pinned JDK differs')
        for n,row in r['artifacts'].items():
            q=Path(n);b.no_links(q);require(q.stat().st_size==row['bytes']and digest(q)==row['sha256'],'Actual new installed JAR differs')
        observation=json.loads((HERE/'linux-metadata.json').read_text());review=json.loads((HERE/'linux-metadata-root-review.json').read_text())
        require(review['passed']and review['actualLinuxPlansMatchLocal']and review['allNineActualLoadedOriginsMatchStagedJars']and review['strictOwnedPidAbsentAfterWait']and review['observationSha256']==digest(HERE/'linux-metadata.json'),'Actual Linux metadata closure differs')
        require(observation['actualCodeFingerprint']==r['codeFingerprint']and observation['profileSha256']==r['profileFingerprint']and observation['dispatchCapacityConfigs']['6000']['rotating']['plan']==r['derivedPlan'],'Actual Linux selected plan/code differs')
        require(r['derivedPlan']['arrivals']==120000 and r['derivedPlan']['maxReadOnlyInFlight']==128 and r['derivedPlan']['eventFetchCount']==32 and r['derivedPlan']['admissionRejections']==[],'Exact finite codec admission differs')
        sampler=json.loads((HERE/'sampler-qualification-private.json').read_text())
        require(digest(HERE/'sampler-qualification-private.json')==r['samplerQualificationPrivateSha256']and sampler['passed']and sampler['private']and sampler['restoredWholeScopeArchiveFromActualGitBlob']and sampler['controllerBridgeQualified']and sampler['newComparisonPrefix']=='verified-handoff-capacity-6000'and sampler['initialCampaignIncompletePreserved']and sampler['actualOwnedPidfdProbePassed'],'Exact common qualified sampler and preserved invalid campaign required')
        require(r['processIdentitySamplerPolicy']=='proc-directory-stat-cmdline-stat-exit-wait-v2'and all(digest(HERE/n)==pin['sha256']and(HERE/n).stat().st_size==pin['bytes']for n,pin in sampler['controllerInputRows'].items()),'All seven common sampler/lifecycle source bodies must match private qualification')
        require(sampler['onlyRegisteredRate']==6000 and sampler['newComparisonPrefix']=='verified-handoff-capacity-6000','Exact prospective capacity admission required')
        if sampler['priorRate'] is not None:
            prior=json.loads((HERE/'curve-prior-private.json').read_text())
            require(digest(HERE/'curve-prior-private.json')==r['curvePriorPrivateSha256']and prior['passed']and prior['private']and prior['completeAuthenticatedAssetDownloadVerified']and prior['finiteProgressionPermitted']and prior['nextRegisteredRate']==6000 and prior['codeFingerprint']==r['codeFingerprint'],'Previous actual candidate point must permit this rate')
        qualified=json.loads((HERE/'handoff-qualification-private.json').read_text());ci=json.loads((HERE/'ci-private-proof.json').read_text())
        timing=json.loads((HERE/'timing-comparison-private.json').read_text());storage=json.loads((HERE/'asset-storage-qualified.json').read_text())
        require(digest(HERE/'handoff-qualification-private.json')==r['handoffQualificationPrivateSha256']and qualified['passed']and qualified['private']and qualified['restoredWholeScopeArchiveFromActualGitBlob']and qualified['fixedPlanComparisonRate']==4000,'Full private handoff qualification required')
        require(digest(HERE/'ci-private-proof.json')==r['ciPrivateProofSha256']and ci['passed']and ci['private']and ci['allTestTasksActuallyExecuted']and ci['forcedCiSourceCommit']==r['sourceCommit']and ci['junit']==dict(tests=394 if CAPSULE else 390,failures=0,errors=0,skipped=0),'Actual forced CI private evidence required')
        require(digest(HERE/'timing-comparison-private.json')==r['timingComparisonPrivateSha256']and timing['passed']and timing['private']and timing['actualRestorationDirectlyFromCommittedGitBlobsVerified'],'All four original timing arms must be privately restored/verified first')
        require(digest(HERE/'asset-storage-qualified.json')==r['assetStorageQualifiedSha256']and storage['passed']and storage['private']and storage['draft']and storage['completeAuthenticatedDownloadVerified']and storage['releaseId']==423510304,'Complete private raw asset upload/download qualification required')
        require(r['caseId']==CASE and r['writerPhaseTimingsExpected']is True and r['verifiedArchiveHandoffExpected']==CAPSULE and r['higherLoadPermitted']is False,'Exact registered case required')
        require(r['codeFingerprint']==('337dcfcd0a2373a5cfa394583669f3dcf7e53c9d6437bd17f0b78c96a54c50df'if CODECOPT else'79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'),'Exact selected artifact required')
        if r.get('precedingCase'):
            previous=json.loads((HERE/'preceding-arm-private.json').read_text())
            require(digest(HERE/'preceding-arm-private.json')==r['precedingPrivateSha256']and previous['passed']and previous['private']and previous['allOriginalNativeAndRawEvidencePushed']and previous['completeAuthenticatedAssetDownloadVerified']and previous['comparisonContinuationPermitted']and previous['caseId']==r['precedingCase']and previous['nextRegisteredCase']==CASE,'Full original/private preceding arm closure required')
        comparison=json.loads((HERE/'comparison-qualification-private.json').read_text())
        require(digest(HERE/'comparison-qualification-private.json')==r['comparisonQualificationPrivateSha256']and comparison['passed']and comparison['private']and comparison['restoredWholeScopeArchiveFromActualGitBlob']and comparison['allNestedOriginalCiFilesVerified']==786 and comparison['fixedPlanComparisonRate']==6000 and comparison['onlyRegisteredCases']==['c1','d1','c2','d2']and comparison['samplerSevenBodiesUnchanged'],'Exact actual CI9/artifact/Linux and registered fixed comparison qualification required')
        require(r['parentJvmArguments']==['--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m']and r['instrumentationEnabled']is False,'Fixed uninstrumented256MiB parent required')
        idle=m.strict_idle(b);protected=m.protected_state(b,r)
        minimum=m.minimum_initial_free_bytes(r);require(shutil.disk_usage(m.ROOT).free>=minimum,'Full finite growth/archive/1GiB free-space budget required')
        require(b.memory_headroom()>=8*m.GIB,'8GiB fresh memory headroom required')
        return dict(passed=True,atUtc=b.now(),idle=idle,protectedOriginal=protected,noJavaStarted=True,minimumInitialFreeBytes=minimum,sourceFreezeSha256=a.freeze_sha256,scope='Fresh120000@6000 fixed immutable-batch encoder comparison;full raw private-asset closure before next case,no higher-load permission')
    m.parent_argv=parent_argv;m.preflight=preflight
    if not a.start_new:print(json.dumps(preflight(base,release)));return
    result=m.execute(base,release,release_path)
    print(json.dumps(dict(result,newArtifactSourceCommit=release['sourceCommit'],rate=6000,caseId=CASE,writerPhaseTimingsExpected=True,verifiedArchiveHandoffExpected=CAPSULE,higherLoadPermitted=False)))

if __name__=='__main__':main()
