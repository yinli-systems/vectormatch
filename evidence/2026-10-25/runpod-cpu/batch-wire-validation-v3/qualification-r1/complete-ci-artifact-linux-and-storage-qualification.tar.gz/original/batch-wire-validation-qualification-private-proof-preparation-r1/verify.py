from pathlib import Path
import datetime,hashlib,json,stat,subprocess,sys,tarfile,zipfile

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'batch-wire-validation-worktree';A=W/'evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/qualification-r1'
O=B/'batch-wire-validation-qualification-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('codex/batch-wire-validation-once',):
    assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo=json.loads(subprocess.check_output(['gh','repo','view','yinli-systems/vectormatch','--json','isPrivate,nameWithOwner']));assert repo['isPrivate']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
assert closed['passed'] and closed['inventorySha256']==sha(A/'INVENTORY.json')
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories']
assert all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
    if row:
        meta,name=row.split(b'\t',1);assert meta.split()[1]==b'blob';blobs[name.decode()]=meta.split()[2].decode()
names=sorted(blobs);assert set(names)=={prefix+'/'+n for n in actual['files']}
assert git('hash-object','--',*[str(W/n)for n in names]).decode().splitlines()==[blobs[n]for n in names]
O.mkdir();restored=O/'restored.tar.gz';archiveName='complete-ci-artifact-linux-and-storage-qualification.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/'+archiveName],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes'] and sha(restored)==closed['archiveSha256']
members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview']
ci=json.loads((A/'FORCED_CI_REVIEW.json').read_text());jars=json.loads((A/'JAR_INPUTS.json').read_text())
assert ci['passed'] and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0) and ci['allTestTasksExecutedWithoutResultCache']
assert ci['sourceCommit']==jars['sourceCommit']==closed['sourceCommit']=='b5ce776efd23566f18f7c5344ad551cc341c1036'
assert not git('diff','--name-only',closed['sourceCommit'],head,'--','core/src','cluster/src','server/src','projector/src','bench/src','scripts','.github','web')
subprocess.run(['git','-C',str(W),'merge-base','--is-ancestor',closed['sourceCommit'],head],check=True)
with tarfile.open(restored)as outer:
    p='original/production-ci-attempt-9-collection-r1/'
    manifest=json.load(outer.extractfile(p+'remote-manifest.json'));seen=set();compiled={m:{} for m in ('core','cluster')}
    with tarfile.open(fileobj=outer.extractfile(p+'complete-code-compiled-tests-and-public-logs.tar.gz'),mode='r|gz')as nested:
        for item in nested:
            assert item.isfile() and item.name.startswith('original/');n=item.name[len('original/'):]
            assert n in manifest['originalFiles'] and n not in seen;seen.add(n);pin=manifest['originalFiles'][n];h=hashlib.sha256()
            f=nested.extractfile(item)
            for block in iter(lambda:f.read(1024**2),b''):h.update(block)
            assert item.size==pin['bytes'] and h.hexdigest()==pin['sha256'] and stat.S_IMODE(item.mode)==pin['mode'] and item.uid==pin['uid'] and item.gid==pin['gid']
            for module in compiled:
                start='compiled-and-tests/'+module+'/build/classes/java/main/'
                if n.startswith(start) and n.endswith('.class'):compiled[module][n[len(start):]]=dict(bytes=item.size,sha256=h.hexdigest())
    assert seen==set(manifest['originalFiles']) and compiled==jars['compiledClasses']
    for module,expected in compiled.items():
        n=module+'-0.1.0-SNAPSHOT.jar'
        with zipfile.ZipFile(outer.extractfile('original/batch-wire-validation-artifact-preparation-r1/lib/'+n))as z:
            values={n:dict(bytes=len(z.read(n)),sha256=hashlib.sha256(z.read(n)).hexdigest())for n in z.namelist()if n.endswith('.class')}
            assert values==expected
    meta=json.load(outer.extractfile('original/batch-wire-validation-linux-metadata-execution-r1/actual-linux-observation.json'))
    assert meta['actualCodeFingerprint']==closed['codeFingerprint']
    for origin in meta['actualClassOrigins']:
        pin=jars['files'][Path(origin['path']).name];assert origin['bytes']==pin['bytes'] and origin['sha256']==pin['sha256']
sampler=json.loads((B/'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json').read_text())
assert sampler['passed']and sampler['controllerBridgeQualified']and sampler['actualOwnedPidfdProbePassed']
bridge=B/'process-identity-exit-wait-controller-bridge-preparation-r1/inputs'
for name,pin in sampler['controllerInputRows'].items():assert(bridge/name).stat().st_size==pin['bytes']and sha(bridge/name)==pin['sha256']
storage=json.loads((A/'PRIVATE_ASSET_STORAGE_REVIEW.json').read_text())
assert storage['passed'] and storage['private'] and storage['draft'] and storage['completeAuthenticatedDownloadVerified']
restored.unlink()
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository=repo['nameWithOwner'],commit=head,
    candidateRemoteBranchVerified=True,allQualificationGitBlobsVerified=len(names),restoredWholeScopeArchiveFromActualGitBlob=True,
    allOriginalScopeMembersVerified=members,allNestedOriginalCiFilesVerified=len(seen),all227ActualCiAndJarClassBodiesReverified=True,
    sourceCommit=closed['sourceCommit'],codeFingerprint=closed['codeFingerprint'],allTestTasksActuallyExecuted=True,
    forcedCiSourceCommit=closed['sourceCommit'],junit=ci['junit'],ciSourceQualified=True,
    fixedPlanComparisonRate=6000,baselineCodeFingerprint='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f',samplerSevenBodiesUnchanged=True,controllerInputRows=sampler['controllerInputRows'],existingSameBodyNativePidfdProbePassed=True,newNativePidProbeExecuted=False,qualifiedSamplerProofSha256=sha(B/'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json'),onlyRegisteredCases=['c1','d1','c2','d2'],higherLoadPermitted=False,nativeBenchmarkExecuted=False,
    privateAssetStorageQualified=True,inventorySha256=sha(A/'INVENTORY.json'),closedSha256=sha(A/'CLOSED.json'),sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result))
