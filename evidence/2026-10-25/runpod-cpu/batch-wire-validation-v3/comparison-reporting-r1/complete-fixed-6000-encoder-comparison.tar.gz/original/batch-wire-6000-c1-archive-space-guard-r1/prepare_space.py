from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=Path(__file__).resolve().parent;assert not(O/'RESULT.json').exists()
# Evaluate only the registered read-only prefix;stop before archive creation/upload.
script=B/'batch-wire-6000-native-archive-preparation-r1/archive.py';source=script.read_text();prefix=source[:source.index('assert logical<12*1024**3')];oldargs=sys.argv;sys.argv=[str(script),'c1'];values={'__file__':str(script),'__name__':'__space_precheck__'}
try:exec(compile(prefix,str(script),'exec'),values)
finally:sys.argv=oldargs
logical=values['logical'];free=shutil.disk_usage(R).free;floor=1024**3+min(logical,1024**3)
pre=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),registeredArchiveSourceSha256=hashlib.sha256(script.read_bytes()).hexdigest(),logicalScopeBytes=logical,freeBytes=free,requiredFreeBytes=floor,archiveAdmissionPasses=free>=floor,noArchiveOrUploadStarted=True,nativeFreeSpaceFloorUnchanged=True)
(O/'PRECHECK.json').write_text(json.dumps(pre,indent=2,sort_keys=True)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','ls-remote','origin','refs/heads/codex/production-correctness-and-maintenance'],text=True).split()[0]==head
rows=[]
for n in subprocess.check_output(['git','ls-files','-z','--','evidence']).decode().split('\0'):
 if not n:continue
 p=R/n
 if not p.is_file():continue
 s=p.stat()
 if n.startswith(('evidence/2026-10-23/','evidence/2026-10-24/'))and s.st_blocks*512>=16*1024**2:rows.append((s.st_blocks*512,n))
selected=sorted(rows,reverse=True)[:20];assert len(selected)==20
pins=[]
for allocated,n in selected:
 p=R/n;s=p.stat();assert p.is_file()and not p.is_symlink()and all(not x.is_symlink()for x in p.parents)
 blob=subprocess.check_output(['git','rev-parse',head+':'+n],text=True).strip();actual=subprocess.check_output(['git','hash-object','--',n],text=True).strip();assert actual==blob
 assert subprocess.check_output(['git','cat-file','-t',blob],text=True).strip()=='blob'
 pins.append(dict(path=n,bytes=s.st_size,allocatedBytes=allocated,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),gitBlob=blob,mode=stat.S_IMODE(s.st_mode)))
info=Path(subprocess.check_output(['git','rev-parse','--git-path','info/sparse-checkout'],text=True).strip());info=info if info.is_absolute()else R/info;old=info.read_bytes();(O/'sparse-before').write_bytes(old)
patterns=old.decode();assert patterns.endswith('\n');patterns+=''.join('!/'+p['path']+'\n'for p in pins);assert all(('!/'+p['path']+'\n')not in old.decode()for p in pins)
(O/'VERIFIED_BEFORE.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),headCommit=head,remoteBranchVerified=True,files=pins,onlyHistoricalTrackedCheckoutCopies=True,allWorkingBodiesMatchActualHeadGitBlobs=True,gitObjectsAndRemoteEvidenceUnchanged=True,sparseBeforeSha256=hashlib.sha256(old).hexdigest(),freeBytesBefore=shutil.disk_usage(R).free),indent=2,sort_keys=True)+'\n')
info.write_text(patterns);result=subprocess.run(['git','sparse-checkout','reapply'],capture_output=True,text=True);(O/'sparse.stdout').write_text(result.stdout);(O/'sparse.stderr').write_text(result.stderr);assert result.returncode==0
assert all(not(R/p['path']).exists()for p in pins)and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
# The original complete bodies remain readable directly from the unchanged object database.
for p in pins:assert subprocess.check_output(['git','cat-file','-s',p['gitBlob']],text=True).strip()==str(p['bytes'])
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),headCommit=head,filesOmittedFromCheckout=len(pins),logicalBytes=sum(p['bytes']for p in pins),allocatedBytesBefore=sum(p['allocatedBytes']for p in pins),freeBytesAfter=shutil.disk_usage(R).free,noTrackedChanges=True,noRawEvidenceOrGitObjectsDeleted=True,restore='Remove the20 appended exact negative patterns from this worktree sparse-checkout file and reapply when sufficient space exists;all complete original bytes remain in the recorded private Git commit.',sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(precheck=pre,result=result)))
