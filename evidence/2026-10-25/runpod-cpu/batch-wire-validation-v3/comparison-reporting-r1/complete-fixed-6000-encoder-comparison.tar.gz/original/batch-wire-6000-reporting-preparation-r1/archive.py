from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;A=R/'evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/comparison-reporting-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=B/'batch-wire-6000-reporting-r1';c=json.loads((O/'COMPARISON.json').read_text());applied=json.loads((O/'APPLIED.json').read_text());assert c['passed']and applied['passed']and applied['indexSha256']==sha(R/'evidence/index.json')
names=[P.name,O.name,'batch-wire-6000-controller-generator-r1','batch-wire-6000-admission-preparation-r1','batch-wire-6000-admission-private-proof-r1','batch-wire-validation-qualification-private-proof-r1','batch-wire-6000-c1-archive-space-guard-r1','dispatch-capacity-scope-tar-preparation-r1']
for case in('c1','d1','c2','d2'):names.extend('batch-wire-6000-'+case+'-'+suffix+'-r1'for suffix in('private-proof','workload-audit','schema-audit','bottleneck','cut-recovery','maintenance-phases','duplicate-retirement'))
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-fixed-6000-encoder-comparison.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(O/'COMPARISON.json',A/'COMPARISON.json')
for n in('README.md','docs/BATCH_WIRE_VALIDATION_RESULTS_V3.md','docs/BATCH_WIRE_VALIDATION_COMPARISON_V3.md','docs/BATCH_WIRE_VALIDATION_CANDIDATE_V3.md','evidence/index.json'):
 p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(A/'README.md').write_text('''# Complete fixed6000/s C1/D1/C2/D2 encoder comparison

120,000 planned synthetic arrivals per fresh20s lineage. Baseline79e5a932 versus CI9 candidate337dcfcd;both verified archive handoff. COMPARISON.json retains every original outcome,paired global/conditional/after-offer p99,goodput,backlog,clearing intervals,maintenance/writer/RPC phases and whether the prospectively registered two-pair criterion passes. No single-pair promotion,statistical significance,sustained ceiling,5ms SLA or100M claim.

The full original report/analysis/source/proof scopes include all four complete private native closure receipts,trade/event/raw/schema/recovery audits,registered generator/admission sources,actual CI9 qualification proof,original/derived index,HTTP checks and the original local-space guard/failed selection/sparse-checkout receipts. Each sibling native asset retains all complete original raw/native/source/readiness/lifecycle bodies and is authenticated-downloaded and every member verified before the next arm. Historical working copies omitted after exact Git-blob proof remain recoverable from the unchanged private commit;raw evidence/Git objects are not deleted. All68 prior runs/30 cohorts remain;four observations in two distinct artifact cohorts make72/32. No stable marker or capacity escalation. The earlier failed7500 capacity curve remains stopped. GC is unavailable in this uninstrumented comparison. The separate V4 branch is undeployed and excluded.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,campaignComplete=True,records=72,cohorts=32,registeredPrimaryCriterionPassed=c['registeredTwoPairP99AndAfterOfferCriterionPassed'],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
