from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/comparison-reporting-r1';O=B/'batch-wire-6000-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
def package(p):
 inv=json.loads((p/'INVENTORY.json').read_text());closed=json.loads((p/'CLOSED.json').read_text());actual=tree(p);assert closed['passed']and closed['inventorySha256']==sha(p/'INVENTORY.json');assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
 prefix=p.relative_to(R).as_posix();blobs={}
 for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
  if row:
   meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
 paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
 return closed,len(paths)
closed,count=package(A);assert closed['campaignComplete']and closed['records']==72 and closed['cohorts']==32
for n in('README.md','docs/BATCH_WIRE_VALIDATION_RESULTS_V3.md','docs/BATCH_WIRE_VALIDATION_COMPARISON_V3.md','docs/BATCH_WIRE_VALIDATION_CANDIDATE_V3.md','evidence/index.json'):assert git('show',head+':'+n)==(R/n).read_bytes()==(A/'published'/n).read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+A.relative_to(R).as_posix()+'/complete-fixed-6000-encoder-comparison.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
c=json.loads((A/'COMPARISON.json').read_text());native=[]
for r in c['observations']:
 case=r['caseId'];p=B/f'batch-wire-6000-{case}-private-proof-r1/PRIVATE_PUSH.json';proof=json.loads(p.read_text());assert proof['passed']and proof['private']and proof['completeAuthenticatedAssetDownloadVerified']and proof['comparisonContinuationPermitted']
 point=A.parent/f'arm-{case}-native-r1';pc,pn=package(point);manifest=json.loads(git('show',head+':'+point.relative_to(R).as_posix()+'/ASSET_MANIFEST.json'));assert manifest==json.loads((point/'ASSET_MANIFEST.json').read_text())
 assert manifest['assetId']==proof['assetId']==r['assetId']and manifest['sha256']==proof['assetSha256']==r['assetSha256']and proof['allOriginalCompressedScopeMembersVerified']==pc['originalScopeReview']
 root=json.loads((point/'root-review/ROOT_REVIEW.json').read_text());assert root['nativeControlPassed']and root['allArrivalP99Ns']==r['p99Ns']and root['notSent']==r['notSent']and root['confirmedAcceptedUniqueOrders']==r['accepted']
 subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],head],check=True)
 native.append(dict(caseId=case,assetId=manifest['assetId'],assetSha256=manifest['sha256'],bytes=manifest['bytes'],previousFullAuthenticatedMemberProofCommit=proof['commit'],proofSha256=sha(p),committedNativeMetadataBlobsVerified=pn))
index=json.loads((R/'evidence/index.json').read_text());before=json.loads((B/'batch-wire-6000-reporting-r1/index-before.json').read_text());assert len(index['runs'])==72 and len(index['capacityCohorts'])==32 and index['runs'][:68]==before['runs']and index['capacityCohorts'][:30]==before['capacityCohorts']and index['capacity']==before['capacity']
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository='yinli-systems/vectormatch',commit=head,bothRemoteBranchesVerified=True,allReportingGitBlobsVerified=count,wholeActualReportingGitTarRestored=True,everyOriginalReportingMemberVerified=members,allFourNativeAssetsPreviouslyFullyAuthenticatedAndMemberVerified=True,native=native,campaignComplete=True,all68PriorRunsAnd30CohortsPreserved=True,records=72,cohorts=32,registeredPrimaryCriterionPassed=c['registeredTwoPairP99AndAfterOfferCriterionPassed'],pairs=c['pairs'],higherLoadPermitted=False,browserRenderVerified=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='native'}))
