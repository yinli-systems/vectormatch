from pathlib import Path
import datetime,hashlib,json,urllib.request
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'batch-wire-6000-reporting-r1';assert not(O/'APPLIED.json').exists();c=json.loads((O/'COMPARISON.json').read_text());assert c['passed']and c['all68PriorRunsAnd30CohortsPreserved'];assert(R/'evidence/index.json').read_bytes()==(O/'index-before.json').read_bytes()
rows=c['observations'];accepted=c['all120000AcceptedEachArm'];criterion=c['registeredTwoPairP99AndAfterOfferCriterionPassed'];ms=lambda n:'undefined'if n is None else f'{n/1e6:.6f}'
text='''# Immutable-batch encoding:fixed6000/s C1/D1/C2/D2

'''+('The four observations meet the registered descriptive criterion:all original orders accepted,and both candidate observations lower scheduled-to-confirmed p99 and offer-return-to-completion p99 relative to their paired controls.'if criterion else'The four observations do not meet the registered descriptive criterion of full acceptance and lower scheduled-to-confirmed AND offer-return-to-completion p99 in both pairs. The candidate is not promoted on this comparison.')+''' Two observations per artifact are not statistical significance,a sustained capacity ceiling or a millisecond SLA. All other phase/recovery tradeoffs remain visible.

[Prospective registration](BATCH_WIRE_VALIDATION_COMPARISON_V3.md) fixes6000 scheduled arrivals/s for20s,120,000 fresh one-unit IOC buys against one pre-funded seeded maker at10 ticks per arm. Baseline C is source23f9c070/artifact79e5a932. Candidate D is sourceb5ce776e/artifact337dcfcd. Both retain immutable verified archive handoff;only RetentionWireV3.class changes. D removes one redundant reconstruction of an already validated immutable BusinessBatch;constructor/UTF-8/nested encoding and complete canonical decode checks remain. No trusted-wire bypass,shared mutable cache or wire version change.

All four use the same prepaid CPU host/container/boot,JDK,cgroups,affinity,leader0,sync2,ROTATING_CONTINUE,W128/Q64,one physical session,three256MiB-heap JVMs,read128/page32/batch4/chunk6144,owner1ms and driver100us. Both2s original-PID readiness gates around setup/5s read-only warm-up,the same project-only advisory cache preconditioning,and all seven qualified control/lifecycle source bodies remain. No JFR or GC logging is added;GC and exact allocation costs are unavailable in this uninstrumented comparison. The original failed7500 capacity point and parent-only JFR diagnostic remain separate;8000 remains unexecuted and no higher load is authorized.

| Arm | Planned | Accepted/trades | NOT_SENT | In-window goodput/s | Global accepted-arrival p99,ms | Accepted-only p99,ms | After-offer p99,ms | Clearing comparable intervals |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for r in rows:text+=f"| {r['caseId'].upper()} | 120000 | {r['accepted']} | {r['notSent']} | {r['goodput']:.2f} | {ms(r['p99Ns'])} | {ms(r['conditionalP99Ns'])} | {ms(r['afterOfferP99Ns'])} | {r['clearing']}/{r['comparable']} |\n"
text+='''
Server rejection,observed UNKNOWN and final UNKNOWN are zero in all four observations;every accepted original is linked to exactly one unique trade and complete original outcomes reconcile. Global accepted-arrival p99 is undefined on any NOT_SENT;conditional successful results are never substituted for missing outcomes. Goodput counts confirmations inside the20s arrival window;after-offer latency includes client polling,raw evidence work,loopback transport,replication and service,not pure network RTT.

## Both paired differences

'''
for a,z in((rows[0],rows[1]),(rows[2],rows[3])):
 p99='undefined'if a['p99Ns']is None or z['p99Ns']is None else f"{(z['p99Ns']/a['p99Ns']-1)*100:+.2f}%"
 text+=f"{a['caseId'].upper()}→{z['caseId'].upper()}:global accepted-arrival p99 {p99};after-offer p99 {(z['afterOfferP99Ns']/a['afterOfferP99Ns']-1)*100:+.2f}%;maintenance wall {(z['maintenanceWallNs']/a['maintenanceWallNs']-1)*100:+.2f}%;in-window goodput {z['goodput']-a['goodput']:+.2f}/s.\n\n"
text+='''The primary criterion was fixed before C1. Neither a single faster pair nor a different successful-only metric is enough. Shared-host variation,JIT/startup,unrecorded GC,storage and scheduling are not uniquely isolated. These short observations cannot establish production tail latency,causal phase attribution or long-term stability. Separate reset lineages do not constitute continuous endurance.

| Phase,total seconds | C1 | D1 | C2 | D2 |
| --- | ---: | ---: | ---: | ---: |
'''
for label,fn in [('Maintenance wall',lambda r:r['maintenanceWallNs']),('Source-RPC interval union',lambda r:r['rpcIntervalUnionNs']),('Coordinator canonical archive verification',lambda r:r['coordinatorArchiveVerificationNs']),('Archive writer elapsed',lambda r:r['writerTotals']['archive']['ElapsedNs']),('Archive full readback,inside writer elapsed',lambda r:r['writerTotals']['archive']['ReadbackNs']),('Event writer elapsed',lambda r:r['writerTotals']['events']['ElapsedNs']),('All payload/receipt forces,inside writer elapsed',lambda r:sum(t['ForceNs']+t['ReceiptForceNs']for t in r['writerTotals'].values()))]:text+='| '+label+' | '+' | '.join(f'{fn(r)/1e9:.9f}'for r in rows)+' |\n'
text+='''
Concurrent RPC intervals are merged by monotonic union. Writer subphases are components of elapsed and must not be added again. Payload/receipt force(true),complete canonical readback and both durable tickets remain before either destructive ACK. This does not establish physical-host loss durability. Comparable clearing intervals exclude setup/source-exhausted drain and reconstruct recorded waiting,not exact physical queue occupancy. All original raw/native/source/readiness/lifecycle records remain available.

## Reproduction and limits

'''
for r in rows:text+=f"- [{r['caseId'].upper()} full original native/raw archive](../evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/arm-{r['caseId']}-native-r1/README.md),private commit`{r['privateCommit']}`,asset`{r['assetId']}`,SHA-256`{r['assetSha256']}`.\n"
text+='''
[Complete qualification](../evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/qualification-r1/README.md) preserves actual forced Linux CI9:394 Java tests including11 real PostgreSQL integrations,197 Python tests,failover/snapshot/restart and web checks,all zero failure/error/skip. All227 JAR classes match actual compiled bodies;only the intended class differs from C. All454 actual CI9/benchmark JDK file bodies match.39 forced local tests and10,839 byte-identical differential rows cover valid/mutated/truncated/oversized/invalid-constructor cases. This is finite compatibility evidence,not an independent matching algorithm. Hosted account billing remains unresolved;the green run uses the existing one-job CPU runner.

[Complete comparison derivation](../evidence/2026-10-25/runpod-cpu/batch-wire-validation-v3/comparison-reporting-r1/README.md) retains every analysis source/result,phase/recovery/trade audit,all private proofs,local-space guards and sparse-checkout receipts,original/derived index and HTTP checks. Every native asset is authenticated-downloaded in full and every member verified before the next arm. Space safeguards remain unchanged. Historical checkout copies omitted after exact Git-blob verification remain fully recoverable from the same private Git commit;original raw evidence/Git objects are not deleted.

All68 previous runs/30 cohorts remain unchanged;four observations in two artifact cohorts make72/32. No stable marker or inferred capacity curve is added. HTTP checks are not browser rendering. No independent physical-node isolation,5ms p99 SLA,production certification,HFT endorsement,100M continuity or external/funded-trading readiness is established. The separate asynchronous V4 branch remains undeployed and excluded.
'''
report=R/'docs/BATCH_WIRE_VALIDATION_RESULTS_V3.md';assert not report.exists();report.write_text(text);(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
p=R/'README.md';s=p.read_text().replace('The console retains68 runs/30 distinct cohorts.','The console retains72 runs/32 distinct cohorts.');anchor='The preceding [registered writer timing';assert s.count(anchor)==1
s=s.replace(anchor,'The [fixed6000/s immutable-batch encoding comparison](docs/BATCH_WIRE_VALIDATION_RESULTS_V3.md) closes C1/D1/C2/D2 with every original outcome retained. '+('Both paired global p99 and after-offer p99 decrease with all120,000 orders/trades accepted per arm;the registered descriptive criterion passes.'if criterion else'The registered two-pair full-acceptance/global-p99/after-offer criterion does not pass;the candidate is not promoted on this comparison.')+' These finite observations are not significance,a sustained ceiling or a millisecond SLA;all phase/recovery tradeoffs remain in the report.\n\n'+anchor);p.write_text(s)
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10)as response:body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body);assert status==200 and json.loads(body)==json.loads((O/'index-derived.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),indexSha256=sha(R/'evidence/index.json'),reportSha256=sha(report),httpStatus=status,httpBodySha256=hashlib.sha256(body).hexdigest(),browserRenderVerified=False,records=72,cohorts=32,registeredPrimaryCriterionPassed=criterion,higherLoadPermitted=False)
(O/'APPLIED.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
