from pathlib import Path
import copy,datetime,hashlib,json,urllib.request
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-handoff-capacity-reporting-r1';assert not O.exists()
pins={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 pins[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,sha256=sha(p));return json.loads(p.read_text())
old=read(R/'evidence/index.json');assert len(old['runs'])==64 and len(old['capacityCohorts'])==28
stop=read(B/'verified-handoff-capacity-stop-r1/STOP.json');assert stop['noEscalation'] and stop['unexecutedRates']==[8000]
startup=read(B/'verified-handoff-capacity-startup-reproduction-r1/RESULT.json');assert startup['passed'] and startup['exactOriginalAnalysisReproduced']
rows=[]
for rate in (6000,7000,7500):
 prefix=f'verified-handoff-capacity-{rate}-d1'
 root=read(B/(prefix+'-root-review-r1')/'ROOT_REVIEW.json')
 raw=read(B/(prefix+'-root-review-r1')/'RAW_AUDIT.json');ready=read(B/(prefix+'-root-review-r1')/'READINESS_REVIEW.json')
 proof=read(B/(prefix+'-private-proof-r1')/'PRIVATE_PUSH.json')
 diag=read(B/(prefix+'-bottleneck-r1')/'DIAGNOSIS.json');cut=read(B/(prefix+'-cut-recovery-r1')/'RECOVERY.json')
 schema=read(B/(prefix+'-schema-audit-r1')/'SCHEMA_AUDIT.json');phase=read(B/(prefix+'-maintenance-phases-r1')/'PHASES.json')
 work=read(B/(prefix+'-workload-audit-r1')/'WORKLOAD.json')
 L=B/(prefix+'-root-review-r1')/f'materialized/attempt-{rate}/idle-arm/load'
 cfg=read(L/'configuration.json');result=read(L/'load-result.json')
 assert all(j['passed']for j in (root,raw,ready,proof,diag,cut,schema,phase,work))
 assert root['nativeControlPassed'] and root['performanceQualified'] and result['schedulerTimingValid']
 assert proof['private'] and proof['completeAuthenticatedAssetDownloadVerified'] and proof['allOriginalNativeAndRawEvidencePushed']
 assert root['codeFingerprint']==proof['codeFingerprint']=='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'
 assert work['uniqueAcceptedOrders']==work['uniqueTradeEvents']==root['confirmedAcceptedUniqueOrders']
 assert root['plannedArrivals']==rate*20==root['confirmedAcceptedUniqueOrders']+root['notSent']
 assert root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0
 assert proof['finiteProgressionPermitted']==(rate<7500)
 rows.append(dict(rate=rate,planned=root['plannedArrivals'],accepted=root['confirmedAcceptedUniqueOrders'],notSent=root['notSent'],goodput=root['arrivalWindowGoodputPerSecond'],p50Ns=root['allArrivalP50Ns'],p99Ns=root['allArrivalP99Ns'],conditionalP99Ns=root['acceptedOrderConditionalP99Ns'],clearing=cut['intervalsReachingZeroRecordedWaiting'],comparable=cut['fullOfferedEquivalentCutIntervals'],queueHigh=diag['sampledQueueHighWater'],afterOfferP99Ns=diag['afterFirstPositiveOfferReturnP99Ns'],maintenanceWallNs=schema['maintenanceWallNs'],cycles=root['maintenanceCycles'],writerTotals=schema['writerTotals'],coordinatorArchiveVerificationNs=schema['coordinatorArchiveVerificationNs'],rpcIntervalUnionNs=phase['rpcIntervalUnionNs'],drainNs=result['lastKnownReplyDrainNs'],timestamp=cfg['scheduledOriginUTC'],privateCommit=proof['commit'],assetId=proof['assetId'],assetSha256=proof['assetSha256'],sourceCommit=proof['sourceCommit'],finiteProgressionPermitted=proof['finiteProgressionPermitted']))
assert rows[-1]['notSent']==74531 and rows[-1]['p99Ns']is None and rows[-1]['conditionalP99Ns']==4557860156
new=copy.deepcopy(old);cohort=dict(id='cpu-handoff-exitwait-capacity-20s',title='Verified handoff candidate capacity · 20s',updatedAt=rows[-1]['timestamp'],reportPath='docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md',configurationFingerprint='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f',scope='Three fresh20s lineages at6000/7000/7500 per second. Same artifact,leader0,sync2,three JVMs on one CPU host,loopback UDP,one physical session,128 workers,Q64,batch4,read128,page32,chunk6144,owner1ms,driver100us.7500 severe valid overload;8000 not executed. These are finite observations,not a sustained ceiling,an SLA or100M.',points=[])
for r in rows:
 identity=f"cpu-handoff-exitwait-capacity-{r['rate']}";p99=None if r['p99Ns']is None else r['p99Ns']/1e6
 new['runs'].append(dict(id=identity,label=f"Verified handoff capacity · {r['rate']:,}/s",scope=f"{r['planned']:,} planned;{r['accepted']:,} accepted;20s",model='One CPU host · three JVMs · loopback UDP · one physical session',commands=r['planned'],throughput=r['goodput'],p50Millis=None if r['p50Ns']is None else r['p50Ns']/1e6,p99Millis=p99,unknown=0,correctnessPassed=True,timestamp=r['timestamp'],durability='sync2;canonical forced payload/receipt readback before both ACKs',artifactPath=f"evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-{r['rate']}-arm-d1-native-r1/README.md",limitations=[f"notSent={r['notSent']};rejected/observed UNKNOWN/final UNKNOWN=0/0/0. All original outcomes reconcile;{r['accepted']} unique trades.",f"Comparable full-cut intervals clearing recorded waiting:{r['clearing']}/{r['comparable']}. Conditional accepted-only p99:{r['conditionalP99Ns']/1e6:.6f}ms. Global accepted-arrival p99 is undefined on any notSent.",'Same qualified sampler/readiness/cache preconditioning;fresh lineages are not continuous endurance. One short observation per rate;no statistical,physical-host isolation or millisecond SLA claim.']))
 cohort['points'].append(dict(id=identity,rate=r['rate'],workers=128,goodput=r['goodput'],p99Millis=p99,clientNotSent=r['notSent'],rejected=0,serverErrors=0,unknown=0,unresolved=0,allOfferedAcceptedP99Millis=p99,drainSeconds=r['drainNs']/1e9,classification='VALID_SEVERE_OVERLOAD'if r['notSent']else'FINITE_GATE_PASSED',peakBacklog=r['queueHigh'],valid=True,stable=None,windowSeconds=20))
new['capacityCohorts'].append(cohort)
assert new['runs'][:64]==old['runs'] and new['capacityCohorts'][:28]==old['capacityCohorts'] and new['capacity']==old['capacity']
assert len(new['runs'])==67 and len(new['capacityCohorts'])==29
text='''# Verified handoff candidate: finite capacity curve

The registered progression stops at7,500 scheduled orders/s because74,531 of150,000 planned arrivals are definitively NOT_SENT/QUEUE_FULL. This is a valid severe overload observation,not an invalid control or an optimization success.8,000/s was never executed. No lost arrival is replaced by an accepted-only percentile.

[Prospective registration](VERIFIED_HANDOFF_CAPACITY_V3.md) fixes candidate source23f9c070/code79e5a932,leader0,sync2,ROTATING_CONTINUE,read128/page32/batch4/chunk6144,owner1ms/driver100us,W128/Q64,one physical session,three JVMs on one CPU host with loopback UDP and256MiB heap each. All three use the same qualified sampler,original-PID readiness gates around5s read-only warm-up,and project-only cache preconditioning. No JFR was enabled. Each point is one fresh20s synthetic lineage,one seeded maker at10 ticks,one-unit IOC buys. All accepted load orders produce exactly one unique trade. Multi-level/cancel workloads and external trading are separate.

| Scheduled/s | Planned | Accepted/trades | NOT_SENT | In-window goodput/s | Global accepted-arrival p99,ms | Accepted-only p99,ms | Clearing comparable intervals |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for r in rows:
 text+=f"| {r['rate']} | {r['planned']} | {r['accepted']} | {r['notSent']} | {r['goodput']:.2f} | {r['p99Ns']/1e6 if r['p99Ns']is not None else 'undefined'} | {r['conditionalP99Ns']/1e6:.6f} | {r['clearing']}/{r['comparable']} |\n"
text+='''
All three points retain zero server rejection,observed UNKNOWN and final UNKNOWN.6,000/s is the highest tested rate clearing recorded waiting in every comparable full-cut interval.7,000/s passes the registered finite gate,but only35/43 intervals clear. Neither observation establishes a sustained capacity ceiling. At7,500/s the128-request window and8192-slot total client queue fill;the measured bottleneck is not thereby uniquely identified as client,network or service. Global accepted-arrival p99 is undefined because74,531 arrivals have no accepted result.4,557.860156ms describes only the75,469 accepted arrivals. In-window goodput counts67,229 confirmations within20s;the remaining accepted orders complete during drain.

## Startup and maintenance evidence

Before the first maintenance starts,all three have completed3,069 load orders and drained pending business. Read-only reconstruction from original CSV and cycle timestamps finds:

| Scheduled/s | Time to first maintenance,ms | Observed accepted/s before it | Mean offer-return→completion,ms | p99 offer-return→completion,ms | Mean admitted logical concurrency |
| ---: | ---: | ---: | ---: | ---: | ---: |
'''
for s in startup['observations']:
 text+=f"| {s['rate']} | {s['firstMaintenanceStartNs']/1e6:.6f} | {s['observedAcceptedRateBeforeFirstMaintenance']:.2f} | {s['meanPostOfferNs']/1e6:.6f} | {s['postOfferP99Ns']/1e6:.6f} | {s['meanAdmittedLogicalConcurrencyBeforeFirstMaintenance']:.3f} |\n"
text+='''
The7,500/s slow round trip is already present before archive maintenance. This interval includes client polling and synchronous raw-evidence work,loopback transport,replication/log storage and service. Startup/JIT/GC and shared-host variability remain unseparated. Submit-to-positive-offer p99 does not rise in that startup comparison. These observations justify instrumented diagnosis;they do not prove a pure network,window,disk or service cause. No queue-full loss occurs before first maintenance;the first7,500/s loss arrives2.311122277s after the scheduled origin.

| Phase,total seconds | 6000/s | 7000/s | 7500/s |
| --- | ---: | ---: | ---: |
'''
for name,fn in [('Maintenance wall',lambda r:r['maintenanceWallNs']),('Coordinator canonical archive verification',lambda r:r['coordinatorArchiveVerificationNs']),('Archive writer elapsed',lambda r:r['writerTotals']['archive']['ElapsedNs']),('Archive full readback,inside elapsed',lambda r:r['writerTotals']['archive']['ReadbackNs']),('Event writer elapsed',lambda r:r['writerTotals']['events']['ElapsedNs']),('All payload/receipt forces,inside writer elapsed',lambda r:sum(t['ForceNs']+t['ReceiptForceNs']for t in r['writerTotals'].values()))]:
 text+='| '+name+' | '+' | '.join(f'{fn(r)/1e9:.9f}'for r in rows)+' |\n'
text+='''
Writer subphases are not added to elapsed again. Complete payload canonical verification,force(true),full readback and receipt force remain before either destructive ACK. This does not establish storage survival after a physical-host loss. An asynchronous-maintenance implementation remains a separate candidate;it cannot alone explain the observed pre-maintenance slowdown.

## Reproduction and boundaries

'''
for r in rows:text+=f"- [{r['rate']}/s complete original native/raw package](../evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-{r['rate']}-arm-d1-native-r1/README.md),private commit`{r['privateCommit']}`,asset`{r['assetId']}`,SHA-256`{r['assetSha256']}`.\n"
text+='''
[Complete curve derivation](../evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-reporting-r1/README.md) retains reporting/diagnosis sources,original and derived UI index,all source pins,proofs,phase/recovery/trade audits and stop decision. Each native private asset was authenticated-downloaded in full and every original member verified before progression. All150,000 original7,500/s outcomes reconcile as75,469 accepted unique trades plus74,531 definite pre-offer queue refusals;the three final state snapshots agree. No failure is discarded or renamed noise. Candidate-codec checks are not an independent matching oracle or cold recovery.

The console preserves all64 previous runs/28 cohorts and appends3 runs in one distinct cohort,67/29. Existing historical three-Pod and other one-host curves remain separate. HTTP-data verification is not browser rendering. One observation per rate does not establish statistical significance,an optimization gain,independent physical-node isolation,hard realtime,a millisecond SLA,production certification,HFT endorsement,external/funded-trading readiness or any100M target. The next performance experiment requires a newly registered diagnostic protocol;the failed progression does not authorize8,000/s.
'''
assert all(p.stat().st_size==v['bytes']and sha(p)==v['sha256']for n,v in pins.items()for p in [R/n])
O.mkdir();(O/'index-before.json').write_bytes((R/'evidence/index.json').read_bytes());(O/'index-derived.json').write_text(json.dumps(new,indent=2,ensure_ascii=False)+'\n')
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),observations=rows,inputs=pins,all64PriorRunsAnd28CohortsPreserved=True,records=67,cohorts=29,stoppedAtRate=7500,unexecutedRates=[8000],higherLoadPermitted=False,sourceSha256=sha(Path(__file__)))
(O/'CURVE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(R/'docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md').write_text(text);(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
p=R/'README.md';s=p.read_text();s=s.replace('The console retains64 runs/28 distinct cohorts.','The console retains67 runs/29 distinct cohorts.');s=s.replace('The [candidate capacity protocol](docs/VERIFIED_HANDOFF_CAPACITY_V3.md) and [bounded asynchronous maintenance design](docs/ASYNC_MAINTENANCE_V4.md) define subsequent gates;neither is an executed higher-rate or V4 optimization result.','The [candidate capacity curve](docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md) now records6,000/7,000/7,500 per second:global p99208.34/317.32ms at the first two rates;the7,500/s point loses74,531 planned arrivals to QUEUE_FULL,so its global accepted-arrival p99 is undefined. Progression stops and8,000/s is unexecuted. The [bounded asynchronous maintenance design](docs/ASYNC_MAINTENANCE_V4.md) remains a separate,undeployed candidate.');p.write_text(s)
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10)as response:body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body);assert status==200 and json.loads(body)==new
applied=dict(passed=True,indexSha256=sha(R/'evidence/index.json'),reportSha256=sha(R/'docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md'),httpStatus=status,httpBodySha256=hashlib.sha256(body).hexdigest(),browserRenderVerified=False,records=67,cohorts=29)
(O/'APPLIED.json').write_text(json.dumps(applied,indent=2,sort_keys=True)+'\n');print(json.dumps(applied))
