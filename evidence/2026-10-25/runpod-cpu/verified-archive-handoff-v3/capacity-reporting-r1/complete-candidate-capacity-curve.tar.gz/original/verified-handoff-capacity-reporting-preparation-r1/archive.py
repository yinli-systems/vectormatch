from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-reporting-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=B/'verified-handoff-capacity-reporting-r1';c=json.loads((O/'CURVE.json').read_text());a=json.loads((O/'APPLIED.json').read_text());assert c['passed']and a['passed']and a['indexSha256']==sha(R/'evidence/index.json')
names=[P.name,O.name,'verified-handoff-capacity-startup-diagnosis-r1','verified-handoff-capacity-startup-reproduction-r1','verified-handoff-capacity-stop-r1','dispatch-capacity-scope-tar-preparation-r1','verified-handoff-capacity-admission-private-proof-r1']
for rate in (6000,7000,7500):
 names.extend(f'verified-handoff-capacity-{rate}-d1-{suffix}-r1'for suffix in ('private-proof','workload-audit','schema-audit','bottleneck','cut-recovery','maintenance-phases','duplicate-retirement'))
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True)
archive=A/'complete-candidate-capacity-curve.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(O/'CURVE.json',A/'CURVE.json')
for n in ('README.md','docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md','docs/VERIFIED_HANDOFF_CAPACITY_V3.md','evidence/index.json'):
 p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(A/'README.md').write_text('''# Candidate finite capacity curve:6000/7000/7500 per second

All three native observations are valid controls.6000/7000 have zero notSent/rejection/UNKNOWN and global accepted-arrival p99208.340423/317.321132ms.7500 has75,469 unique accepted trades and74,531 definite client QUEUE_FULL outcomes;global accepted-arrival p99 is undefined. Accepted-only p994557.860156ms is conditional. The registered gate fails and8000 was not executed. No sustained ceiling,SLA or100M claim.

This complete derivation retains all reporting and startup-analysis sources/results,source pins,private proofs,phase/recovery/trade audits,UI before/after and HTTP receipts,stop decision and generated-copy retirement receipts. All64 earlier runs/28 cohorts remain unchanged;the index is67/29. The three sibling committed native packages retain the full original raw bodies as private draft assets,each previously authenticated-downloaded in full with every member SHA/size/mode/owner/directory verified. These proofs are linked rather than replacing raw evidence. No new workload is executed by the report. Startup slowdown precedes first maintenance;client polling/raw IO,replication/service,GC and shared-host effects remain unseparated.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,records=67,cohorts=29,stoppedAtRate=7500,unexecutedRates=[8000],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'],gitPayloadFiles=len(inv['files']))))
