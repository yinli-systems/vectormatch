from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-reporting-r1';O=B/'verified-handoff-capacity-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo='yinli-systems/vectormatch';assert json.loads(subprocess.check_output(['gh','api','repos/'+repo]))['private']
def package(p):
 inv=json.loads((p/'INVENTORY.json').read_text());closed=json.loads((p/'CLOSED.json').read_text());actual=tree(p)
 assert closed['passed']and closed['inventorySha256']==sha(p/'INVENTORY.json')
 assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
 prefix=p.relative_to(R).as_posix();blobs={}
 for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
  if row:
   meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
 paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
 return closed,len(paths)
closed,count=package(A);assert closed['records']==67 and closed['cohorts']==29 and not closed['higherLoadPermitted']
for n in ('README.md','docs/VERIFIED_HANDOFF_CAPACITY_RESULTS_V3.md','docs/VERIFIED_HANDOFF_CAPACITY_V3.md','evidence/index.json'):assert git('show',head+':'+n)==(R/n).read_bytes()==(A/'published'/n).read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+A.relative_to(R).as_posix()+'/complete-candidate-capacity-curve.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
c=json.loads((A/'CURVE.json').read_text());native=[]
for r in c['observations']:
 rate=r['rate'];p=B/f'verified-handoff-capacity-{rate}-d1-private-proof-r1/PRIVATE_PUSH.json';proof=json.loads(p.read_text())
 assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']and proof['allOriginalNativeAndRawEvidencePushed']
 point=A.parent/f'capacity-{rate}-arm-d1-native-r1';pc,pn=package(point);manifest=point/'ASSET_MANIFEST.json';m=json.loads(git('show',head+':'+manifest.relative_to(R).as_posix()));assert m==json.loads(manifest.read_text())
 assert m['assetId']==proof['assetId']==r['assetId']and m['sha256']==proof['assetSha256']==r['assetSha256']and m['bytes']==proof['assetBytes']and sha(point/'INVENTORY.json')==proof['archiveInventorySha256']
 assert proof['allOriginalCompressedScopeMembersVerified']==pc['originalScopeReview']
 root=json.loads((point/'root-review/ROOT_REVIEW.json').read_text());assert root['nativeControlPassed']and root['performanceQualified']and root['allArrivalP99Ns']==r['p99Ns']
 assert root['notSent']==r['notSent']and root['confirmedAcceptedUniqueOrders']==r['accepted']and proof['finiteProgressionPermitted']==(rate<7500)
 subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],head],check=True)
 native.append(dict(rate=rate,assetId=m['assetId'],assetSha256=m['sha256'],bytes=m['bytes'],previousCompleteAuthenticatedMemberProofCommit=proof['commit'],proofSha256=sha(p),allCommittedNativeMetadataBlobsVerified=pn))
index=json.loads((R/'evidence/index.json').read_text());before=json.loads((B/'verified-handoff-capacity-reporting-r1/index-before.json').read_text());assert len(index['runs'])==67 and len(index['capacityCohorts'])==29 and index['runs'][:64]==before['runs']and index['capacityCohorts'][:28]==before['capacityCohorts']and index['capacity']==before['capacity']
assert index['runs'][-1]['p99Millis']is None and index['capacityCohorts'][-1]['points'][-1]['clientNotSent']==74531
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,private=True,commit=head,bothRemoteBranchesVerified=True,reportingGitBlobsVerified=count,reportingRestoredFromActualGitBlob=True,allOriginalReportingMembersVerified=members,native=native,allThreeNativeAssetsPreviouslyFullyAuthenticatedAndMemberVerified=True,all64PriorRunsAnd28CohortsPreserved=True,records=67,cohorts=29,executedRates=[6000,7000,7500],unexecutedRates=[8000],stoppedAtRate=7500,higherLoadPermitted=False,startupAnalysisExactlyReproduced=True,browserRenderVerified=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='native'}))
