from pathlib import Path
import csv,hashlib,json,math
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-handoff-capacity-startup-reproduction-r1';assert not O.exists()
rows=[];pins={}
for rate in (6000,7000,7500):
 L=B/f'verified-handoff-capacity-{rate}-d1-root-review-r1/materialized/attempt-{rate}/idle-arm/load'
 cfg=json.loads((L/'configuration.json').read_text())
 cycle=dict(line.split('=',1)for line in (L/'maintenance/cycle-1.verified.txt').read_text().splitlines())
 origin=cfg['scheduledOriginMonotonicNs'];start=int(cycle['cycleStartedMonotonicNs'])-origin
 with (L/'arrivals.csv').open()as f:allrows=list(csv.DictReader(f))
 accepted=[r for r in allrows if r['result_code']=='ACCEPTED' and int(r['reply_completion_offset_ns'])<=start]
 assert len(accepted)==3069
 def p99(v):return sorted(v)[math.ceil(len(v)*.99)-1]
 post=[int(r['reply_completion_offset_ns'])-int(r['first_successful_offer_return_offset_ns'])for r in accepted]
 notsent=[r for r in allrows if r['status']=='NOT_SENT']
 row=dict(rate=rate,firstMaintenanceStartNs=start,acceptedBeforeFirstMaintenance=len(accepted),observedAcceptedRateBeforeFirstMaintenance=len(accepted)*1e9/start,meanPostOfferNs=sum(post)/len(post),postOfferP99Ns=p99(post),submitToOfferP99Ns=p99([int(r['first_successful_offer_return_offset_ns'])-int(r['submit_offset_ns'])for r in accepted]),scheduledToDispatchP99Ns=p99([int(r['dispatch_offset_ns'])-int(r['scheduled_offset_ns'])for r in accepted]),meanAdmittedLogicalConcurrencyBeforeFirstMaintenance=sum(post)/start,notSentArrivingBeforeFirstMaintenance=sum(int(r['arrival_offset_ns'])<start for r in notsent),firstNotSentArrivalOffsetNs=min((int(r['arrival_offset_ns'])for r in notsent),default=None),sourceCsvSha256=hashlib.sha256((L/'arrivals.csv').read_bytes()).hexdigest())
 rows.append(row)
 for n in ('configuration.json','arrivals.csv','maintenance/cycle-1.verified.txt'):
  p=L/n;pins[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
old=json.loads((B/'verified-handoff-capacity-startup-diagnosis-r1/RESULT.json').read_text());assert rows==old['observations']
O.mkdir();result=dict(passed=True,observations=rows,inputs=pins,exactOriginalAnalysisReproduced=True,definition='All accepted replies completed before the first maintenance start; mean logical concurrency is the sum of offer-return-to-completion lifetimes divided by that startup interval. No pending business remains at maintenance start.',limits=old['source'],sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,rates=[r['rate']for r in rows])))
