from pathlib import Path
import ast,hashlib,json,shutil,sys,tarfile

B=Path(__file__).resolve().parent.parent;case=sys.argv[1];cases=('c1','d1','c2','d2');assert case in cases
prefix='verified-archive-handoff-exitwait'
S=B/'dispatch-capacity-controller-4000-preparation-r1';O=B/f'{prefix}-{case}-controller-preparation-r1';assert not O.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qualification=B/'verified-archive-handoff-qualification-private-proof-r1/PRIVATE_PUSH.json';q=json.loads(qualification.read_text())
assert q['passed'] and q['private'] and q['restoredWholeScopeArchiveFromActualGitBlob'] and q['onlyRegisteredCases']==list(cases) and q['privateAssetStorageQualified']
timingProof=B/'writer-timing-abab-reporting-private-proof-r1/PRIVATE_PUSH.json';t=json.loads(timingProof.read_text())
assert t['passed'] and t['private'] and t['actualRestorationDirectlyFromCommittedGitBlobsVerified']
candidate=case.startswith('d');sourcePrefix='verified-archive-handoff'if candidate else'writer-phase-timing'
M=B/f'{sourcePrefix}-linux-metadata-execution-r1';meta=json.loads((M/'actual-linux-observation.json').read_text());review=json.loads((M/'ROOT_REVIEW.json').read_text())
assert review['passed'] and meta['actualCodeFingerprint']==(q['codeFingerprint']if candidate else'f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca')
ci=qualification if candidate else B/'production-correctness-private-proof-r1/PRIVATE_PUSH.json'
c=json.loads(ci.read_text());assert c['passed'] and c['private'] and c['allTestTasksActuallyExecuted'] and c['forcedCiSourceCommit']==meta['sourceCommit']
previous=cases[cases.index(case)-1]if case!='c1'else None
if previous:
    prior=B/f'{prefix}-{previous}-private-proof-r1/PRIVATE_PUSH.json';p=json.loads(prior.read_text())
    assert p['passed'] and p['private'] and p['allOriginalNativeAndRawEvidencePushed'] and p['knownOutcomeQualified'] and p['nextRegisteredCase']==case
samplerPath=B/'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json';sampler=json.loads(samplerPath.read_text())
assert sampler['passed']and sampler['private']and sampler['restoredWholeScopeArchiveFromActualGitBlob']and sampler['controllerBridgeQualified']and sampler['newComparisonPrefix']==prefix and sampler['onlyRegisteredCases']==list(cases)and sampler['initialCampaignIncompletePreserved']
bridge=B/'process-identity-exit-wait-controller-bridge-preparation-r1/inputs'
O.mkdir()
for n in json.loads((S/'FROZEN.json').read_text())['files']:shutil.copy2((bridge if n in sampler['controllerInputRows']else S)/n,O/n)
shutil.copy2(bridge/'owned_process_identity.py',O/'owned_process_identity.py')
shutil.copy2(samplerPath,O/'sampler-qualification-private.json')
for path,name in [(qualification,'handoff-qualification-private.json'),(ci,'ci-private-proof.json'),(timingProof,'timing-comparison-private.json'),
                  (B/'private-release-storage-proof-r1/RESULT.json','asset-storage-qualified.json'),(M/'actual-linux-observation.json','linux-metadata.json'),(M/'ROOT_REVIEW.json','linux-metadata-root-review.json')]:shutil.copy2(path,O/name)
release=json.loads((O/'release.json').read_text());pins=json.loads((B/f'{sourcePrefix}-linux-metadata-preparation-r1/metadata-config.json').read_text())['rows']
old='/opt/vectormatch-cpu/tools/cpu-dispatch-capacity-metadata-r1';new=f'/opt/vectormatch-cpu/tools/cpu-{sourcePrefix}-metadata-r1'
assert meta['dispatchCapacityConfigs']['4000']['rotating']['plan']==release['derivedPlan']
release.update(sourceCommit=meta['sourceCommit'],codeFingerprint=meta['actualCodeFingerprint'],caseId=case,
    writerPhaseTimingsExpected=True,verifiedArchiveHandoffExpected=candidate,higherLoadPermitted=False,
    scope=f'VERIFIED_ARCHIVE_HANDOFF_EXIT_WAIT_{case.upper()}_4000_20S',
    handoffQualificationPrivateSha256=sha(O/'handoff-qualification-private.json'),ciPrivateProofSha256=sha(O/'ci-private-proof.json'),
    timingComparisonPrivateSha256=sha(O/'timing-comparison-private.json'),assetStorageQualifiedSha256=sha(O/'asset-storage-qualified.json'),
    rawEvidenceBackend=dict(repository='yinli-systems/vectormatch',private=True,releaseId=423510304,releaseTag='evidence-private-20261025',completeOriginalScopeTar=True,authenticatedFullDownloadBeforeNextCase=True))
release.update(processIdentitySamplerPolicy='proc-directory-stat-cmdline-stat-exit-wait-v2',samplerQualificationPrivateSha256=sha(O/'sampler-qualification-private.json'),identityReaderSha256=sampler['identityReaderSha256'],ownedWrapperSha256=sampler['ownedWrapperSha256'],cpuLoaderSha256=sampler['cpuLoaderSha256'])
release['artifacts']={p.replace(old,new):dict(bytes=pins['lib/'+Path(p).name]['bytes'],sha256=pins['lib/'+Path(p).name]['sha256'])for p in release['artifacts']}
for key in ('classPath','nodeClassPath'):release[key]=[p.replace(old,new)for p in release[key]]
if previous:shutil.copy2(prior,O/'preceding-arm-private.json');release.update(precedingCase=previous,precedingPrivateSha256=sha(O/'preceding-arm-private.json'))
(O/'release.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\n')
s=(O/'first_pilot.py').read_text().replace('dispatch-capacity-4000-r1',f'{prefix}-{case}-r1')
assert s.count('1d15cd2c53e0914c6d1d203cc486c563be3d2cfdaa1fa159ffaa8ffd231b14c4')==1
s=s.replace('1d15cd2c53e0914c6d1d203cc486c563be3d2cfdaa1fa159ffaa8ffd231b14c4',sampler['cpuLoaderSha256'])
needle='        idle=m.strict_idle(b);protected=m.protected_state(b,r)';assert needle in s
gate="""        sampler=json.loads((HERE/'sampler-qualification-private.json').read_text())
        require(digest(HERE/'sampler-qualification-private.json')==r['samplerQualificationPrivateSha256']and sampler['passed']and sampler['private']and sampler['restoredWholeScopeArchiveFromActualGitBlob']and sampler['controllerBridgeQualified']and sampler['newComparisonPrefix']=='verified-archive-handoff-exitwait'and sampler['initialCampaignIncompletePreserved']and sampler['actualOwnedPidfdProbePassed'],'Exact common qualified sampler and preserved invalid campaign required')
        require(r['processIdentitySamplerPolicy']=='proc-directory-stat-cmdline-stat-exit-wait-v2'and all(digest(HERE/n)==pin['sha256']and(HERE/n).stat().st_size==pin['bytes']for n,pin in sampler['controllerInputRows'].items()),'All seven common sampler/lifecycle source bodies must match private qualification')
        qualified=json.loads((HERE/'handoff-qualification-private.json').read_text());ci=json.loads((HERE/'ci-private-proof.json').read_text())
        timing=json.loads((HERE/'timing-comparison-private.json').read_text());storage=json.loads((HERE/'asset-storage-qualified.json').read_text())
        require(digest(HERE/'handoff-qualification-private.json')==r['handoffQualificationPrivateSha256']and qualified['passed']and qualified['private']and qualified['restoredWholeScopeArchiveFromActualGitBlob']and qualified['fixedPlanComparisonRate']==4000,'Full private handoff qualification required')
        require(digest(HERE/'ci-private-proof.json')==r['ciPrivateProofSha256']and ci['passed']and ci['private']and ci['allTestTasksActuallyExecuted']and ci['forcedCiSourceCommit']==r['sourceCommit']and ci['junit']==dict(tests=394 if CAPSULE else 390,failures=0,errors=0,skipped=0),'Actual forced CI private evidence required')
        require(digest(HERE/'timing-comparison-private.json')==r['timingComparisonPrivateSha256']and timing['passed']and timing['private']and timing['actualRestorationDirectlyFromCommittedGitBlobsVerified'],'All four original timing arms must be privately restored/verified first')
        require(digest(HERE/'asset-storage-qualified.json')==r['assetStorageQualifiedSha256']and storage['passed']and storage['private']and storage['draft']and storage['completeAuthenticatedDownloadVerified']and storage['releaseId']==423510304,'Complete private raw asset upload/download qualification required')
        require(r['caseId']==CASE and r['writerPhaseTimingsExpected']is True and r['verifiedArchiveHandoffExpected']==CAPSULE and r['higherLoadPermitted']is False,'Exact registered case required')
        require(r['codeFingerprint']==('79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'if CAPSULE else'f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca'),'Exact selected artifact required')
        if r.get('precedingCase'):
            previous=json.loads((HERE/'preceding-arm-private.json').read_text())
            require(digest(HERE/'preceding-arm-private.json')==r['precedingPrivateSha256']and previous['passed']and previous['private']and previous['allOriginalNativeAndRawEvidencePushed']and previous['completeAuthenticatedAssetDownloadVerified']and previous['knownOutcomeQualified']and previous['caseId']==r['precedingCase']and previous['nextRegisteredCase']==CASE,'Full original/private preceding arm closure required')
"""
s=s.replace(needle,gate+needle).replace('PREP=Path(',f'CASE={case!r};CAPSULE={candidate!r}\nPREP=Path(',1)
s=s.replace('maintainedCapacityPreset=True,rate=4000,allHigherPresetsStillUnexecuted=True','rate=4000,caseId=CASE,writerPhaseTimingsExpected=True,verifiedArchiveHandoffExpected=CAPSULE,higherLoadPermitted=False')
s=s.replace('First fresh80000@4000 with common128 qualification of NEW maintained-capacity artifact; no higher-load permission implied by this controller','Fresh80000@4000 registered common-sampler handoff retest;full raw private-asset closure before next case,no higher-load permission')
(O/'first_pilot.py').write_text(s)
files={}
for p in sorted(O.iterdir()):
    if p.suffix=='.py':ast.parse(p.read_text())
    p.chmod(0o644);files[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p),mode=420)
(O/'FROZEN.json').write_text(json.dumps(dict(schemaVersion=1,files=files,caseId=case,onlySelectedOfferedRate=4000,predecessorCase=previous,
    writerPhaseTimingsExpected=True,verifiedArchiveHandoffExpected=candidate,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
with tarfile.open(O/'source-package.tar.gz','w:gz')as t:
    for n in list(files)+['FROZEN.json']:t.add(O/n,arcname=n,recursive=False)
print(json.dumps(dict(passed=True,caseId=case,files=len(files),sourceFreezeSha256=sha(O/'FROZEN.json'),codeFingerprint=release['codeFingerprint'])))
