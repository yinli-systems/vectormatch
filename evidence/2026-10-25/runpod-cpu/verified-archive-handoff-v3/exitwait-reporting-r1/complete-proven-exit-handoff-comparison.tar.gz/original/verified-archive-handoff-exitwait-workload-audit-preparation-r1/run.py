from pathlib import Path
import datetime,hashlib,json,subprocess,sys

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;case=sys.argv[1]
assert case in ('c1','d1','c2','d2')
root=B/f'verified-archive-handoff-exitwait-{case}-root-review-r1';O=B/f'verified-archive-handoff-exitwait-{case}-workload-audit-r1'
assert not O.exists()
review=json.loads((root/'ROOT_REVIEW.json').read_text());raw=json.loads((root/'RAW_AUDIT.json').read_text())
assert review['passed'] and raw['passed'] and review['caseId']==raw['caseId']==case
lib=B/('verified-archive-handoff-artifact-preparation-r1/lib'if case.startswith('d')else'writer-phase-timing-artifact-preparation-r1/lib')
cp=str((P/'classes').resolve())+':'+':'.join(str((lib/n).resolve())for n in ('aeron-all-1.53.3.jar','agrona-2.6.1.jar','cluster-0.1.0-SNAPSHOT.jar','core-0.1.0-SNAPSHOT.jar'))
O.mkdir();input=root/'materialized/attempt-4000/idle-arm/load/physical-replies.bin'
args=[str((R/'.tools/jdk/bin/java').resolve()),'-Xmx256m','--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','-cp',cp,
      'io.vectormatch.cluster.DecodeTrades',str(input),str(O/'WORKLOAD.json')]
sourceSha=hashlib.sha256((P/'DecodeTrades.java').read_bytes()).hexdigest()
(O/'REGISTRATION.json').write_text(json.dumps(dict(arguments=args,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=sourceSha,codeFingerprint=review['codeFingerprint']),indent=2)+'\n')
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=subprocess.run(args,stdout=out,stderr=err,timeout=60)
(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n');assert r.returncode==0
result=json.loads((O/'WORKLOAD.json').read_text())
assert result['passed'] and result['uniqueAcceptedOrders']==result['uniqueTradeEvents']==result['resultTradeCount']==80000
assert result['replyBytes']==input.stat().st_size and result['replySha256']==hashlib.sha256(input.read_bytes()).hexdigest()
print(json.dumps(result))
