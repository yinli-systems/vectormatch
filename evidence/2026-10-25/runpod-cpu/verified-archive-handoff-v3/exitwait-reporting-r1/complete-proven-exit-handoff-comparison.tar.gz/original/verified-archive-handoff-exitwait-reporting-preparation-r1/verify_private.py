from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/exitwait-reporting-r1';O=B/'verified-archive-handoff-exitwait-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo='yinli-systems/vectormatch';assert json.loads(subprocess.check_output(['gh','api','repos/'+repo]))['private']
def package(p):
 inv=json.loads((p/'INVENTORY.json').read_text());closed=json.loads((p/'CLOSED.json').read_text());actual=tree(p)
 assert closed['passed'] and closed['inventorySha256']==sha(p/'INVENTORY.json')
 assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories'] and all(actual['files'][n]==v for n,v in inv['files'].items())
 prefix=p.relative_to(R).as_posix();blobs={}
 for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
  if row:
   meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
 paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
 return closed,len(paths)
closed,count=package(A);assert closed['campaignComplete'] and closed['records']==64 and closed['cohorts']==28
for n in ['README.md','docs/VERIFIED_ARCHIVE_HANDOFF_EXIT_WAIT_RESULTS_V3.md','docs/VERIFIED_ARCHIVE_HANDOFF_EXIT_WAIT_V3.md','docs/ASYNC_MAINTENANCE_V4.md','evidence/index.json']:assert git('show',head+':'+n)==(R/n).read_bytes()==(A/'published'/n).read_bytes()
O.mkdir();restored=O/'restored-reporting.tar.gz';prefix=A.relative_to(R).as_posix()
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/complete-proven-exit-handoff-comparison.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes'] and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
c=json.loads((A/'COMPARISON.json').read_text());assert [r['caseId']for r in c['observations']]==['c1','d1','c2','d2'];native=[]
for r in c['observations']:
 case=r['caseId'];p=B/f'verified-archive-handoff-exitwait-{case}-private-proof-r1/PRIVATE_PUSH.json';proof=json.loads(p.read_text());assert proof['passed'] and proof['knownOutcomeQualified'] and proof['completeAuthenticatedAssetDownloadVerified']
 point=A.parent/f'exitwait-arm-{case}-native-r1';pc,pn=package(point);manifest=point/'ASSET_MANIFEST.json';a=json.loads(git('show',head+':'+manifest.relative_to(R).as_posix()));assert a==json.loads(manifest.read_text())
 assert a['assetId']==proof['assetId'] and a['sha256']==proof['assetSha256'] and a['bytes']==proof['assetBytes'] and sha(point/'INVENTORY.json')==proof['archiveInventorySha256']
 assert proof['allOriginalCompressedScopeMembersVerified']==pc['originalScopeReview']
 root=json.loads((point/'root-review/ROOT_REVIEW.json').read_text());assert root['nativeControlPassed'] and root['performanceQualified'] and root['allArrivalP99Ns']==r['p99Ns']
 assert r['workload']['uniqueAcceptedOrders']==r['workload']['uniqueTradeEvents']==root['confirmedAcceptedUniqueOrders']==80000
 assert root['notSent']==root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0
 subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],head],check=True)
 native.append(dict(caseId=case,assetId=a['assetId'],assetSha256=a['sha256'],bytes=a['bytes'],previousCompleteAuthenticatedMemberProofCommit=proof['commit'],proofSha256=sha(p),allCommittedNativeMetadataBlobsVerified=pn))
index=json.loads((R/'evidence/index.json').read_text());before=json.loads((B/'verified-archive-handoff-exitwait-reporting-r1/index-before.json').read_text())
assert len(index['runs'])==64 and len(index['capacityCohorts'])==28 and index['runs'][:60]==before['runs'] and index['capacityCohorts'][:26]==before['capacityCohorts'] and index['capacity']==before['capacity']
q=json.loads((B/'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json').read_text());assert q['passed'] and q['all786NestedCi8OriginalFilesVerified']==786 and q['firstRetestIncompletePreserved']
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,private=True,commit=head,bothRemoteBranchesVerified=True,reportingGitBlobsVerified=count,reportingRestoredFromActualGitBlob=True,allOriginalReportingMembersVerified=members,native=native,allFourNativeAssetsPreviouslyFullyAuthenticatedAndMemberVerified=True,campaignComplete=True,executedCases=['c1','d1','c2','d2'],allOutcomesReconcile=True,all60PriorRunsAnd26CohortsPreserved=True,records=64,cohorts=28,repeatedFiniteP99AndMaintenanceReduction=c['repeatedFiniteP99AndMaintenanceReduction'],pairedDeltas=c['pairedDeltas'],historicalInvalidCampaignsUnchanged=True,qualifiedSamplerSourceCommit=q['identityReaderCiSourceCommit'],junit=q['junit'],pythonTests=q['pythonTests'],browserRenderVerified=False,higherLoadPermitted=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='native'}))
