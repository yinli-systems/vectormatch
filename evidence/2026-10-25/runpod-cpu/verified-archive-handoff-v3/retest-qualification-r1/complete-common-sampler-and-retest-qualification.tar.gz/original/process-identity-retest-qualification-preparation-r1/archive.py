from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-qualification-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
bridge=json.loads((B/'process-identity-controller-bridge-preparation-r1/PREPARATION.json').read_text())
native=json.loads((B/'process-identity-controller-native-proof-r1/stdout.json').read_text())
prior=json.loads((B/'verified-archive-handoff-incomplete-reporting-private-proof-r1/PRIVATE_PUSH.json').read_text())
jdk=json.loads((B/'process-identity-ci7-jdk-equivalence-r1/stdout.json').read_text())
assert bridge['passed'] and bridge['all227ActualCi7ApplicationClassesEqualQualifiedCi6'] and bridge['allOtherOwnedSignalAndLifecycleAstUnchanged']
assert native['passed']and native['mismatchedIdentityRejectedWithoutSignal']and native['originalPidfdSigtermStopPassed']and native['noForcedKill']
assert prior['passed']and prior['private']and prior['allThreeNativeAssetsRestoredAndEveryMemberVerified']and prior['campaignComplete']is False and prior['invalidCases']==['c2']
assert prior['allTestTasksActuallyExecuted']and prior['junit']==dict(tests=394,failures=0,errors=0,skipped=0)and prior['pythonTests']==189
assert jdk['passed']and jdk['files']==[454,454]
names=['process-identity-retest-qualification-preparation-r1','process-identity-controller-bridge-preparation-r1',
    'process-identity-controller-original-sources-r1','process-identity-controller-native-proof-r1','process-identity-ci7-jdk-equivalence-r1',
    'process-identity-linux-python38-r1','process-identity-exit-race-reproduction-r1','process-identity-forced-correctness-r1',
    'verified-archive-handoff-incomplete-reporting-private-proof-r1','verified-archive-handoff-qualification-private-proof-r1',
    'writer-phase-timing-linux-metadata-execution-r1','verified-archive-handoff-linux-metadata-execution-r1',
    'dispatch-capacity-scope-tar-preparation-r1']
before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-common-sampler-and-retest-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for src,name in [(B/'process-identity-controller-bridge-preparation-r1/PREPARATION.json','CONTROLLER_BRIDGE.json'),
                 (B/'process-identity-controller-native-proof-r1/stdout.json','OWNED_PIDFD_PROOF.json'),
                 (B/'verified-archive-handoff-incomplete-reporting-private-proof-r1/PRIVATE_PUSH.json','INITIAL_CAMPAIGN_PRIVATE_PROOF.json'),
                 (B/'process-identity-forced-correctness-r1/RESULT.json','FORCED_CI7_REVIEW.json')]:shutil.copy2(src,A/name)
for n in ('docs/VERIFIED_ARCHIVE_HANDOFF_RETEST_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md'):
    p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(A/'README.md').write_text('''# Common identity sampler:qualified handoff retest

Actual CI7 source4198aadd passes394 Java/11 PostgreSQL/189 Python plus failover/web gates,all0 skips. The controller's Python3.8 runtime separately passes18/18 identity tests. All227 CI7 application classes equal qualified CI6 classes;existing F3/79 benchmark JARs retain their actual build/source identity. The complete454-file CI7/benchmark JDK images agree.

The bridge changes only the owned process_identity function and the CPU loader's base-source hash. All other lifecycle/signal AST and four attestation/readiness source bodies are unchanged. A real owned-child proof refuses a mismatched identity without signaling,then passes the original pidfd SIGTERM/strict-exit path. All wrapper/reader/source bytes are retained. The initial C1/D1/C2 assets have been authenticated-downloaded and every original member verified;C2 remains invalid and old D2 remains unexecuted. The exact historical trigger is not claimed.

Register a new C1/D1/C2/D2 with one common sampler,fresh exclusive namespaces/lineages and unchanged4000/s20s80,000-order configuration. Complete private source/raw closure precedes every next case. No new matching workload has executed in this qualification. No performance gain,significance,sustained capacity,millisecond SLA,production certification or100M proof is established.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),
    archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,newComparisonExecuted=False,
    identityReaderSha256=bridge['identityReaderSha256'],ownedWrapperSha256=bridge['ownedWrapperSha256'],cpuLoaderSha256=bridge['cpuLoaderSha256'],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'],payloadFiles=len(inv['files']))))
