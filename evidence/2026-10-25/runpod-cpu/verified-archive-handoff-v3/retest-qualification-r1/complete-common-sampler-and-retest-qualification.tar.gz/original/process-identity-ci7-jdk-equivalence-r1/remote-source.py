from pathlib import Path
import hashlib,json,socket
assert socket.gethostname()=='33ace3d92505'
roots=[Path('/opt/vectormatch-cpu/tools/jdk-21.0.13+9'),Path('/opt/vectormatch-cpu/ci/production-correctness-r7/toolcache/Java_Temurin-Hotspot_jdk/21.0.13-9.0.LTS/x64')]
def tree(r):
 values={}
 for p in sorted(r.rglob('*')):
  if p.is_file():
   p.resolve().relative_to(r.resolve());values[str(p.relative_to(r))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return values
v=[tree(r)for r in roots];assert v[0]==v[1]and len(v[0])==454
print(json.dumps(dict(passed=True,roots=list(map(str,roots)),files=[len(x)for x in v],allFileBodies=v[0],noJavaStarted=True)))
