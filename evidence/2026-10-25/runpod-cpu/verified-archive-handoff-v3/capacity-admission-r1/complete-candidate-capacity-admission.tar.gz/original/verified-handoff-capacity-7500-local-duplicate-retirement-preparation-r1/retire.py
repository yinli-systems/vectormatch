from pathlib import Path
import datetime,json,shutil,stat,subprocess,sys

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';case=sys.argv[1];assert case in ('c1','d1','c2','d2')
prefix='verified-handoff-capacity-7500';O=B/f'{prefix}-{case}-duplicate-retirement-r1';assert not O.exists()
A=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-7500-arm-{case}-native-r1'
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
proof=json.loads((B/f'{prefix}-{case}-private-proof-r1/PRIVATE_PUSH.json').read_text())
assert proof['passed'] and proof['private'] and proof['completeAuthenticatedAssetDownloadVerified'] and proof['allOriginalNativeAndRawEvidencePushed']
remote=git('ls-remote','origin','refs/heads/codex/production-correctness-and-maintenance').decode().split()[0]
subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],remote],check=True)
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
assert closed['passed'] and closed['inventorySha256']==sha(A/'INVENTORY.json')==proof['archiveInventorySha256']
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories']
assert all(actual['files'][n]==v for n,v in inv['files'].items())
gitPrefix=A.relative_to(R).as_posix();blobs={}
for entry in git('ls-tree','-r','-z',proof['commit'],'--',gitPrefix).split(b'\0'):
    if entry:
        meta,name=entry.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={gitPrefix+'/'+n for n in actual['files']}
assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
asset=json.loads((A/'ASSET_MANIFEST.json').read_text());repo='yinli-systems/vectormatch'
assert asset['repository']==repo and asset['private'] and asset['caseId']==case and asset['assetId']==proof['assetId']
remoteAsset=json.loads(subprocess.check_output(['gh','api','repos/'+repo+'/releases/assets/'+str(asset['assetId'])]))
assert remoteAsset['state']=='uploaded' and remoteAsset['size']==asset['bytes']==proof['assetBytes'] and remoteAsset['digest']=='sha256:'+asset['sha256']
bundle=B/f'{prefix}-{case}-archive-r1'/asset['assetName'];assert str(bundle)==asset['localOriginalArchive']
assert bundle.stat().st_size==asset['bytes'] and sha(bundle)==asset['sha256']==proof['assetSha256']
scopes=json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text());members=verify(bundle,scopes)
assert members==closed['originalScopeReview']==proof['allOriginalCompressedScopeMembersVerified']
selected=[]
for kind in ('collection','root-review'):
    scope=f'{prefix}-{case}-{kind}-r1'
    for relative,pin in scopes[scope]['files'].items():
        eligible=(kind=='collection' and relative=='full-original-closed-round.tar.gz')or(kind=='root-review' and pin['bytes']>=16*1024**2 and not relative.endswith('arrivals.csv'))
        if not eligible:continue
        p=B/scope/relative;s=p.stat();assert not p.is_symlink()
        assert pin==dict(bytes=s.st_size,sha256=sha(p),mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
        selected.append(dict(target=str(p),bytes=s.st_size,sha256=pin['sha256'],restoreScopeTarMember='original/'+scope+'/'+relative))
assert len(selected)>=5
selected.append(dict(target=str(bundle),bytes=bundle.stat().st_size,sha256=sha(bundle),restoreScopeTarMember=None))
for row in selected:
    p=Path(row['target']);assert p.is_relative_to(B) and all(not parent.is_symlink()for parent in (p,*p.parents))
O.mkdir();shutil.copy2(Path(__file__),O/'executed-retire.py')
result=dict(verifiedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),caseId=case,privateCommit=proof['commit'],
    assetManifest=str(A/'ASSET_MANIFEST.json'),assetId=asset['assetId'],assetSha256=asset['sha256'],files=selected,
    allOriginalMembersAndCommittedGitBlobsReverifiedBeforeUnlink=True,completeAuthenticatedAssetDownloadAlreadyVerified=True,
    freeBytesBefore=shutil.disk_usage(R).free,
    scope='Redundant local closed runtime copies only. Full raw bytes remain in the private release asset and remote native originals. Keep arrivals.csv and all small reports/audits. Restore complete asset by authenticated API ID;verify size/SHA and original member inventory before use.')
(O/'VERIFIED_BEFORE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for row in selected:
    p=Path(row['target']);assert not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];p.unlink()
result.update(passed=True,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),retiredFiles=len(selected),
    retiredLogicalBytes=sum(v['bytes']for v in selected),allTargetsAbsent=all(not Path(v['target']).exists()for v in selected),freeBytesAfter=shutil.disk_usage(R).free)
(O/'RETIREMENT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='files'}))
