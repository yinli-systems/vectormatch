from pathlib import Path
import collections, datetime, hashlib, json, sys

B = Path(__file__).resolve().parent.parent
case = sys.argv[1]
assert case in ('c1', 'd1', 'c2', 'd2')
O = B / f'verified-handoff-capacity-8000-{case}-schema-audit-r1'
assert not O.exists()
root = B / f'verified-handoff-capacity-8000-{case}-root-review-r1'
load = root / 'materialized/attempt-8000/idle-arm/load'
inputs = {}
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()
def pin(p):
    inputs[str(p)] = dict(bytes=p.stat().st_size, sha256=sha(p))
    return p
def read(p): return json.loads(pin(p).read_text())
def kv(p):
    lines = pin(p).read_text().splitlines()
    pairs = [line.split('=', 1) for line in lines if '=' in line]
    assert len(dict(pairs)) == len(pairs), 'duplicate receipt field'
    return dict(pairs)
review = read(root / 'ROOT_REVIEW.json')
raw = read(root / 'RAW_AUDIT.json')
assert review['passed'] and raw['passed'] and review['caseId'] == raw['caseId'] == case
timing = True
capsule = case.startswith('d')
summary = read(load / 'load-result.json')
suffixes = ('CopyNs', 'QueueWaitNs', 'PrevalidationNs', 'InputHashNs', 'WriteNs',
            'ForceNs', 'ReadbackNs', 'ReceiptWriteNs', 'ReceiptForceNs', 'ElapsedNs')
serial = ('PrevalidationNs', 'InputHashNs', 'WriteNs', 'ForceNs', 'ReadbackNs', 'ReceiptWriteNs', 'ReceiptForceNs')
totals = {kind: collections.Counter() for kind in ('archive', 'events')}
cycles, payloads = [], set()
for p in sorted((load / 'maintenance').glob('cycle-*.verified.txt'), key=lambda p: int(p.name.split('-')[1].split('.')[0])):
    c = kv(p)
    assert c['forceAndReadbackBeforeBothAcks'] == 'true'
    duration = int(c['cycleEndedMonotonicNs']) - int(c['cycleStartedMonotonicNs'])
    assert duration >= 0
    if timing:
        assert c['writerTimingSchema'] == '1'
        coordinator = int(c['coordinatorArchiveVerificationNs'])
        assert 0 <= coordinator <= duration
    else:
        assert not any(k == 'writerTimingSchema' or 'Writer' in k or k == 'coordinatorArchiveVerificationNs' for k in c)
        coordinator = None
    row = dict(cycle=int(c['cycle']), wallNs=duration, coordinatorArchiveVerificationNs=coordinator, writers={})
    measured = coordinator or 0
    for kind, field in (('archive', 'archiveFile'), ('events', 'eventFile')):
        if c[field] == 'null':
            assert kind == 'events' and (not timing or c['eventsWriterPresent'] == 'false')
            continue
        remote = Path(c[field])
        expected_parent = f'/opt/vectormatch-cpu/experiments/verified-handoff-capacity-8000-{case}-r1/attempt-8000/idle-arm/load/writer'
        assert str(remote.parent) == expected_parent
        payload = load / 'writer' / remote.name
        receipt_path = payload.with_name(payload.name + '.verified.txt')
        assert receipt_path.stat().st_size <= 1024
        receipt = kv(receipt_path)
        assert remote.name == receipt['payload'] and remote.name not in payloads
        payloads.add(remote.name)
        pin(payload)
        assert payload.stat().st_size == int(receipt['bytes']) and sha(payload) == receipt['sha256']
        assert receipt['forceTrueCompleted'] == receipt['fullReadbackVerified'] == 'true'
        if kind == 'archive': assert c['archiveSha256'] == receipt['sha256']
        legacy = {n: int(receipt[n]) for n in ('writeNs', 'forceNs', 'readbackNs')}
        assert all(v >= 0 for v in legacy.values())
        if timing:
            assert c[kind + 'WriterPresent'] == 'true'
            if capsule:
                assert c[kind + 'WriterVerifiedArchiveHandoff'] == ('true' if kind == 'archive' else 'false')
            else:
                assert kind + 'WriterVerifiedArchiveHandoff' not in c
            phases = {n: int(c[kind + 'Writer' + n]) for n in suffixes}
            assert all(v >= 0 for v in phases.values())
            assert sum(phases[n] for n in serial) <= phases['ElapsedNs']
            assert all(phases[n[0].upper() + n[1:]] == v for n, v in legacy.items())
            phases['UnmeasuredWriterNs'] = phases['ElapsedNs'] - sum(phases[n] for n in serial)
            measured += phases['ElapsedNs'] + phases['CopyNs'] + phases['QueueWaitNs']
        else:
            phases = {n[0].upper() + n[1:]: v for n, v in legacy.items()}
        totals[kind].update(phases)
        row['writers'][kind] = dict(payload=remote.name, bytes=payload.stat().st_size, sha256=receipt['sha256'], **phases)
    assert measured <= duration, 'coordinator/writer serial stages exceed cycle wall time'
    cycles.append(row)
assert len(cycles) == summary['maintenanceCycles']
assert set(p.name for p in (load / 'writer').glob('*.bin')) == payloads
assert set(p.name for p in (load / 'writer').glob('*.verified.txt')) == {p + '.verified.txt' for p in payloads}
assert all(Path(n).stat().st_size == v['bytes'] and sha(Path(n)) == v['sha256'] for n, v in inputs.items())
result = dict(passed=True, atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), caseId=case,
              writerTimingSchema=1, verifiedArchiveHandoffExpected=capsule, maintenanceCycles=len(cycles), payloadsVerified=len(payloads),
              maintenanceWallNs=sum(c['wallNs'] for c in cycles),
              coordinatorArchiveVerificationNs=sum(c['coordinatorArchiveVerificationNs'] for c in cycles) if timing else None,
              writerTotals={k: dict(v) for k, v in totals.items()}, cycles=cycles, inputs=inputs,
              sourceSha256=sha(Path(__file__)),
              scope='Every original cycle and payload receipt; exact bytes/SHA and legacy metrics match. Seven serial writer phases are bounded by elapsed; copy/queue precede elapsed. No isolated hardware/CPU/network inference or independent codec oracle.')
O.mkdir()
(O / 'SCHEMA_AUDIT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('cycles', 'inputs')}))
