package io.vectormatch.cluster;

import io.vectormatch.core.MatchingEngine.Event;
import io.vectormatch.core.MatchingEngine.EventType;
import io.vectormatch.core.MatchingEngine.Result;
import io.vectormatch.core.MatchingEngine.ResultCode;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Counts original decoded outcomes/events;not an independent matching oracle. */
public final class DecodeTrades {
    record Outcome(Result result,String payloadHash){}
    static void require(boolean value,String message){if(!value)throw new IllegalStateException(message);}
    public static void main(String[] args)throws Exception{
        Path input=Path.of(args[0]),output=Path.of(args[1]);long size=Files.size(input);int accepted=Integer.parseInt(args[2]);require(accepted>=0&&accepted<=350000,"bounded expected accepted count");
        require(size>0&&size<1024L*1024*1024,"bounded closed reply tape required");
        var outcomes=new HashMap<String,Outcome>();var events=new TreeMap<Long,Event>();long offset=0,frames=0,replayedEntries=0;
        var digest=MessageDigest.getInstance("SHA-256");
        try(var in=new DataInputStream(new BufferedInputStream(new java.security.DigestInputStream(Files.newInputStream(input),digest),65536))){
            while(offset<size){
                require(size-offset>=12,"partial tape header");in.readLong();int length=in.readInt();
                require(length>0&&length<=RetentionReplyV3.MAX_REPLY_BYTES&&offset+12L+length<=size,"bounded complete tape frame");
                byte[] bytes=in.readNBytes(length);require(bytes.length==length,"truncated reply");
                var reply=RetentionReplyV3.decode(bytes);require(Arrays.equals(bytes,RetentionReplyV3.encode(reply))&&reply.error().isEmpty(),"canonical error-free reply required");
                if(reply.payload()instanceof RetentionReplyV3.Batch batch)for(var entry:batch.entries()){
                    require(entry.status()==RetentionReplyV3.BatchStatus.APPLIED&&entry.result()!=null,"applied original outcomes required");
                    Result result=entry.result();require(result.code()==ResultCode.ACCEPTED&&result.tradeCount()==1&&result.remainingQuantity()==0,"one fully filled IOC per planned outcome required");
                    String key=entry.identity().producerId()+":"+entry.identity().requestSeq();var value=new Outcome(result,entry.commandSha256());
                    Outcome previous=outcomes.putIfAbsent(key,value);require(previous==null||previous.equals(value),"conflicting duplicate outcome");
                    if(entry.replayed())replayedEntries++;
                }
                if(reply.payload()instanceof RetentionReplyV3.Events page)for(Event event:page.batch().events()){
                    Event previous=events.putIfAbsent(event.eventSeq(),event);require(previous==null||previous.equals(event),"conflicting duplicate event");
                }
                require(outcomes.size()<=accepted&&events.size()<=2*accepted+3,"fixed-workload audit bounds");offset+=12L+length;frames++;
            }
            require(in.read()==-1&&Files.size(input)==size,"reply tape changed/extended");
        }
        require(outcomes.size()==accepted&&events.size()==2*accepted+3,"all business outcomes and exported events required");
        var orders=new HashSet<Long>();long resultTrades=0;
        for(Outcome outcome:outcomes.values()){
            long id=outcome.result().orderId();require(id>=2&&id<=accepted+1&&orders.add(id),"distinct planned order identities required");
            resultTrades+=outcome.result().tradeCount();
        }
        long eventSeq=0,tradeEvents=0,quantity=0,notional=0;var takers=new HashSet<Long>();
        var types=new TreeMap<String,Long>();
        for(Event event:events.values()){
            require(event.eventSeq()==++eventSeq,"complete exported event sequence required");types.merge(event.type().name(),1L,Long::sum);
            if(event.type()==EventType.TRADE){
                require(event.priceTicks()==10&&event.quantityLots()==1&&event.makerOrderId()==1&&orders.contains(event.takerOrderId())&&takers.add(event.takerOrderId()),"one-unit fixed-price seeded-maker trade linkage required");
                tradeEvents++;quantity=Math.addExact(quantity,event.quantityLots());notional=Math.addExact(notional,Math.multiplyExact(event.priceTicks(),event.quantityLots()));
            }
        }
        require(tradeEvents==resultTrades&&tradeEvents==accepted&&takers.equals(orders),"outcome/trade-event closure");
        var result=new LinkedHashMap<String,Object>();result.put("passed",true);result.put("replyFrames",frames);result.put("replyBytes",size);
        result.put("replySha256",HexFormat.of().formatHex(digest.digest()));result.put("uniqueAcceptedOrders",outcomes.size());result.put("resultTradeCount",resultTrades);
        result.put("uniqueExportedEvents",events.size());result.put("eventTypes",types);result.put("uniqueTradeEvents",tradeEvents);result.put("filledQuantityLots",quantity);
        result.put("priceTicks",10);result.put("notionalTickLots",notional);result.put("makerOrderId",1);result.put("uniqueTakerOrders",takers.size());result.put("replayedReplyEntries",replayedEntries);
        result.put("scope","Original reply/event counting with exact duplicate equality and order linkage. Synthetic one-unit IOC trades against one pre-funded seeded maker at10 ticks;not a multi-level/cancel workload,external venue or funded trading. Candidate codec,not an independent matching oracle.");
        RetentionCapacityJsonV3.writeNew(output,result);
    }
}
