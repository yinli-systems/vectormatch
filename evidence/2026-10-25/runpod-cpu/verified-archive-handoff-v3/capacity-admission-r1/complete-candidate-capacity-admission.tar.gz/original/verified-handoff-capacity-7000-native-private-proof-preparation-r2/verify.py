from pathlib import Path
import datetime,json,subprocess,sys

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';case=sys.argv[1];cases=('d1',);assert case in cases
prefix='verified-handoff-capacity-7000';A=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-7000-arm-{case}-native-r1';O=B/f'{prefix}-{case}-private-proof-r1'
assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
def api(path):return json.loads(subprocess.check_output(['gh','api',path]))
head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/production-correctness-and-maintenance').decode().split()[0]==head
repo='yinli-systems/vectormatch';assert api('repos/'+repo)['private']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
assert closed['passed'] and closed['caseId']==case and closed['inventorySha256']==sha(A/'INVENTORY.json')
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories']
assert all(actual['files'][n]==v for n,v in inv['files'].items())
gitPrefix=A.relative_to(R).as_posix();blobs={}
for entry in git('ls-tree','-r','-z',head,'--',gitPrefix).split(b'\0'):
    if entry:
        meta,name=entry.split(b'\t',1);assert meta.split()[1]==b'blob';blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={gitPrefix+'/'+n for n in actual['files']}
assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
asset=json.loads(git('show',head+':'+gitPrefix+'/ASSET_MANIFEST.json'))
assert asset['schemaVersion']==1 and asset['repository']==repo and asset['private'] and asset['draft'] and asset['caseId']==case
assert closed['assetManifestSha256']==sha(A/'ASSET_MANIFEST.json') and asset['releaseId']==423510304 and asset['releaseTag']=='evidence-private-20261025'
assert type(asset['assetId'])is int and asset['assetId']>0 and asset['assetApiUrl']=='https://api.github.com/repos/'+repo+'/releases/assets/'+str(asset['assetId'])
expectedName=f'handoff-capacity-7000-{case}-complete-original-scopes-r1.tar.gz';assert asset['assetName']==expectedName
original=B/f'{prefix}-{case}-archive-r1'/expectedName;assert asset['localOriginalArchive']==str(original)
assert original.stat().st_size==asset['bytes']==closed['archiveBytes'] and sha(original)==asset['sha256']==closed['archiveSha256']
release=api('repos/'+repo+'/releases/'+str(asset['releaseId']));assert release['draft'] and release['tag_name']==asset['releaseTag']
remote=api('repos/'+repo+'/releases/assets/'+str(asset['assetId']))
assert remote['id']==asset['assetId'] and remote['name']==expectedName and remote['size']==asset['bytes'] and remote['state']=='uploaded' and remote['digest']=='sha256:'+asset['sha256']
assert sum(a['id']==asset['assetId'] and a['name']==expectedName for a in release['assets'])==1
O.mkdir();download=O/'authenticated-complete-original-scopes.tar.gz'
(O/'AUTHENTICATED_ASSET_METADATA.json').write_text(json.dumps(remote,indent=2,sort_keys=True)+'\n')
with download.open('xb')as out,(O/'download.stderr').open('xb')as err:
    result=subprocess.run(['gh','api','repos/'+repo+'/releases/assets/'+str(asset['assetId']),'-H','Accept: application/octet-stream'],stdout=out,stderr=err,timeout=600,env={**__import__('os').environ,'GODEBUG':'http2client=0'})
assert result.returncode==0 and download.stat().st_size==asset['bytes'] and sha(download)==asset['sha256']
members=verify(download,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['originalScopeReview']
root=json.loads((A/'root-review/ROOT_REVIEW.json').read_text());raw=json.loads((A/'root-review/RAW_AUDIT.json').read_text());ready=json.loads((A/'root-review/READINESS_REVIEW.json').read_text());schema=json.loads((A/'SCHEMA_AUDIT.json').read_text())
assert all(x['passed']for x in (root,raw,ready,schema)) and all(x['caseId']==case for x in (root,raw,ready,schema))
assert schema['verifiedArchiveHandoffExpected']==case.startswith('d') and schema['writerTimingSchema']==1
assert raw['allOriginalFrameIndexesOffsetsLengthsHashesAndOfferRecordsVerified'] and root['strictKnownSourceQualification']
releasePin=json.loads((B/f'{prefix}-{case}-controller-preparation-r1/release.json').read_text())
assert root['codeFingerprint']==raw['codeFingerprint']==asset['codeFingerprint']==releasePin['codeFingerprint']
qualification=A.parent/'qualification-r1';refs=json.loads((A/'SHARED_EVIDENCE_REFERENCES.json').read_text())
assert all((qualification/n).stat().st_size==v['bytes'] and sha(qualification/n)==v['sha256']for n,v in refs.items())
known=root['nativeControlPassed'] and root['schedulerTimingValid'] and root['confirmedAcceptedUniqueOrders']==140000 and root['notSent']==root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0
permitted=known and root['windowConfirmationFraction']>=.99 and root['allArrivalP99Ns']is not None and root['allArrivalP99Ns']<=1000000000
nextCase=cases[cases.index(case)+1]if cases.index(case)<len(cases)-1 else None
download.unlink() # Only the generated,fully verified download copy;original TAR and remote asset remain.
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository=repo,commit=head,
    caseId=case,sourceCommit=releasePin['sourceCommit'],codeFingerprint=root['codeFingerprint'],writerPhaseTimingsExpected=True,
    verifiedArchiveHandoffExpected=case.startswith('d'),allEvidenceGitBlobsVerified=len(paths),allOriginalNativeAndRawEvidencePushed=True,
    completeAuthenticatedAssetDownloadVerified=True,allOriginalCompressedScopeMembersVerified=members,assetId=asset['assetId'],assetBytes=asset['bytes'],
    assetSha256=asset['sha256'],archiveInventorySha256=sha(A/'INVENTORY.json'),archiveClosedSha256=sha(A/'CLOSED.json'),
    committedAssetManifestSha256=sha(A/'ASSET_MANIFEST.json'),schemaAuditSha256=sha(A/'SCHEMA_AUDIT.json'),
    offeredRate=7000,plannedArrivals=140000,knownOutcomeQualified=known,finiteProgressionPermitted=permitted,nextRegisteredRate=7500 if permitted else None,nextRegisteredCase=nextCase if known else None,higherLoadPermitted=False,
    allArrivalP99Ns=root['allArrivalP99Ns'],arrivalWindowGoodputPerSecond=root['arrivalWindowGoodputPerSecond'],
    onlyGeneratedVerifiedDownloadRemoved=True,http2DisabledPerDownloadProcess=True,noSustainedCapacityOrRealtimeClaim=True,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(proof))
