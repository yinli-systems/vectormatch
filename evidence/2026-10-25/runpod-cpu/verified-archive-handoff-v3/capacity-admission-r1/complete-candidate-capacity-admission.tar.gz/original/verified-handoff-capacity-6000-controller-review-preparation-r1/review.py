from pathlib import Path
from types import SimpleNamespace
import sys,json,hashlib,copy,datetime,ast

B=Path(__file__).resolve().parent.parent;case=sys.argv[1];assert case in('c1','d1','c2','d2');rate=6000
P=B/f'verified-handoff-capacity-6000-{case}-controller-preparation-r1';O=B/f'verified-handoff-capacity-6000-{case}-controller-review-r1';assert not O.exists()
sys.path.insert(0,str(P));import cpu_read_window32_abab as m
m.WINDOWS=[128];m.READ_WINDOW_ORDER=(128,);m.OWNER_PARK_ORDER=(1000000,)
exec(compile((P/'capacity_validators.py').read_text(),str(P/'capacity_validators.py'),'exec'),m.__dict__)
base=B/'ready-shared-capacity-1000-root-review-r1/materialized/attempt-1000/idle-arm'
r=json.loads((P/'release.json').read_text());reg=json.loads((base/'registration.json').read_text())
reg.update(arrivals=rate*20,rate=rate,codeSha256=r['codeFingerprint'],fineDispatchCapacityPreset=True,dispatchOrderPolicy='ROTATING_CONTINUE')
m.validate_registration(r,128,reg)
summary=json.loads((base/'load/load-result.json').read_text())
summary.update(scheduledArrivals=rate*20,releasedArrivals=rate*20,ratePerSecond=rate,
    completedLogicalReplies=rate*20,confirmedAcceptedUniqueOrders=rate*20,
    maintenanceCycles=(rate*20+3+3071)//3072,dispatchOrderPolicy='ROTATING_CONTINUE')
m.validate_long_summary(summary,128);guards=2
loss=copy.deepcopy(summary);loss.update(completedLogicalReplies=rate*20-100,confirmedAcceptedUniqueOrders=rate*20-100,notSent=100,allArrivalP99Ns=None)
m.validate_long_summary(loss,128);guards+=1
for key,value in [('arrivals',rate*20+1),('rate',rate-1),('readWindow',32),('eventFetchCount',16),('sync',0),('preloadWarmupMillis',0),('codeSha256','0'*64)]:
    bad=copy.deepcopy(reg);bad[key]=value
    try:m.validate_registration(r,128,bad)
    except RuntimeError:guards+=1
    else:raise AssertionError(key)
for key,value in [('scheduledArrivals',rate*20-1),('ratePerSecond',rate-1),('readWindow',32),('unknownObserved',1),('unknownFinal',1),('schedulerTimingValid',False),('notSent',-1)]:
    bad=copy.deepcopy(summary);bad[key]=value
    try:m.validate_long_summary(bad,128)
    except RuntimeError:guards+=1
    else:raise AssertionError(key)
bad=copy.deepcopy(loss);bad['allArrivalP99Ns']=1
try:m.validate_long_summary(bad,128)
except RuntimeError:guards+=1
else:raise AssertionError('Censored global success percentile was admitted')

source=(P/'first_pilot.py').read_text();tree=ast.parse(source)
assert f"'read128-dispatch-capacity','rotating','{rate}'" in source
assert source.count("validate_readiness(doc,nodes,cfg['scheduledOriginMonotonicNs'])")==1
inner=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='validate_with_readiness')
checks=[n for n in inner.body if (isinstance(n,ast.For)and 'fineDispatchCapacityPreset'in ast.unparse(n))or(isinstance(n,ast.Expr)and 'Actual source policy differs'in ast.unparse(n))]
assert len(checks)==2
compiled=compile(ast.fix_missing_locations(ast.Module(body=checks,type_ignores=[])),'actual-fine-policy-guards','exec')
def policy_guard(values):
    reg,cfg,functional,summary=values
    transport=SimpleNamespace(PAIR=Path('/pure-fixture'),json_bounded=lambda b,p:functional if p.name=='capacity-correctness-result.json'else summary)
    exec(compiled,dict(reg=reg,cfg=cfg,m=transport,b=None,require=m.require))
values=[dict(fineDispatchCapacityPreset=True,dispatchOrderPolicy='ROTATING_CONTINUE')for _ in range(3)]+[dict(dispatchOrderPolicy='ROTATING_CONTINUE')]
policy_guard(values);guards+=1
for index in range(4):
    for key,value in ([('fineDispatchCapacityPreset',False),('dispatchOrderPolicy','FIXED_ZERO_START')]if index<3 else [('dispatchOrderPolicy','FIXED_ZERO_START')]):
        bad=copy.deepcopy(values);bad[index][key]=value
        try:policy_guard(bad)
        except RuntimeError:guards+=1
        else:raise AssertionError((index,key))
meta=json.loads((P/'linux-metadata.json').read_text())
assert meta['dispatchCapacityConfigs'][str(rate)]['fixed']['plan']==meta['dispatchCapacityConfigs'][str(rate)]['rotating']['plan']==r['derivedPlan']
assert r['fineDispatchCapacityPreset']and r['dispatchOrderPolicy']=='ROTATING_CONTINUE'
assert r['caseId']==case and r['writerPhaseTimingsExpected']is True and r['verifiedArchiveHandoffExpected']==case.startswith('d') and r['higherLoadPermitted']is False
assert "Actual forced CI private evidence required"in source and "Full original/private preceding arm closure required"in source
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();same={}
for n in ['idle_attestation.py','owner_poll_attestation.py','shutdown_warning.py','readiness_validation.py']:
    assert (P/n).read_bytes()==(B/'startup-readiness-controller-preparation-r2'/n).read_bytes();same[n]=sha(P/n)
sampler=json.loads((P/'sampler-qualification-private.json').read_text());assert sampler['passed']and sampler['private']and sampler['controllerBridgeQualified']and sampler['newComparisonPrefix']=='verified-handoff-capacity-6000'
for n,pin in sampler['controllerInputRows'].items():assert(P/n).stat().st_size==pin['bytes']and sha(P/n)==pin['sha256']
assert r['cpuLoaderSha256']==sampler['cpuLoaderSha256']and r['ownedWrapperSha256']==sampler['ownedWrapperSha256']and r['identityReaderSha256']==sampler['identityReaderSha256']
assert 'All seven common sampler/lifecycle source bodies must match private qualification'in source
O.mkdir()
(O/'SOURCE_REVIEW.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    rate=rate,pureFixtureGuards=guards,actualFinePolicyAstGuardsExecuted=True,
    fourOriginalAttestationAndReadinessSourcesUnchanged=same,allSevenQualifiedControllerSourceBodiesMatch=True,allOtherSignalAndLifecycleAstUnchanged=True,bothPolicyAdmissionPlansIdentical=True,
    fixturesNotActualNativeEvidence=True,sourceFreezeSha256=sha(P/'FROZEN.json')),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,rate=rate,pureFixtureGuards=guards)))
