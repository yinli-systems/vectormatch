from pathlib import Path
import datetime,json,shutil,subprocess,sys,tarfile

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';case=sys.argv[1];assert case in ('c1','d1','c2','d2')
prefix='verified-handoff-capacity-8000';A=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-8000-arm-{case}-native-r1';T=B/f'{prefix}-{case}-archive-r1'
assert not A.exists() and not T.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
root=B/f'{prefix}-{case}-root-review-r1'
r=json.loads((root/'ROOT_REVIEW.json').read_text());raw=json.loads((root/'RAW_AUDIT.json').read_text());ready=json.loads((root/'READINESS_REVIEW.json').read_text())
schema=json.loads((B/f'{prefix}-{case}-schema-audit-r1/SCHEMA_AUDIT.json').read_text())
assert all(x['passed']for x in (r,raw,ready,schema)) and r['nativeControlPassed'] and r['performanceQualified']
assert r['caseId']==raw['caseId']==ready['caseId']==schema['caseId']==case and schema['verifiedArchiveHandoffExpected']==case.startswith('d')
names=[f'{prefix}-{case}-{suffix}-r1'for suffix in ('controller-preparation','controller-review','controller-stage','launch','collection','root-review','review-execution','cache-precondition','schema-audit')]
for pattern in (f'{prefix}-{case}-preflight-r*',f'{prefix}-{case}-probe-r*'):names.extend(p.name for p in sorted(B.glob(pattern)))
names.extend([f'{prefix}-{n}-r1'for n in ('controller-generator','controller-review-preparation','runner','root-review-preparation',
    'native-archive-preparation','native-private-proof-preparation','bottleneck-preparation','recovery-preparation','maintenance-phases-preparation')])
names.extend(['verified-handoff-capacity-8000-schema-audit-preparation-r1','verified-handoff-capacity-8000-cache-precondition-preparation-r1',
    'verified-archive-handoff-qualification-private-proof-r1','verified-archive-handoff-qualification-private-proof-preparation-r1',
    'dispatch-capacity-scope-tar-preparation-r1','dispatch-capacity-scope-tar-validation-r1',
    'current-maintained-capacity-streaming-decoder-preparation-r1','current-maintained-capacity-streaming-decoder-validation-r1'])
names.extend(['process-identity-exit-wait-qualification-private-proof-r1','process-identity-exit-wait-qualification-preparation-r1','process-identity-exit-wait-controller-bridge-preparation-r1'])
workload=json.loads((B/f'{prefix}-{case}-workload-audit-r1/WORKLOAD.json').read_text())
assert(workload['passed'] and workload['uniqueAcceptedOrders']==workload['uniqueTradeEvents']==workload['resultTradeCount']==r['confirmedAcceptedUniqueOrders'])or(r['serverRejected']>0 and workload.get('applicable')is False)
names.extend([f'{prefix}-workload-audit-preparation-r1',f'{prefix}-{case}-workload-audit-r1'])
names.extend(['exitwait-local-sparse-cache-r1','verified-handoff-capacity-admission-preparation-r1',f'{prefix}-admission-private-proof-r1'])
if case=='c1':names.append('verified-handoff-capacity-8000-c1-archive-space-guard-r1')
names=[n.replace('native-private-proof-preparation-r1','native-private-proof-preparation-r2')for n in names]
assert len(set(names))==len(names)
before={n:tree(B/n)for n in names};logical=sum(sum(v['bytes']for v in scope['files'].values())for scope in before.values())
assert logical<12*1024**3 and shutil.disk_usage(R).free>=1024**3+min(logical,1024**3)
T.mkdir();bundle=T/f'handoff-capacity-8000-{case}-complete-original-scopes-r1.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(bundle,before);assert bundle.stat().st_size<1024**3 and all(tree(B/n)==before[n]for n in names)
repo='yinli-systems/vectormatch';releaseId=423510304;tag='evidence-private-20261025'
def api(path):return json.loads(subprocess.check_output(['gh','api',path]))
assert api('repos/'+repo)['private']
release=api('repos/'+repo+'/releases/'+str(releaseId));assert release['draft'] and release['tag_name']==tag
assert not any(a['name']==bundle.name for a in release['assets'])
registration=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,releaseId=releaseId,releaseTag=tag,
    assetName=bundle.name,bytes=bundle.stat().st_size,sha256=sha(bundle),completeScopeMembers=members,oneUploadOnly=True)
(T/'UPLOAD_REGISTRATION.json').write_text(json.dumps(registration,indent=2,sort_keys=True)+'\n')
with(T/'upload.stdout').open('xb')as out,(T/'upload.stderr').open('xb')as err:
    upload=subprocess.run(['gh','release','upload',tag,str(bundle),'--repo',repo],stdout=out,stderr=err,timeout=600)
(T/'UPLOAD_EXECUTION.json').write_text(json.dumps(dict(exitCode=upload.returncode),indent=2)+'\n')
assert upload.returncode==0,'Preserve files and inspect remote asset;no overwrite or blind re-upload'
after=api('repos/'+repo+'/releases/'+str(releaseId));matches=[a for a in after['assets']if a['name']==bundle.name];assert len(matches)==1
asset=matches[0];assert asset['state']=='uploaded' and asset['size']==bundle.stat().st_size and asset['digest']=='sha256:'+sha(bundle)
assert all(tree(B/n)==before[n]for n in names)
A.mkdir(parents=True)
manifest=dict(schemaVersion=1,repository=repo,private=True,draft=True,releaseId=releaseId,releaseTag=tag,assetId=asset['id'],
    assetName=asset['name'],assetApiUrl=asset['url'],bytes=asset['size'],sha256=sha(bundle),serverDigest=asset['digest'],
    localOriginalArchive=str(bundle),caseId=case,codeFingerprint=r['codeFingerprint'],archiveFormat='complete-original-scope-tar-gzip',authenticatedFullDownloadRequired=True)
(A/'ASSET_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(A/'UPLOAD_METADATA.json').write_text(json.dumps(asset,indent=2,sort_keys=True)+'\n')
for name in ('UPLOAD_REGISTRATION.json','UPLOAD_EXECUTION.json','upload.stdout','upload.stderr'):shutil.copy2(T/name,A/name)
for name in ('ROOT_REVIEW.json','RAW_AUDIT.json','READINESS_REVIEW.json'):
    p=A/'root-review'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
shutil.copy2(B/f'{prefix}-{case}-schema-audit-r1/SCHEMA_AUDIT.json',A/'SCHEMA_AUDIT.json')
qualification=A.parent/'qualification-r1'
(A/'SHARED_EVIDENCE_REFERENCES.json').write_text(json.dumps({n:dict(bytes=(qualification/n).stat().st_size,sha256=sha(qualification/n))for n in ('INVENTORY.json','CLOSED.json')},indent=2,sort_keys=True)+'\n')
shutil.copy2(R/'docs/VERIFIED_HANDOFF_CAPACITY_V3.md',A/'REGISTERED_PLAN.md')
(A/'README.md').write_text(f'''# Immutable handoff comparison:{case.upper()} original native/raw evidence

Fresh160,000 IOC arrivals@8000/s for20s;artifact{r['codeFingerprint']}. Accepted{r['confirmedAcceptedUniqueOrders']},notSent{r['notSent']},rejected{r['serverRejected']},observed/final UNKNOWN{r['unknownObserved']}/{r['unknownFinal']};all-arrival p99{r['allArrivalP99Ns']}ns. This is one finite comparison observation,not a sustained-capacity or millisecond-SLA claim.

Every original closed native TAR,CSV,wire/frame/offer,decoder/identity,configuration/readiness/lifecycle and source record is preserved in one complete compressed original-scope TAR. ASSET_MANIFEST identifies the exact private draft-release asset,size,SHA-256 and authenticated API URL;ORIGINAL_SCOPE_INVENTORIES pins every member's bytes/mode/owner/directory. No raw row is sampled or omitted. Git retains the small manifest and audits;the full compressed original body is an attachment under the same private repository. The private progression proof must authenticate and download the entire committed asset,reverify its SHA and all members,before the next case can start. Upload alone does not qualify progression.

Leader0/sync2/ROTATING_CONTINUE/read128/page32/batch4/chunk6144/owner1ms/driver100us/W128Q64,one physical session/three JVMs on the same CPU. Original two2s readiness gates,5s warm-up,cache preconditioning,resource/durability/evidence bounds retained. Complete canonical forced readback and both payload/receipt forces precede either destructive ACK. Candidate-codec checks are not an independent matching oracle or binary cold restore.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),caseId=case,
    inventorySha256=sha(A/'INVENTORY.json'),assetManifestSha256=sha(A/'ASSET_MANIFEST.json'),archiveBytes=bundle.stat().st_size,
    archiveSha256=sha(bundle),originalScopeReview=members,allSourcesUnchanged=True,assetDownloadRequiredBeforeProgression=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,caseId=case,assetId=asset['id'],archiveBytes=bundle.stat().st_size,gitPayloadFiles=len(inv['files']),originalFiles=members['originalFiles'])))
