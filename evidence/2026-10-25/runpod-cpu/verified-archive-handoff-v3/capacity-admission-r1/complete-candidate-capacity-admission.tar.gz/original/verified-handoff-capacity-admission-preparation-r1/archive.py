from pathlib import Path
import datetime
import json
import shutil
import sys
import tarfile

root = Path.cwd()
base = Path(__file__).resolve().parent.parent
preparation = Path(__file__).resolve().parent
target = root / 'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-admission-r1'
assert not target.exists()
sys.path.insert(0, str(base / 'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree, verify, sha

plans = json.loads((preparation / 'PLANS.json').read_text())
parity = json.loads((base / 'verified-handoff-capacity-trade-audit-qualification-r1/RESULT.json').read_text())
assert plans['passed'] and parity['passed'] and parity['fullPositiveResultExactlyMatchesPreviousQualifiedCounter']
assert not (base / 'verified-handoff-capacity-trade-audit-qualification-r1/original-80k-physical-replies.bin').exists()
families = ['controller-generator-r1', 'controller-review-preparation-r1', 'runner-r1',
            'root-review-preparation-r1', 'native-archive-preparation-r1',
            'native-private-proof-preparation-r2', 'local-duplicate-retirement-preparation-r1',
            'bottleneck-preparation-r1', 'recovery-preparation-r1', 'maintenance-phases-preparation-r1',
            'schema-audit-preparation-r1', 'workload-audit-preparation-r1', 'cache-precondition-preparation-r1']
names = [preparation.name, 'verified-handoff-capacity-trade-audit-qualification-r1',
         'process-identity-exit-wait-qualification-private-proof-r1',
         'verified-archive-handoff-exitwait-reporting-private-proof-r1',
         'verified-archive-handoff-qualification-private-proof-r1',
         'verified-archive-handoff-linux-metadata-execution-r1',
         'verified-archive-handoff-linux-metadata-preparation-r1',
         'dispatch-capacity-scope-tar-preparation-r1']
for rate in plans['rates']:
    names.extend(f'verified-handoff-capacity-{rate}-{family}' for family in families)
assert len(names) == len(set(names))
before = {name: tree(base / name) for name in names}
target.mkdir(parents=True)
archive = target / 'complete-candidate-capacity-admission.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=1) as bundle:
    for name in names:
        bundle.add(base / name, arcname='original/' + name)
members = verify(archive, before)
assert all(tree(base / name) == before[name] for name in names)
(target / 'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
shutil.copy2(preparation / 'PLANS.json', target / 'PLANS.json')
for name in ('docs/VERIFIED_HANDOFF_CAPACITY_V3.md',):
    destination = target / 'published' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, destination)
(target / 'README.md').write_text('''# Candidate capacity admission, before orders

The completed4k C1/D1/C2/D2 source/raw/private proofs remain closed. Register only candidate79 source23f9 with the unchanged CI8-qualified51ad/d700/11d sampler and original lifecycle. Actual Linux metadata already records matching rotating/fixed fine-rate plans at6000/7000/7500/8000,for120k/140k/150k/160k fresh20s arrivals. This package does not claim those rates have executed or passed.

All four sets of helper sources and analysis classes are retained. The per-rate controller replaces historical template authority with the exact private admission and prior candidate point;it retains the original artifact's4k code/CI qualification rather than rewriting that record. A separately closed prior point must satisfy zero missing/rejected/unknown,valid timing,>=99% in-window confirmation and global p99<=1s before escalation. Stronger complete interval clearing is reported separately. No rate above8k is admitted.

The new trade counter accepts an explicit expected accepted count. Its four compiled bodies agree;the full80k positive result exactly matches the previously qualified counter on the original D2 tape,and79999/80001/0 expectations are refused. The input is byte-bound to an already fully authenticated original D2 private asset;only a redundant readback copy is retired,with its restore member and SHA retained. Business-rejection cases explicitly mark this simple trade counter inapplicable while preserving authoritative root/raw results;they cannot permit escalation. These are analysis tests,not new orders or a matching oracle.

Complete raw attachments,byte/member verification,resource/retention floors,source/readiness/ownership gates and all invalid observations are retained. This is preparation until a whole-Git private restoration proof creates the exact per-rate admission receipts. No new resource,paid service,GPU,SLA,production or100M claim.
''')
inventory = tree(target)
(target / 'INVENTORY.json').write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
(target / 'CLOSED.json').write_text(json.dumps(dict(
    passed=True, atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    inventorySha256=sha(target / 'INVENTORY.json'), archiveBytes=archive.stat().st_size,
    archiveSha256=sha(archive), scopeReview=members, noOrdersAdmitted=True,
    onlyRegisteredRates=[6000, 7000, 7500, 8000], onlyRegisteredCase='d1',
    candidateCodeFingerprint=plans['codeFingerprint'], higherThan8000Permitted=False,
), indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(passed=True, archiveBytes=archive.stat().st_size,
                     originalFiles=members['originalFiles'], gitPayloadFiles=len(inventory['files']))))
