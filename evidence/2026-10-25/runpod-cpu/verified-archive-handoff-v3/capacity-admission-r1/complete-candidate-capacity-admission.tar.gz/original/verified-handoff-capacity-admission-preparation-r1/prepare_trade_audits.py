from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
base = Path(__file__).resolve().parent.parent
source = (base / 'verified-archive-handoff-exitwait-workload-audit-preparation-r1/DecodeTrades.java').read_text()
source = source.replace('Path input=Path.of(args[0]),output=Path.of(args[1]);long size=Files.size(input);',
                        'Path input=Path.of(args[0]),output=Path.of(args[1]);long size=Files.size(input);'
                        'int accepted=Integer.parseInt(args[2]);require(accepted>=0&&accepted<=350000,"bounded expected accepted count");')
source = source.replace('<=80000', '<=accepted').replace('==80000', '==accepted')
source = source.replace('<=80001', '<=accepted+1').replace('<=160003', '<=2*accepted+3').replace('==160003', '==2*accepted+3')
assert '80000' not in source and '160003' not in source and '80001' not in source
lib = base / 'verified-archive-handoff-artifact-preparation-r1/lib'
dependencies = ':'.join(str((lib / name).resolve()) for name in ('aeron-all-1.53.3.jar', 'agrona-2.6.1.jar',
                                                              'cluster-0.1.0-SNAPSHOT.jar', 'core-0.1.0-SNAPSHOT.jar'))
for rate in (6000, 7000, 7500, 8000):
    prefix = f'verified-handoff-capacity-{rate}'
    folder = base / f'{prefix}-workload-audit-preparation-r1'
    assert not (folder / 'classes').exists()
    (folder / 'DecodeTrades.java').write_text(source)
    args = [str((root / '.tools/jdk/bin/javac').resolve()), '-cp', dependencies,
            '-d', str(folder / 'classes'), str(folder / 'DecodeTrades.java')]
    completed = subprocess.run(args, capture_output=True, text=True, timeout=30)
    (folder / 'compile.stdout').write_text(completed.stdout)
    (folder / 'compile.stderr').write_text(completed.stderr)
    assert completed.returncode == 0, completed.stderr
    runner = folder / 'run.py'
    body = runner.read_text().replace("str(input),str(O/'WORKLOAD.json')]",
                                     "str(input),str(O/'WORKLOAD.json'),str(review['confirmedAcceptedUniqueOrders'])]")
    body = body.replace(f"result['resultTradeCount']=={rate*20}", "result['resultTradeCount']==review['confirmedAcceptedUniqueOrders']")
    # A business rejection is outside this simple one-filled-IOC trade counter.
    # Preserve a structured unsupported audit; root/raw still retain the actual result.
    marker = 'with(O/\'stdout\').open(\'xb\')'
    assert marker in body
    body = body.replace(marker, """if review['serverRejected']:
 (O/'WORKLOAD.json').write_text(json.dumps(dict(passed=False,applicable=False,reason='Business rejection requires a separately qualified mixed-result trade counter;original root/raw outcomes remain authoritative',accepted=review['confirmedAcceptedUniqueOrders'],serverRejected=review['serverRejected']),indent=2)+'\\n')
 print(json.dumps(dict(passed=False,applicable=False,serverRejected=review['serverRejected'])));sys.exit(0)
""" + marker)
    runner.write_text(body)
    archive = base / f'{prefix}-native-archive-preparation-r1/archive.py'
    body = archive.read_text()
    body = body.replace(f"assert workload['passed'] and workload['uniqueAcceptedOrders']==workload['uniqueTradeEvents']==workload['resultTradeCount']=={rate*20}",
                        "assert(workload['passed'] and workload['uniqueAcceptedOrders']==workload['uniqueTradeEvents']==workload['resultTradeCount']==r['confirmedAcceptedUniqueOrders'])or(r['serverRejected']>0 and workload.get('applicable')is False)")
    archive.write_text(body)
    diagnostic = base / f'{prefix}-bottleneck-preparation-r1/analyze.py'
    body = diagnostic.read_text().replace("assert q(acceptedLatencies,.99)==review['allArrivalP99Ns']", 
                                         "assert q(acceptedLatencies,.99)==review['acceptedOrderConditionalP99Ns']")
    diagnostic.write_text(body)
print(json.dumps(dict(passed=True,allFourSourcesIdentical=True,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),
                      dynamicAcceptedCount=True,noRemoteActions=True,noPerformanceRun=True)))
