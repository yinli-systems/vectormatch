"""Prepare fixed-rate helper families. No cloud action or order admission."""
from pathlib import Path
import ast
import json
import re
import shutil

base = Path(__file__).resolve().parent.parent
plans = json.loads((Path(__file__).parent / 'PLANS.json').read_text())
families = [
    'controller-generator-r1', 'controller-review-preparation-r1', 'runner-r1',
    'root-review-preparation-r1', 'native-archive-preparation-r1',
    'native-private-proof-preparation-r2', 'local-duplicate-retirement-preparation-r1',
    'bottleneck-preparation-r1', 'recovery-preparation-r1', 'maintenance-phases-preparation-r1',
    'schema-audit-preparation-r1', 'workload-audit-preparation-r1', 'cache-precondition-preparation-r1',
]
for rate_text in plans['rates']:
    rate = int(rate_text)
    prefix = f'verified-handoff-capacity-{rate}'
    for family in families:
        original = base / ('verified-archive-handoff-exitwait-' + family)
        target = base / (prefix + '-' + family)
        assert not target.exists()
        shutil.copytree(original, target, ignore=shutil.ignore_patterns('__pycache__', 'classes'))
        for file in target.rglob('*'):
            if not file.is_file() or file.suffix not in ('.py', '.java', '.json'):
                continue
            source = file.read_text()
            source = source.replace('verified-archive-handoff-exitwait', prefix)
            source = source.replace('handoff-exitwait-', f'handoff-capacity-{rate}-')
            source = source.replace('exitwait-arm-', f'capacity-{rate}-arm-')
            source = source.replace('VERIFIED_ARCHIVE_HANDOFF_EXIT_WAIT_V3', 'VERIFIED_HANDOFF_CAPACITY_V3')
            source = re.sub(r'\b4000\b', str(rate), source)
            source = re.sub(r'\b80000\b', str(rate * 20), source)
            source = re.sub(r'\b80001\b', str(rate * 20 + 1), source)
            source = re.sub(r'\b160003\b', str(rate * 40 + 3), source)
            source = source.replace('80,000', f'{rate * 20:,}').replace('80000@', f'{rate * 20}@')
            # Original artifact qualification remains the closed4k code/CI proof.
            source = source.replace(f"qualified['fixedPlanComparisonRate']=={rate}",
                                    "qualified['fixedPlanComparisonRate']==4000")
            file.write_text(source)

    generator = base / f'{prefix}-controller-generator-r1/generate.py'
    source = generator.read_text()
    source = source.replace('assert case in cases', "assert case=='d1'")
    source = source.replace("previous=cases[cases.index(case)-1]if case!='c1'else None", 'previous=None')
    source = source.replace('process-identity-exit-wait-qualification-private-proof-r1',
                            f'verified-handoff-capacity-{rate}-admission-private-proof-r1')
    source = source.replace("sampler['onlyRegisteredCases']==list(cases)", "sampler['onlyRegisteredCases']==['d1']")
    marker = "s=(O/'first_pilot.py').read_text().replace("
    assert marker in source
    source = source.replace(marker, """# Discard historical template authority; replace it with this curve's private admission.
for old in O.glob('prior-*.json'):old.unlink()
for key in ('priorQualification','adoptionPrivateProofSha256'):release.pop(key,None)
(O/'release.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\\n')
template=(O/'first_pilot.py').read_text()
begin=template.index("        adoption=json.loads((HERE/'adoption-private-proof.json')")
end=template.index('        idle=m.strict_idle(b);protected=m.protected_state(b,r)',begin)
(O/'first_pilot.py').write_text(template[:begin]+template[end:])
""" + marker)
    # The first point derives from completed4k; later points require closed finite progression.
    marker = 'bridge=B/'
    index = source.index(marker)
    source = source[:index] + """requireRate=sampler['onlyRegisteredRate'];assert requireRate==RATE
curvePrevious=sampler['priorRate']
curveProof=None
if curvePrevious is not None:
    curveProof=B/f'verified-handoff-capacity-{curvePrevious}-d1-private-proof-r1/PRIVATE_PUSH.json'
    cp=json.loads(curveProof.read_text())
    assert cp['passed']and cp['private']and cp['finiteProgressionPermitted']and cp['nextRegisteredRate']==RATE
    assert cp['codeFingerprint']==meta['actualCodeFingerprint']and cp['completeAuthenticatedAssetDownloadVerified']
""".replace('RATE', str(rate)) + source[index:]
    marker = "shutil.copy2(samplerPath,O/'sampler-qualification-private.json')"
    source = source.replace(marker, marker + "\nif curveProof is not None:shutil.copy2(curveProof,O/'curve-prior-private.json')")
    marker = "        qualified=json.loads((HERE/'handoff-qualification-private.json').read_text());"
    assert marker in source
    source = source.replace(marker, """        require(sampler['onlyRegisteredRate']==RATE and sampler['newComparisonPrefix']=='PREFIX','Exact prospective capacity admission required')
        if sampler['priorRate'] is not None:
            prior=json.loads((HERE/'curve-prior-private.json').read_text())
            require(prior['passed']and prior['private']and prior['completeAuthenticatedAssetDownloadVerified']and prior['finiteProgressionPermitted']and prior['nextRegisteredRate']==RATE and prior['codeFingerprint']==r['codeFingerprint'],'Previous actual candidate point must permit this rate')
""".replace('RATE', str(rate)).replace('PREFIX', prefix) + marker)
    generator.write_text(source)

    archive = base / f'{prefix}-native-archive-preparation-r1/archive.py'
    source = archive.read_text().replace(f"'{prefix}-native-private-proof-preparation-r1'", f"'{prefix}-native-private-proof-preparation-r2'")
    # The archive family constructs this reference from prefix plus a suffix.
    source = source.replace("'native-private-proof-preparation'", "'native-private-proof-preparation-r2-marker'")
    source = source.replace("names.extend([f'{prefix}-{n}-r1'", "names.extend([f'{prefix}-{n}-r1'")
    source = source.replace("'native-private-proof-preparation-r2-marker'", "'native-private-proof-preparation'")
    source = source.replace("assert len(set(names))==len(names)", "names=[n.replace('native-private-proof-preparation-r1','native-private-proof-preparation-r2')for n in names]\nassert len(set(names))==len(names)")
    archive.write_text(source)
    for family in families:
        for file in (base / f'{prefix}-{family}').rglob('*.py'):
            ast.parse(file.read_text(), filename=str(file))
print(json.dumps(dict(passed=True, preparedRates=list(plans['rates']), familiesPerRate=len(families),
                      allPythonSyntaxParsed=True, noCloudActions=True, noOrdersAdmitted=True)))
