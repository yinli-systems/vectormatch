from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent.parent
output = Path(__file__).resolve().parent / 'PLANS.json'
assert not output.exists()
sampler_file = base / 'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json'
comparison_file = base / 'verified-archive-handoff-exitwait-reporting-private-proof-r1/PRIVATE_PUSH.json'
sampler = json.loads(sampler_file.read_text())
comparison = json.loads(comparison_file.read_text())
assert sampler['passed'] and comparison['passed'] and comparison['campaignComplete']
assert comparison['repeatedFiniteP99AndMaintenanceReduction']
metadata = json.loads((base / 'verified-archive-handoff-linux-metadata-execution-r1/actual-linux-observation.json').read_text())
previous = {6000: None, 7000: 6000, 7500: 7000, 8000: 7500}
rows = {}
for rate, predecessor in previous.items():
    release = json.loads((base / f'dispatch-capacity-controller-{rate}-preparation-r1/release.json').read_text())
    observed = metadata['dispatchCapacityConfigs'][str(rate)]
    assert observed['fixed']['plan'] == observed['rotating']['plan'] == release['derivedPlan']
    assert observed['rotating']['arrivals'] == rate * 20
    assert not release['derivedPlan']['admissionRejections']
    rows[str(rate)] = dict(rate=rate, arrivals=rate * 20, namespacePrefix=f'verified-handoff-capacity-{rate}',
                           plan=release['derivedPlan'], onlyRegisteredCase='d1', priorRate=predecessor)
result = dict(passed=True, preparationOnly=True, noOrdersAdmitted=True,
              codeFingerprint=metadata['actualCodeFingerprint'], sourceCommit=metadata['sourceCommit'], rates=rows,
              samplerPrivateProofSha256=hashlib.sha256(sampler_file.read_bytes()).hexdigest(),
              completedComparisonPrivateProofSha256=hashlib.sha256(comparison_file.read_bytes()).hexdigest(),
              allOriginalBoundsRetained=True, noAppArtifactOrLifecycleSourceChange=True)
output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'rates'}))
