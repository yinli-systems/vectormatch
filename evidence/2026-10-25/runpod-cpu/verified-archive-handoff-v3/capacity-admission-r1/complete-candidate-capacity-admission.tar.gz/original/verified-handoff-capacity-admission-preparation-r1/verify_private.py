from pathlib import Path
import datetime
import json
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent.parent
target = root / 'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-admission-r1'
output = base / 'verified-handoff-capacity-admission-private-proof-r1'
assert not output.exists()
sys.path.insert(0, str(base / 'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree, verify, sha

def git(*args):
    return subprocess.check_output(['git', *args])

head = git('rev-parse', 'HEAD').decode().strip()
for branch in ('main', 'codex/production-correctness-and-maintenance'):
    assert git('ls-remote', 'origin', 'refs/heads/' + branch).decode().split()[0] == head
assert json.loads(subprocess.check_output(['gh', 'api', 'repos/yinli-systems/vectormatch']))['private']
inventory = json.loads((target / 'INVENTORY.json').read_text())
closed = json.loads((target / 'CLOSED.json').read_text())
actual = tree(target)
assert closed['passed'] and closed['inventorySha256'] == sha(target / 'INVENTORY.json')
assert closed['noOrdersAdmitted'] and closed['onlyRegisteredRates'] == [6000, 7000, 7500, 8000]
assert set(actual['files']) == set(inventory['files']) | {'INVENTORY.json', 'CLOSED.json'}
assert actual['directories'] == inventory['directories']
assert all(actual['files'][name] == row for name, row in inventory['files'].items())
prefix = target.relative_to(root).as_posix()
blobs = {}
for entry in git('ls-tree', '-r', '-z', head, '--', prefix).split(b'\0'):
    if entry:
        metadata, name = entry.split(b'\t', 1)
        blobs[name.decode()] = metadata.split()[2].decode()
paths = sorted(blobs)
assert set(paths) == {prefix + '/' + name for name in actual['files']}
assert git('hash-object', '--', *paths).decode().splitlines() == [blobs[name] for name in paths]
assert git('show', head + ':docs/VERIFIED_HANDOFF_CAPACITY_V3.md') == (target / 'published/docs/VERIFIED_HANDOFF_CAPACITY_V3.md').read_bytes()
output.mkdir()
restored = output / 'restored-admission.tar.gz'
with restored.open('xb') as destination:
    subprocess.run(['git', 'cat-file', 'blob', head + ':' + prefix + '/complete-candidate-capacity-admission.tar.gz'],
                   stdout=destination, check=True)
assert restored.stat().st_size == closed['archiveBytes'] and sha(restored) == closed['archiveSha256']
members = verify(restored, json.loads((target / 'ORIGINAL_SCOPE_INVENTORIES.json').read_text()))
assert members == closed['scopeReview']
restored.unlink()

sampler_path = base / 'process-identity-exit-wait-qualification-private-proof-r1/PRIVATE_PUSH.json'
comparison_path = base / 'verified-archive-handoff-exitwait-reporting-private-proof-r1/PRIVATE_PUSH.json'
sampler = json.loads(sampler_path.read_text())
comparison = json.loads(comparison_path.read_text())
plans = json.loads((target / 'PLANS.json').read_text())
assert sha(sampler_path) == plans['samplerPrivateProofSha256']
assert sha(comparison_path) == plans['completedComparisonPrivateProofSha256']
assert sampler['passed'] and sampler['controllerBridgeQualified'] and sampler['actualOwnedPidfdProbePassed']
assert comparison['passed'] and comparison['campaignComplete'] and comparison['repeatedFiniteP99AndMaintenanceReduction']
assert comparison['allFourNativeAssetsPreviouslyFullyAuthenticatedAndMemberVerified']
for prior in (sampler, comparison):
    subprocess.run(['git', 'merge-base', '--is-ancestor', prior['commit'], head], check=True)

receipt = dict(passed=True, private=True, repository='yinli-systems/vectormatch', commit=head,
               atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), bothRemoteBranchesVerified=True,
               allQualificationGitBlobsVerified=len(paths), restoredWholeScopeArchiveFromActualGitBlob=True,
               allOriginalScopeMembersVerified=members, noOrdersAdmitted=True,
               registeredRates=[6000, 7000, 7500, 8000], higherThan8000Permitted=False,
               samplerSourceUnchanged=True, samplerPrivateProofSha256=sha(sampler_path),
               completedComparisonPrivateProofSha256=sha(comparison_path), sourceSha256=sha(Path(__file__)))
(output / 'PRIVATE_PUSH.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
for rate, plan in plans['rates'].items():
    destination = base / f'verified-handoff-capacity-{rate}-admission-private-proof-r1'
    assert not destination.exists()
    destination.mkdir()
    scoped = dict(sampler)
    scoped.update(receipt)
    scoped.update(newComparisonPrefix=plan['namespacePrefix'], onlyRegisteredCases=['d1'],
                  onlyRegisteredRate=int(rate), fixedPlanComparisonRate=int(rate), priorRate=plan['priorRate'],
                  candidateCodeFingerprint=plans['codeFingerprint'], candidateSourceCommit=plans['sourceCommit'],
                  candidatePlan=plan['plan'], newComparisonExecuted=False,
                  inheritedSamplerQualificationCommit=sampler['commit'],
                  scopedAdmissionIsNewAndPriorFrozenRegistrationsUnchanged=True)
    (destination / 'PRIVATE_PUSH.json').write_text(json.dumps(scoped, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt))
