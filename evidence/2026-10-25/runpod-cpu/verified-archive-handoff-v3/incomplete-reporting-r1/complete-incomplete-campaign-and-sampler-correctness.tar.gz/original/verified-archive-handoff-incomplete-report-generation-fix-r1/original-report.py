from pathlib import Path
import copy,datetime,hashlib,json

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-archive-handoff-incomplete-reporting-r1';assert not O.exists()
pins={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):pins[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p));return json.loads(p.read_text())
old=read(R/'evidence/index.json');assert len(old['runs'])==55 and len(old['capacityCohorts'])==22
rows=[]
for case in ('c1','d1','c2'):
    invalid=case=='c2';P=B/f'verified-archive-handoff-cdcd-{case}-root-review-r1'
    proof=read(B/f'verified-archive-handoff-cdcd-{case}-'+('invalid-private-proof-r1'if invalid else'private-proof-r1')+'/PRIVATE_PUSH.json')
    root=read(P/'ROOT_REVIEW.json');raw=read(P/'RAW_AUDIT.json')
    schema=read(B/f'verified-archive-handoff-cdcd-{case}-schema-audit-r1/SCHEMA_AUDIT.json')
    workload=read(B/f'verified-archive-handoff-cdcd-{case}-workload-audit-r1/WORKLOAD.json')
    load=P/'materialized/attempt-4000/idle-arm/load';cfg=read(load/'configuration.json');summary=read(load/'load-result.json')
    assert all(x['passed']for x in (proof,root,raw,schema,workload)) and proof['private'] and proof['completeAuthenticatedAssetDownloadVerified']
    assert root['nativeControlPassed']is(not invalid) and root['performanceQualified']is(not invalid)
    assert root['confirmedAcceptedUniqueOrders']==workload['uniqueAcceptedOrders']==workload['uniqueTradeEvents']==80000
    assert root['notSent']==root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0
    assert proof['knownOutcomeQualified']is(not invalid)
    archive=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/arm-{case}-'+('invalid-native-r1'if invalid else'native-r1')
    asset=read(archive/'ASSET_MANIFEST.json');scopes=read(archive/'ORIGINAL_SCOPE_INVENTORIES.json')
    wire=scopes[f'verified-archive-handoff-cdcd-{case}-root-review-r1']['files']['materialized/attempt-4000/idle-arm/load/physical-replies.bin']
    assert workload['replySha256']==wire['sha256'] and workload['replyBytes']==wire['bytes']
    if invalid:
        assert proof['nativeControlPassed']is False and proof['nextRunQualified']is False and proof['nextRegisteredCase']is None
        read(B/'verified-archive-handoff-c2-invalid-review-r1/INVALID_CONTROL_REVIEW.json');cut=diag=None
    else:
        cut=read(B/f'verified-archive-handoff-cdcd-{case}-cut-recovery-r1/RECOVERY.json')
        diag=read(B/f'verified-archive-handoff-cdcd-{case}-bottleneck-r1/DIAGNOSIS.json')
        read(B/f'verified-archive-handoff-cdcd-{case}-maintenance-phases-r1/PHASES.json')
    rows.append(dict(caseId=case,valid=not invalid,codeFingerprint=root['codeFingerprint'],sourceCommit=proof['sourceCommit'],
        privateCommit=proof['commit'],assetId=asset['assetId'],assetBytes=asset['bytes'],assetSha256=asset['sha256'],
        planned=80000,accepted=80000,trades=80000,goodput=root['arrivalWindowGoodputPerSecond'],p50Ns=root['allArrivalP50Ns'],
        diagnosticAllArrivalP99Ns=root['allArrivalP99Ns'],afterOfferP99Ns=None if invalid else diag['afterFirstPositiveOfferReturnP99Ns'],
        globalQualifiedP99Ns=None if invalid else root['allArrivalP99Ns'],maintenanceWallNs=schema['maintenanceWallNs'],
        archiveWriterPrevalidationNs=schema['writerTotals']['archive']['PrevalidationNs'],writerTotals=schema['writerTotals'],
        coordinatorArchiveVerificationNs=schema['coordinatorArchiveVerificationNs'],nativeErrors=root['nativeControlErrors'],
        fullOfferedCutIntervals=None if invalid else cut['fullOfferedEquivalentCutIntervals'],clearingIntervals=None if invalid else cut['intervalsReachingZeroRecordedWaiting'],
        sampledQueueHigh=root['sampledBacklogHighWater'],drainNs=summary['lastKnownReplyDrainNs'],scheduledOriginUTC=cfg['scheduledOriginUTC'],
        archivePath=archive.relative_to(R).as_posix(),workload=workload))
data=copy.deepcopy(old)
for letter,description in (('c','timing control'),('d','immutable handoff candidate')):
    selected=[r for r in rows if r['caseId'].startswith(letter)]
    cohort=dict(id=f'cpu-handoff-initial-{letter}-4000-20s',title=f'Initial handoff comparison · {description}',updatedAt=selected[-1]['scheduledOriginUTC'],
        configurationFingerprint=selected[0]['codeFingerprint'],reportPath='docs/VERIFIED_ARCHIVE_HANDOFF_INITIAL_RESULTS_V3.md',
        scope='Original process sampler. C1/D1 valid;C2 invalid due incomplete process identity;D2 never executed.4,000/s,fresh80,000-order20s lineages,one physical session/three JVMs on one CPU host. Same leader0/sync2/read128/page32/batch4/chunk6144/owner1ms/driver100us/W128Q64/readiness/warm-up/cache procedure. Incomplete comparison;no repeatable optimization,sustained-capacity or SLA claim.',points=[])
    for r in selected:
        identity='cpu-handoff-initial-'+r['caseId'];invalid=not r['valid']
        data['runs'].append(dict(id=identity,label=f"Initial handoff · {r['caseId'].upper()}"+(' · INVALID process observation'if invalid else''),
            scope='80,000 original orders/trades reconciled;'+('native control invalid'if invalid else'finite20s comparison'),
            model='One CPU host · three JVMs · loopback UDP · one physical session',commands=80000,throughput=r['goodput'],
            p50Millis=r['p50Ns']/1e6,p99Millis=r['diagnosticAllArrivalP99Ns']/1e6,unknown=0,correctnessPassed=r['valid'],
            durability='sync2;full canonical force/readback and payload/receipt completion before both ACKs',timestamp=r['scheduledOriginUTC'],
            artifactPath=r['archivePath']+'/README.md',limitations=[
                'Synthetic one-unit IOC executions against one pre-funded seeded maker at10 ticks;80,000 unique trade events agree with original order outcomes. Not a multi-level/cancel or external-venue workload.',
                'C2 retains nativeControlPassed=false and performanceQualified=false although every business outcome reconciles. Its latency is diagnostic only. D2 never executes.',
                'First pair p99 drops2.90%,but after-positive-offer p99 worsens11.07→17.01ms. One pair is not a repeated optimization or significance result.',
                f"Complete original native/raw scope asset{r['assetId']} fully authenticated-downloaded/member-verified at{r['privateCommit']};all0 notSent/rejection/observed/final UNKNOWN.",
                'All previous cohorts retained.128 logical workers are one physical session;no physical-host isolation,millisecond SLA,production certification or100M proof.']))
        cohort['points'].append(dict(id=identity,rate=4000,workers=128,goodput=r['goodput'],p99Millis=r['diagnosticAllArrivalP99Ns']/1e6,
            allOfferedAcceptedP99Millis=None if invalid else r['globalQualifiedP99Ns']/1e6,clientNotSent=0,rejected=0,serverErrors=0,
            unknown=0,unresolved=0,drainSeconds=r['drainNs']/1e9,classification='INVALID_PROCESS_IDENTITY_OBSERVATION'if invalid else'FINITE_20S_COMPARISON_INCOMPLETE',
            peakBacklog=r['sampledQueueHigh'],valid=r['valid'],stable=None,windowSeconds=20))
    data['capacityCohorts'].append(cohort)
data['runs'][55:]=sorted(data['runs'][55:],key=lambda r:('c1','d1','c2').index(r['id'].removeprefix('cpu-handoff-initial-')))
assert data['runs'][:55]==old['runs'] and data['capacityCohorts'][:22]==old['capacityCohorts'] and data['capacity']==old['capacity']
assert len(data['runs'])==58 and len(data['capacityCohorts'])==24
assert all(Path(n).stat().st_size==v['bytes'] and sha(Path(n))==v['sha256']for n,v in pins.items())
O.mkdir();(O/'index-before.json').write_bytes((R/'evidence/index.json').read_bytes());(O/'index-derived.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),campaignComplete=False,executedCases=['c1','d1','c2'],unexecutedCases=['d2'],
    observations=rows,firstPairP99DeltaNs=rows[1]['diagnosticAllArrivalP99Ns']-rows[0]['diagnosticAllArrivalP99Ns'],
    firstPairAfterOfferP99DeltaNs=rows[1]['afterOfferP99Ns']-rows[0]['afterOfferP99Ns'],all55PriorRunsAnd22CohortsPreserved=True,
    records=58,cohorts=24,repeatableOptimizationEstablished=False,inputs=pins,sourceSha256=sha(Path(__file__)))
(O/'COMPARISON.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,campaignComplete=False,records=58,cohorts=24,firstPairP99DeltaNs=result['firstPairP99DeltaNs'],firstPairAfterOfferP99DeltaNs=result['firstPairAfterOfferP99DeltaNs'])))
