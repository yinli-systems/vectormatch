from pathlib import Path
import datetime,hashlib,json,shutil,stat,subprocess,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3';report=A/'incomplete-reporting-r1';O=B/'verified-archive-handoff-incomplete-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo='yinli-systems/vectormatch';assert json.loads(subprocess.check_output(['gh','api','repos/'+repo]))['private']
def package(p):
    inv=json.loads((p/'INVENTORY.json').read_text());closed=json.loads((p/'CLOSED.json').read_text());actual=tree(p)
    assert closed['passed'] and closed['inventorySha256']==sha(p/'INVENTORY.json')
    assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories']
    assert all(actual['files'][n]==v for n,v in inv['files'].items());prefix=p.relative_to(R).as_posix();blobs={}
    for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
        if row:
            meta,name=row.split(b'\t',1);assert meta.split()[1]==b'blob';blobs[name.decode()]=meta.split()[2].decode()
    names=sorted(blobs);assert set(names)=={prefix+'/'+n for n in actual['files']}
    assert git('hash-object','--',*names).decode().splitlines()==[blobs[n]for n in names]
    return closed,len(names)
closed,count=package(report);assert closed['campaignComplete']is False and closed['invalidCases']==['c2'] and closed['unexecutedCases']==['d2']
published=['README.md','docs/VERIFIED_ARCHIVE_HANDOFF_INITIAL_RESULTS_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md','docs/PRODUCTION_CORRECTNESS_RESULTS.md','docs/PRODUCTION_ACCEPTANCE.md','evidence/index.json']
for n in published:assert git('show',head+':'+n)==(R/n).read_bytes()==(report/'published'/n).read_bytes()
index=json.loads((R/'evidence/index.json').read_text());assert len(index['runs'])==58 and len(index['capacityCohorts'])==24
O.mkdir();restored=O/'restored-reporting.tar.gz';prefix=report.relative_to(R).as_posix()
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/complete-incomplete-campaign-and-sampler-correctness.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes'] and sha(restored)==closed['archiveSha256']
members=verify(restored,json.loads((report/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview']
with tarfile.open(restored)as outer:
    ciPrefix='original/production-ci-attempt-7-collection-r1/'
    manifest=json.load(outer.extractfile(ciPrefix+'remote-manifest.json'));seen=set()
    with tarfile.open(fileobj=outer.extractfile(ciPrefix+'complete-code-compiled-tests-and-public-logs.tar.gz'),mode='r|gz')as nested:
        for item in nested:
            assert item.isfile()and item.name.startswith('original/');n=item.name[len('original/'):];assert n not in seen and n in manifest['originalFiles'];seen.add(n);pin=manifest['originalFiles'][n]
            h=hashlib.sha256();stream=nested.extractfile(item)
            for block in iter(lambda:stream.read(1024**2),b''):h.update(block)
            assert item.size==pin['bytes']and h.hexdigest()==pin['sha256']and stat.S_IMODE(item.mode)==pin['mode']and item.uid==pin['uid']and item.gid==pin['gid']
    assert seen==set(manifest['originalFiles'])
restored.unlink();native=[]
for case in ('c1','d1','c2'):
    invalid=case=='c2';point=A/(f'arm-{case}-'+('invalid-native-r1'if invalid else'native-r1'));_,pointCount=package(point)
    asset=json.loads(git('show',head+':'+point.relative_to(R).as_posix()+'/ASSET_MANIFEST.json'))
    assert asset['repository']==repo and asset['private']and asset['draft']and asset['releaseId']==423510304 and asset['caseId']==case
    remote=json.loads(subprocess.check_output(['gh','api','repos/'+repo+'/releases/assets/'+str(asset['assetId'])]))
    assert remote['name']==asset['assetName'] and remote['state']=='uploaded'and remote['size']==asset['bytes']and remote['digest']=='sha256:'+asset['sha256']
    assert shutil.disk_usage(R).free>asset['bytes']+1024**3
    download=O/f'authenticated-{case}.tar.gz'
    with download.open('xb')as out,(O/f'{case}-download.stderr').open('xb')as err:
        result=subprocess.run(['gh','api','repos/'+repo+'/releases/assets/'+str(asset['assetId']),'-H','Accept: application/octet-stream'],stdout=out,stderr=err,timeout=300)
    assert result.returncode==0 and download.stat().st_size==asset['bytes']and sha(download)==asset['sha256']
    original=verify(download,json.loads((point/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()))
    assert original==json.loads((point/'CLOSED.json').read_text())['originalScopeReview']
    root=json.loads((point/'root-review/ROOT_REVIEW.json').read_text());assert root['nativeControlPassed']is(not invalid) and root['performanceQualified']is(not invalid)
    row=dict(caseId=case,valid=not invalid,assetId=asset['assetId'],bytes=asset['bytes'],sha256=asset['sha256'],gitManifestBlobsVerified=pointCount,
        completeAuthenticatedDownloadFromCommittedManifestVerified=True,originalScopeMembersVerified=original,onlyGeneratedDownloadRemoved=True)
    (O/f'NATIVE_{case}.json').write_text(json.dumps(row,indent=2,sort_keys=True)+'\n');download.unlink();native.append(row)
ci=json.loads((report/'FORCED_CI7_REVIEW.json').read_text());assert ci['passed']and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0)and ci['pythonTests']==189 and ci['allTestTasksExecutedWithoutResultCache']
assert not git('diff','--name-only',ci['sourceCommit'],head,'--','scripts','.github','core/src','cluster/src','server/src','projector/src','bench/src','web')
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,private=True,commit=head,bothRemoteBranchesVerified=True,
    reportingGitBlobsVerified=count,reportingRestoredFromActualGitBlob=True,allOriginalReportingMembersVerified=members,all786NestedCi7OriginalFilesVerified=len(seen),
    native=native,allThreeNativeAssetsRestoredAndEveryMemberVerified=True,campaignComplete=False,validCases=['c1','d1'],invalidCases=['c2'],unexecutedCases=['d2'],
    originalInvalidQualificationRetained=True,repeatableOptimizationEstablished=False,all55PriorRunsAnd22CohortsPreserved=True,records=58,cohorts=24,
    allTestTasksActuallyExecuted=True,forcedCiSourceCommit=ci['sourceCommit'],junit=ci['junit'],pythonTests=189,pythonSkipped=0,
    browserRenderVerified=False,higherLoadPermitted=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='native'}))
