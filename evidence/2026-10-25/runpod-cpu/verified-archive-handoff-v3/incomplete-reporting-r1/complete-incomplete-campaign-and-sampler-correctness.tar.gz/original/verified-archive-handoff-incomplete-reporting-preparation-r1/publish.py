from pathlib import Path
import datetime,hashlib,json,urllib.request
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-archive-handoff-incomplete-reporting-r1'
assert not(O/'APPLIED.json').exists();c=json.loads((O/'COMPARISON.json').read_text())
assert c['passed'] and c['campaignComplete']is False and c['unexecutedCases']==['d2']
assert (R/'evidence/index.json').read_bytes()==(O/'index-before.json').read_bytes()
text='''# Immutable handoff: initial comparison remains incomplete

The registered C1/D1/C2/D2 campaign stops after C2 fails its process-identity observation gate. C1 and D1 are valid finite observations;C2 remains invalid and D2 never executes. The candidate removes repeated archive prevalidation,but this campaign does not establish a repeatable performance gain.

Each executed arm uses80,000 fresh one-unit IOC orders at4,000 scheduled arrivals/s for20s,against one pre-funded seeded sell order at10 ticks. Original order outcomes agree with80,000 distinct trade events in each arm. This is a real path through the synthetic matching engine,with one price/maker/fill per order;it is not a multi-level,cancel/replace,external-venue or funded-trading workload.

Leader0,sync2,ROTATING_CONTINUE,read128,page32,batch4,chunk6144,owner1ms,driver100us,W128/Q64,one physical session and three JVMs on one CPU host remain fixed. All use the original process sampler,the same pinned JDK/boot/affinity/cgroups,two2s readiness observations around setup/5s warm-up,and the same project-only cache preconditioning. No JFR. C uses timing sourceaed9430d/codef3a5745c;D uses CI6-qualified source23f9c070/code79e5a932. Full payload/receipt force and canonical readback precede either destructive ACK.

| Arm | Native control | Accepted orders / trade events | In-window goodput/s | Qualified all-arrival p99 ms | Diagnostic p99 ms | After-positive-offer p99 ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for r in c['observations']:
    qualified='—'if not r['valid']else f"{r['globalQualifiedP99Ns']/1e6:.6f}"
    after='—'if r['afterOfferP99Ns']is None else f"{r['afterOfferP99Ns']/1e6:.6f}"
    text+=f"| {r['caseId'].upper()} | {'Valid finite observation'if r['valid']else'INVALID process identity'} | 80,000 / 80,000 | {r['goodput']:.2f} | {qualified} | {r['diagnosticAllArrivalP99Ns']/1e6:.6f} | {after} |\n"
first,second=c['observations'][:2]
text+=f'''
All three arms reconcile every planned original outcome,with zero notSent,rejection,observed UNKNOWN or final UNKNOWN. C1/D1 each clear recorded waiting in23/23 comparable offered-cut intervals. All outcomes and invalid status remain visible;the C2 diagnostic quantile cannot substitute for a qualified performance observation.

## What the first pair establishes

Scheduled-to-confirmation p99 changes by{(second['diagnosticAllArrivalP99Ns']/first['diagnosticAllArrivalP99Ns']-1)*100:.2f}%;maintenance wall changes5.561833365→5.333869314s over27 cycles. Repeated archive prevalidation changes0.990036012→0.000017659s;the immutable handoff flag and zero handoff-copy duration are present in every D1 archive cycle. Complete forced canonical readback and receipt metrics still verify.

Other measured phases become slower:archive readback0.666567529→1.077229423s;event prevalidation0.134192534→0.227562981s;event readback0.144072792→0.239359550s. After-positive-offer p99 increases11.069032→17.014943ms. The phase distributions show persistent differences beyond the first cycle. These observations do not isolate CPU scheduling,JIT,GC,NUMA,network or storage as the cause. Removed work is not a prediction of end-to-end savings. One pair,especially with this tradeoff,is insufficient to claim an extreme or repeatable optimization.

## Why C2 stays invalid

The original controller records`Incomplete process identity`during execution,without the PID/read phase. All four owned JVMs subsequently stop cleanly,and independent raw-byte checks verify all80,000 orders/trades,zero unknown and matching three-node snapshot logs. Nevertheless,the original nativeControlPassed and performanceQualified values remain false. No waiver,rerun of that lineage or valid reclassification is applied.

An independent controlled exit interleaving reproduces the exact old sampler exception. The [identity observation fix](PROCESS_IDENTITY_OBSERVATION.md) binds reads to one proc directory descriptor,rechecks birth/exit state and still refuses malformed live identities. The exact historical C2 trigger remains unproved. A common qualified sampler and new exclusive lineages are required for a fresh full comparison;D2 of this incomplete campaign remains unexecuted.

## Complete private evidence

'''
for r in c['observations']:
    text+=f"- [{r['caseId'].upper()} complete original archive](../{r['archivePath']}/README.md):asset{r['assetId']},{r['assetBytes']:,} bytes,SHA-256`{r['assetSha256']}`,full authenticated download/member verification at`{r['privateCommit']}`.\n"
text+='''
The [reporting package](../evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/incomplete-reporting-r1/README.md) preserves every analysis/audit source and result,invalid-control review,trade counting,private closure proofs,prepared-but-unexecuted four-arm report source,original/derived UI index and publication receipts. Native assets retain every original closed native TAR,CSV,wire/frame/offer,configuration,identity,source and readiness/lifecycle record. Member SHA/size/mode/owner/directory inventories are complete. Candidate-codec checks are not an independent matching oracle or binary cold recovery.

The index retains all55 earlier runs and22 cohorts unchanged,and appends these3 observations in2 original-sampler artifact cohorts:58 runs/24 cohorts. C2 is visibly invalid;no stable marker is inferred. An HTTP data check is not a rendered-browser review. Separate reset lineages cannot be added into continuous1M/10M/100M endurance. No sustained capacity,millisecond SLA,physical-host isolation,production certification,HFT endorsement or funded-trading readiness is established.
'''
target=R/'docs/VERIFIED_ARCHIVE_HANDOFF_INITIAL_RESULTS_V3.md';assert not target.exists();target.write_text(text)
(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
applied=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),indexSha256=sha(R/'evidence/index.json'),reportSha256=sha(target),
    records=58,cohorts=24,all55PriorRunsAnd22CohortsPreserved=True,campaignComplete=False)
(O/'APPLIED.json').write_text(json.dumps(applied,indent=2,sort_keys=True)+'\n')
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10)as response:body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body)
j=json.loads(body);http=dict(passed=status==200 and j==json.loads((R/'evidence/index.json').read_text()),status=status,records=len(j['runs']),cohorts=len(j['capacityCohorts']),
    bodySha256=hashlib.sha256(body).hexdigest(),browserRenderVerified=False)
(O/'HTTP_REVIEW.json').write_text(json.dumps(http,indent=2,sort_keys=True)+'\n');assert http['passed']
print(json.dumps(dict(applied=applied,http=http)))
