from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/incomplete-reporting-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
report=B/'verified-archive-handoff-incomplete-reporting-r1';c=json.loads((report/'COMPARISON.json').read_text());applied=json.loads((report/'APPLIED.json').read_text())
assert c['passed'] and c['campaignComplete']is False and applied['passed'] and applied['indexSha256']==sha(R/'evidence/index.json')
ci=json.loads((B/'process-identity-forced-correctness-r1/RESULT.json').read_text());assert ci['passed'] and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0) and ci['pythonTests']==189
names=['verified-archive-handoff-incomplete-reporting-r1','verified-archive-handoff-incomplete-reporting-preparation-r1',
    'verified-archive-handoff-incomplete-report-generation-fix-r1','verified-archive-handoff-cdcd-reporting-preparation-r1',
    'verified-archive-handoff-workload-audit-preparation-r1','verified-archive-handoff-first-pair-phase-diagnostic-r1',
    'verified-archive-handoff-cdcd-bottleneck-preparation-r1','verified-archive-handoff-cdcd-recovery-preparation-r1',
    'verified-archive-handoff-cdcd-maintenance-phases-preparation-r1','verified-archive-handoff-schema-audit-preparation-r1',
    'verified-archive-handoff-c2-invalid-review-preparation-r1','verified-archive-handoff-c2-invalid-review-r1',
    'verified-archive-handoff-c2-invalid-archive-preparation-r1','verified-archive-handoff-c2-invalid-private-proof-preparation-r1',
    'verified-archive-handoff-c2-invalid-local-retirement-preparation-r1','verified-archive-handoff-cdcd-local-duplicate-retirement-preparation-r1',
    'verified-archive-handoff-local-sparse-cache-preparation-r1','verified-archive-handoff-local-sparse-cache-r1',
    'production-cpu-ci-controller-preparation-r7','production-cpu-ci-environment-r7','production-cpu-ci-registration-r7',
    'production-cpu-ci-dispatch-r7','production-ci-evidence-collection-preparation-r4','production-ci-attempt-7-collection-r1',
    'process-identity-forced-correctness-preparation-r1','process-identity-forced-correctness-r1',
    'process-identity-linux-python38-r1','process-identity-local-review-r1','process-identity-exit-race-reproduction-r1',
    'process-identity-controller-bridge-preparation-r1','process-identity-controller-native-proof-r1','dispatch-capacity-scope-tar-preparation-r1']
for case in ('c1','d1'):
    names.extend(f'verified-archive-handoff-cdcd-{case}-{suffix}-r1'for suffix in ('private-proof','workload-audit','schema-audit','bottleneck','cut-recovery','maintenance-phases','duplicate-retirement'))
names.extend(['verified-archive-handoff-cdcd-c2-invalid-private-proof-r1','verified-archive-handoff-cdcd-c2-workload-audit-r1',
    'verified-archive-handoff-cdcd-c2-schema-audit-r1','verified-archive-handoff-cdcd-c2-invalid-duplicate-retirement-r1'])
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-incomplete-campaign-and-sampler-correctness.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
review=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
published=['README.md','docs/VERIFIED_ARCHIVE_HANDOFF_INITIAL_RESULTS_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md',
           'docs/PRODUCTION_CORRECTNESS_RESULTS.md','docs/PRODUCTION_ACCEPTANCE.md','evidence/index.json']
for n in published:
    p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
shutil.copy2(report/'COMPARISON.json',A/'COMPARISON.json');shutil.copy2(B/'process-identity-forced-correctness-r1/RESULT.json',A/'FORCED_CI7_REVIEW.json')
(A/'README.md').write_text('''# Initial immutable handoff comparison:incomplete and fully retained

C1/D1 are valid finite observations at4000/s for20s,80,000 distinct accepted orders and trade events per arm. Global p99 is229.613096→222.965821ms;after-positive-offer p99 worsens11.069032→17.014943ms. C2 retains nativeControlPassed=false and performanceQualified=false after Incomplete process identity;all its80,000 original orders/trades and0 unknown reconcile,but its240.568357ms quantile is diagnostic only. D2 never executes. No repeated optimization or SLA is established.

The full original native/raw bodies are private-release assets identified by the three sibling manifests;each has already been completely authenticated-downloaded and member-verified. This package preserves every reporting/audit source/result,trade counting,invalid status,closure proof,retirement/restore receipt,previous and derived index and published file. It also preserves complete actual CI7 source/compiler/test/log evidence:394 Java/11 PostgreSQL/189 Python plus failover/web checks,all0 skips. The actual Python3.8 controller runtime passes18/18 identity tests;the exact archived old function reproduces the exit-interleaving defect independently. Historical C2's PID/read phase remains unavailable,so its exact trigger is not claimed.

The new owned wrapper changes only process_identity;the CPU loader changes only its base-source hash. All other lifecycle/signal AST and four attestation/readiness source bodies remain unchanged. A real owned-child probe rejects wrong identity without signaling and passes the original pidfd SIGTERM/strict-exit path. No benchmark uses the new sampler yet. New common-harness comparison requires separate private qualification. All55 earlier runs/22 cohorts are retained;58 runs/24 cohorts now include the invalid C2. HTTP verification is not browser rendering.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),
    archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=review,campaignComplete=False,records=58,cohorts=24,
    validCases=['c1','d1'],invalidCases=['c2'],unexecutedCases=['d2'],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalReportingFiles=review['originalFiles'],payloadFiles=len(inv['files']))))
