from pathlib import Path
import sys,tarfile,io,hashlib,json,socket,subprocess,base64
c=json.loads(base64.b64decode(sys.argv[1]));root=Path(c['root'])
assert socket.gethostname()=='33ace3d92505'and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='8d765c71-dbfa-4354-8db0-6c392e701e6f'
assert root==Path('/opt/vectormatch-cpu/tools/process-identity-proof-r1')and not root.exists()
b=sys.stdin.buffer.read();assert len(b)<1024**2 and hashlib.sha256(b).hexdigest()==c['bundleSha256'];root.mkdir()
with tarfile.open(fileobj=io.BytesIO(b))as t:
 members=t.getmembers();assert len(members)==len(c['rows'])
 for m in members:
  assert m.isfile()and m.name in c['rows'];data=t.extractfile(m).read();pin=c['rows'][m.name]
  assert len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256']
  p=root/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(0o644)
r=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_owned_process_identity.py','-v'],cwd=root,capture_output=True,text=True,timeout=60)
(root/'tests.stdout').write_text(r.stdout);(root/'tests.stderr').write_text(r.stderr)
assert r.returncode==0 and 'Ran 18 tests'in r.stderr and '\nOK\n'in r.stderr and 'skipped'not in r.stderr
assert all((root/n).stat().st_size==v['bytes']and hashlib.sha256((root/n).read_bytes()).hexdigest()==v['sha256']for n,v in c['rows'].items())
result=dict(passed=True,pythonVersion=sys.version,pythonExecutable=sys.executable,tests=18,skipped=0,allSourcesUnchanged=True,rows=c['rows'],stdout=r.stdout,stderr=r.stderr,noJavaSqlOrTradingWorkload=True)
(root/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
