from pathlib import Path
import copy, datetime, hashlib, json

R = Path.cwd()
B = R / 'runtime/cloud/cpu-20261024'
O = B / 'verified-archive-handoff-cdcd-reporting-r1'
assert not O.exists()
pins = {}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    pins[str(p)] = dict(bytes=p.stat().st_size, sha256=sha(p))
    return json.loads(p.read_text())
old = read(R / 'evidence/index.json')
assert len(old['runs']) == 55 and len(old['capacityCohorts']) == 22
observations = []
for case in ('c1', 'd1', 'c2', 'd2'):
    P = B / f'verified-archive-handoff-cdcd-{case}-root-review-r1'
    proof = read(B / f'verified-archive-handoff-cdcd-{case}-private-proof-r1/PRIVATE_PUSH.json')
    root, raw, ready = [read(P / n) for n in ('ROOT_REVIEW.json', 'RAW_AUDIT.json', 'READINESS_REVIEW.json')]
    diag = read(B / f'verified-archive-handoff-cdcd-{case}-bottleneck-r1/DIAGNOSIS.json')
    cut = read(B / f'verified-archive-handoff-cdcd-{case}-cut-recovery-r1/RECOVERY.json')
    phases = read(B / f'verified-archive-handoff-cdcd-{case}-maintenance-phases-r1/PHASES.json')
    schema = read(B / f'verified-archive-handoff-cdcd-{case}-schema-audit-r1/SCHEMA_AUDIT.json')
    load = P / 'materialized/attempt-4000/idle-arm/load'
    cfg, result = read(load / 'configuration.json'), read(load / 'load-result.json')
    assert all(v['passed'] for v in (proof, root, raw, ready, diag, cut, phases, schema))
    assert proof['private'] and proof['allOriginalNativeAndRawEvidencePushed'] and proof['knownOutcomeQualified']
    assert root['nativeControlPassed'] and root['confirmedAcceptedUniqueOrders'] == 80000
    assert root['notSent'] == root['serverRejected'] == root['unknownObserved'] == root['unknownFinal'] == 0
    assert proof['writerPhaseTimingsExpected'] is True and proof['verifiedArchiveHandoffExpected'] == case.startswith('d') and proof['higherLoadPermitted'] is False
    assert schema['writerTimingSchema'] == 1 and schema['verifiedArchiveHandoffExpected'] == case.startswith('d')
    wall = schema['maintenanceWallNs']
    measured = phases['rpcIntervalUnionNs']
    if True:
        measured += schema['coordinatorArchiveVerificationNs']
        measured += sum(t['ElapsedNs'] + t['CopyNs'] + t['QueueWaitNs'] for t in schema['writerTotals'].values())
        assert measured <= wall
    workload = read(B / f'verified-archive-handoff-cdcd-{case}-workload-audit-r1/WORKLOAD.json')
    arm = R / f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/arm-{case}-native-r1'
    scopeInventory = read(arm/'ORIGINAL_SCOPE_INVENTORIES.json')
    wirePin=scopeInventory[f'verified-archive-handoff-cdcd-{case}-root-review-r1']['files']['materialized/attempt-4000/idle-arm/load/physical-replies.bin']
    assert workload['passed'] and workload['uniqueAcceptedOrders']==workload['uniqueTradeEvents']==workload['resultTradeCount']==80000
    assert workload['replySha256']==wirePin['sha256'] and workload['replyBytes']==wirePin['bytes']
    observations.append(dict(workload=workload,caseId=case, codeFingerprint=proof['codeFingerprint'], sourceCommit=proof['sourceCommit'],
        scheduledOriginUTC=cfg['scheduledOriginUTC'], privateCommit=proof['commit'],
        planned=80000, accepted=80000, goodput=root['arrivalWindowGoodputPerSecond'],
        p50Ns=root['allArrivalP50Ns'], p99Ns=root['allArrivalP99Ns'],
        windowConfirmationFraction=root['windowConfirmationFraction'], drainNs=result['lastKnownReplyDrainNs'],
        fullOfferedCutIntervals=cut['fullOfferedEquivalentCutIntervals'], clearingIntervals=cut['intervalsReachingZeroRecordedWaiting'],
        firstWaiting=cut['firstWaiting'], lastWaiting=cut['lastWaiting'], sampledQueueHigh=diag['sampledQueueHighWater'],
        afterOfferP99Ns=diag['afterFirstPositiveOfferReturnP99Ns'], tailPredispatchShare=diag['slowestOnePercentPredispatchShare'],
        maintenanceCycles=root['maintenanceCycles'], maintenanceWallNs=wall,
        rpcIntervalUnionNs=phases['rpcIntervalUnionNs'], rpcIntervalUnionByKindNs=phases['rpcIntervalUnionByKindNs'],
        coordinatorArchiveVerificationNs=schema['coordinatorArchiveVerificationNs'], writerTotals=schema['writerTotals'],
        detailedUninstrumentedResidualNs=wall - measured))
data = copy.deepcopy(old)
for letter, description in (('c', 'timing control'), ('d', 'verified archive handoff')):
    selected = [v for v in observations if v['caseId'].startswith(letter)]
    cohort = dict(id=f'cpu-verified-handoff-{letter}-4000-20s', title=f'CPU verified archive handoff · {description} · 4,000/s',
        updatedAt=selected[-1]['scheduledOriginUTC'], reportPath='docs/VERIFIED_ARCHIVE_HANDOFF_RESULTS_V3.md',
        configurationFingerprint=selected[0]['codeFingerprint'],
        scope='Registered C1/D1/C2/D2;4,000/s for20s,fresh80,000-order lineages. Same CPU host/three JVMs/one physical session,leader0/sync2/read128/page32/batch4/chunk6144/owner1ms/driver100us/W128Q64. Same project-only read-only cache preconditioning before each arm. All earlier curves remain separate. A candidate optimization comparison;two observations per artifact are not statistical significance,sustained capacity,an SLA or100M.', points=[])
    for v in selected:
        case = v['caseId']; identity = f'cpu-verified-handoff-{case}'
        data['runs'].append(dict(id=identity, label=f'Verified archive handoff · {case.upper()} · {description}',
            scope='80,000 planned and accepted · finite20s diagnostic',
            model='One CPU host · three JVMs · loopback UDP · one physical session', commands=80000,
            throughput=v['goodput'], p50Millis=v['p50Ns']/1e6, p99Millis=v['p99Ns']/1e6,
            unknown=0, correctnessPassed=True, timestamp=v['scheduledOriginUTC'],
            durability='sync2;canonical validation and payload/receipt force plus full readback before both ACKs',
            artifactPath=f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/arm-{case}-native-r1/README.md',
            limitations=[f"Artifact{v['codeFingerprint']};all80,000 accepted;notSent/rejected/observed UNKNOWN/final UNKNOWN=0/0/0/0.",
                f"Recorded waiting clears in{v['clearingIntervals']}/{v['fullOfferedCutIntervals']} comparable offered-cut intervals. Full original native/raw evidence privately verified at{v['privateCommit']}.",
                'Same registered cache preconditioning and two original-PID2s readiness gates around5s warm-up.128 logical workers are one physical session;three JVMs share one host.',
                'Finite candidate comparison. No statistical significance,sustained capacity,millisecond SLA,independent-host isolation or100M claim. Candidate-codec checks are not an independent matching oracle.']))
        cohort['points'].append(dict(id=identity, rate=4000, workers=128, goodput=v['goodput'], p99Millis=v['p99Ns']/1e6,
            clientNotSent=0, rejected=0, serverErrors=0, unknown=0, unresolved=0,
            allOfferedAcceptedP99Millis=v['p99Ns']/1e6, drainSeconds=v['drainNs']/1e9,
            classification='FINITE_20S_HANDOFF_COMPARISON', peakBacklog=v['sampledQueueHigh'], valid=True, stable=None, windowSeconds=20))
    data['capacityCohorts'].append(cohort)
assert data['runs'][:55] == old['runs'] and data['capacityCohorts'][:22] == old['capacityCohorts']
assert data['capacity'] == old['capacity'] and len(data['runs']) == 59 and len(data['capacityCohorts']) == 24
# Retain chronological arm order in the run cards as well as the comparison table.
data['runs'][55:] = sorted(data['runs'][55:], key=lambda v: ('c1','d1','c2','d2').index(v['id'].removeprefix('cpu-verified-handoff-')))
pairs = [dict(control=a['caseId'], timing=b['caseId'], p99DeltaNs=b['p99Ns']-a['p99Ns'],
              maintenanceWallDeltaNs=b['maintenanceWallNs']-a['maintenanceWallNs'])
         for a,b in ((observations[0], observations[1]), (observations[2], observations[3]))]
assert all(Path(n).stat().st_size == p['bytes'] and sha(Path(n)) == p['sha256'] for n,p in pins.items())
O.mkdir()
(O/'index-before.json').write_bytes((R/'evidence/index.json').read_bytes())
(O/'index-derived.json').write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')
result = dict(passed=True, atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), observations=observations,
              pairedDeltas=pairs, inputs=pins, allInputBodiesUnchanged=True, all55PriorRunsAnd22CohortsPreserved=True,
              records=59, cohorts=24, sourceSha256=sha(Path(__file__)), noSignificanceOrSustainedCapacityClaim=True,
              repeatedFiniteP99AndMaintenanceReduction=all(p["p99DeltaNs"] < 0 and p["maintenanceWallDeltaNs"] < 0 for p in pairs))
(O/'COMPARISON.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps(dict(passed=True, records=59, cohorts=24, observations=observations, pairedDeltas=pairs)))
