from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-archive-handoff-local-sparse-cache-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,sha
def git(*a):return subprocess.check_output(['git',*a])
proof=json.loads((B/'writer-timing-abab-reporting-private-proof-r1/PRIVATE_PUSH.json').read_text())
assert proof['passed']and proof['private']and proof['actualRestorationDirectlyFromCommittedGitBlobsVerified']
remote=git('ls-remote','origin','refs/heads/main').decode().split()[0]
subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],remote],check=True)
assert not git('status','--porcelain')
patterns=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());old=patterns.read_bytes();rows=[];exclusions=[]
for case in ('a1','b1','a2','b2'):
 A=R/f'evidence/2026-10-25/runpod-cpu/writer-phase-timing-v3/arm-{case}-native-r1'
 inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
 assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')
 assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']
 assert all(actual['files'][n]==v for n,v in inv['files'].items())
 prefix=A.relative_to(R).as_posix();exclusions.append('!/'+prefix+'/.large-file-parts/')
 for name,pin in inv['files'].items():
  if not name.startswith('.large-file-parts/'):continue
  p=A/name;n=p.relative_to(R).as_posix();obj=git('rev-parse',proof['commit']+':'+n).decode().strip()
  process=subprocess.Popen(['git','cat-file','blob',obj],stdout=subprocess.PIPE);h=hashlib.sha256();size=0
  for block in iter(lambda:process.stdout.read(1024**2),b''):h.update(block);size+=len(block)
  process.stdout.close();assert process.wait()==0 and size==pin['bytes']and h.hexdigest()==pin['sha256']and sha(p)==pin['sha256']
  rows.append(dict(path=n,bytes=size,sha256=h.hexdigest(),gitBlob=obj,privateCommit=proof['commit']))
assert len(rows)==28 and all(e.encode()not in old for e in exclusions)
O.mkdir();(O/'sparse-checkout.before').write_bytes(old)
registration=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),passedBeforeMutation=True,priorDirectWholeArchiveRestorationCommit=proof['commit'],
 allSelectedOriginalPartBytesReverifiedFromActualCommittedGitBlobs=True,files=rows,exclusions=exclusions,freeBytesBefore=shutil.disk_usage(R).free,
 scope='Only verified tracked working-tree copies of the four old timing raw part directories become sparse. No Git object/history,remote archive,application state or other workspace file is removed.',
 restoreRecipe='Append a positive /<case>/.large-file-parts/ sparse pattern and run git sparse-checkout reapply after reserving space;or read each recorded gitBlob with git cat-file blob into a fresh output and verify length/SHA-256.')
(O/'VERIFIED_BEFORE.json').write_text(json.dumps(registration,indent=2,sort_keys=True)+'\n')
new=old.rstrip()+b'\n'+('\n'.join(exclusions)+'\n').encode();patterns.write_bytes(new)
r=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','reapply'],capture_output=True,text=True)
(O/'reapply.stdout').write_text(r.stdout);(O/'reapply.stderr').write_text(r.stderr);assert r.returncode==0
assert all(not(R/v['path']).exists()for v in rows)and not git('status','--porcelain')
(O/'sparse-checkout.after').write_bytes(patterns.read_bytes())
result=dict(registration,passed=True,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),workingTreeFilesNowSparse=len(rows),
 logicalBytesNoLongerDuplicatedInWorkingTree=sum(v['bytes']for v in rows),freeBytesAfter=shutil.disk_usage(R).free,
 noRemoteOrGitHistoryMutation=True,sourceSha256=sha(Path(__file__)))
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='files'}))
