from pathlib import Path
import datetime,json,shutil,sys,tarfile

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/qualification-r1'
assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
ci=json.loads((B/'verified-archive-handoff-forced-correctness-r1/RESULT.json').read_text())
artifact=B/'verified-archive-handoff-artifact-preparation-r1';metadata=B/'verified-archive-handoff-linux-metadata-execution-r1'
jar=json.loads((artifact/'JAR_INPUTS.json').read_text());actual=json.loads((metadata/'actual-linux-observation.json').read_text())
assert ci['passed'] and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0) and ci['allTestTasksExecutedWithoutResultCache']
assert jar['passed'] and jar['allCoreAndClusterJarClassesEqualActualCiCompiledClasses'] and ci['sourceCommit']==jar['sourceCommit']==actual['sourceCommit']
assert actual['actualCodeFingerprint']=='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'
assert all(json.loads(p.read_text())['passed']for p in (artifact/'JDK_IMAGE_EQUIVALENCE.json',artifact/'TICKET_CODE_EQUIVALENCE.json',metadata/'ROOT_REVIEW.json'))
timing=json.loads((B/'writer-timing-abab-reporting-private-proof-r1/PRIVATE_PUSH.json').read_text())
storage=json.loads((B/'private-release-storage-proof-r1/RESULT.json').read_text())
assert timing['passed'] and timing['private'] and timing['actualRestorationDirectlyFromCommittedGitBlobsVerified']
assert storage['passed'] and storage['private'] and storage['draft'] and storage['completeAuthenticatedDownloadVerified']
legacy=json.loads((B/'dispatch-capacity-controller-4000-preparation-r1/release.json').read_text())
assert actual['dispatchCapacityConfigs']['4000']['rotating']['plan']==legacy['derivedPlan'] and actual['readinessContract']==legacy['readinessContract']
names=['verified-archive-handoff-qualification-archive-preparation-r1','verified-archive-handoff-qualification-private-proof-preparation-r1',
    'verified-archive-handoff-local-validation-r1','verified-archive-handoff-artifact-preparation-r1',
    'verified-archive-handoff-linux-metadata-preparation-r1','verified-archive-handoff-linux-metadata-execution-r1',
    'verified-archive-handoff-forced-correctness-preparation-r1','verified-archive-handoff-forced-correctness-r1',
    'production-cpu-ci-controller-preparation-r6','production-cpu-ci-environment-r6','production-cpu-ci-registration-r6',
    'production-cpu-ci-dispatch-r6','production-cpu-ci-diagnostic-r6','production-ci-evidence-collection-preparation-r3',
    'production-ci-attempt-6-collection-r1','private-release-storage-preparation-r1','private-release-storage-proof-r1',
    'writer-timing-abab-reporting-private-proof-r1','dispatch-capacity-scope-tar-preparation-r1']
before={n:tree(B/n)for n in names};O.mkdir(parents=True);archive=O/'complete-ci-artifact-linux-and-storage-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(O/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for src,name in [(artifact/'JAR_INPUTS.json','JAR_INPUTS.json'),(metadata/'ROOT_REVIEW.json','LINUX_METADATA_REVIEW.json'),
                 (B/'verified-archive-handoff-forced-correctness-r1/RESULT.json','FORCED_CI_REVIEW.json'),
                 (B/'private-release-storage-proof-r1/RESULT.json','PRIVATE_ASSET_STORAGE_REVIEW.json')]:shutil.copy2(src,O/name)
for n in ('docs/VERIFIED_ARCHIVE_HANDOFF_V3.md','docs/PRODUCTION_CORRECTNESS_RESULTS.md'):
    p=O/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(O/'README.md').write_text('''# Immutable verified handoff: complete qualification

Source23f9c070/code79e5a932 comes from actual forced Linux CI6:394 Java tests including11 real PostgreSQL tests,171 Python tests,failover/snapshot/restart and web gates pass with0 skips. All five test modules execute with a new Gradle home and no test-result reuse. All227 core/cluster classes equal CI compiled bodies. The41 core classes are byte-identical to timing controlf3a5745c;only the two main sources,five existing classes and new VerifiedArchive class differ. Ticket instructions/signatures are identical. Full454-file CI6/benchmark JDK images match. Local and actual Linux metadata,all nine loaded origins,all existing plans and readiness contracts agree.

The complete scope TAR retains every CI6 tracked source,compiled/test/log body,all setup and qualification sources/results,all29 targeted local test records,and full artifact/metadata bytes. Tokens,SSH/API keys,Git authentication state and runner worker diagnostic logs are excluded by the closed CI collector. The four prior timing native archives have been restored directly from committed Git blobs and every original scope member verified. The private draft-release backend is separately qualified by uploading the already-authorized CI5 collection and downloading all2,841,657 bytes with matching SHA-256 and server digest;this is storage qualification,not application durability.

Register C1/D1/C2/D2 at4000/s for20s each. C uses timing artifactf3a5745c;D uses79e5a932. Keep exact configuration,JDK,readiness,cache preconditioning and durable ACK fences fixed. Full private native/raw closure precedes every next arm. No new performance workload is executed by this qualification,and no gain,significance,sustained capacity,millisecond SLA or100M claim is established.
''')
inv=tree(O);(O/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(O/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    inventorySha256=sha(O/'INVENTORY.json'),archiveSha256=sha(archive),archiveBytes=archive.stat().st_size,scopeReview=members,
    sourceCommit=actual['sourceCommit'],codeFingerprint=actual['actualCodeFingerprint'],noNativePerformanceClaim=True),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'],payloadFiles=len(inv['files']))))
