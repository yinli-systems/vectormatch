from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, tarfile

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'private-release-storage-proof-r1'
assert not O.exists()
repo='yinli-systems/vectormatch';tag='evidence-private-20261025'
source='23f9c070e2cb394a13d1bc80d60a3b532e032204'
def api(*args,body=None):
    r=subprocess.run(['gh','api',*args],input=None if body is None else json.dumps(body),text=True,capture_output=True)
    assert r.returncode==0,r.stderr
    return json.loads(r.stdout)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
repository=api('repos/'+repo);assert repository['private'] and repository['full_name']==repo
existing=api('repos/'+repo+'/releases?per_page=100')
assert not any(r['tag_name']==tag for r in existing),'Existing release requires read-only recovery,not another creation'
original=B/'production-ci-attempt-5-collection-r1/complete-code-compiled-tests-and-public-logs.tar.gz'
verified=json.loads((original.parent/'VERIFIED.json').read_text())
assert verified['passed'] and original.stat().st_size==verified['archiveBytes'] and sha(original)==verified['archiveSha256']
with tarfile.open(original)as t:
    members=t.getmembers()
    assert len(members)==verified['allOriginalCollectedFilesVerified']
    assert all(m.isfile() and m.name.startswith('original/') for m in members)
    assert all(not any(p in ('.git','.ssh','.credentials','_diag') for p in Path(m.name).parts) for m in members)
O.mkdir();upload=O/'ci5-qualified-code-tests-public-logs.tar.gz';shutil.copy2(original,upload)
assert sha(upload)==verified['archiveSha256'] and upload.stat().st_size<2*1024**3
registration=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,private=True,
    releaseTag=tag,targetCommit=source,assetName=upload.name,bytes=upload.stat().st_size,sha256=sha(upload),
    originalCollection=str(original),originalCollectionVerified=True,oneCreateOneUploadOnly=True,draft=True)
(O/'REGISTRATION.json').write_text(json.dumps(registration,indent=2,sort_keys=True)+'\n')
release=api('--method','POST','repos/'+repo+'/releases','--input','-',body=dict(tag_name=tag,target_commitish=source,
    name='Private synthetic benchmark evidence · 2026-10-25',draft=True,prerelease=True,
    body='Private raw evidence storage qualification. The first asset is the already-qualified CI5 synthetic code/test/public-log collection;no new workload or performance claim. Future assets require explicit size/SHA-256 manifests and complete authenticated download verification. Code and small evidence manifests remain in Git.'))
assert release['draft'] and release['tag_name']==tag
(O/'CREATED_RELEASE.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\n')
r=subprocess.run(['gh','release','upload',tag,str(upload),'--repo',repo],capture_output=True,text=True)
(O/'upload.stdout').write_text(r.stdout);(O/'upload.stderr').write_text(r.stderr)
(O/'UPLOAD_EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n')
assert r.returncode==0,'Preserve failed upload and query existing asset;do not overwrite or blindly resubmit'
after=api('repos/'+repo+'/releases/'+str(release['id']))
matches=[a for a in after['assets']if a['name']==upload.name];assert len(matches)==1
asset=matches[0];assert asset['state']=='uploaded' and asset['size']==upload.stat().st_size
assert not asset.get('digest') or asset['digest']=='sha256:'+sha(upload)
(O/'UPLOADED_RELEASE.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
download=O/'authenticated-download.tar.gz'
with download.open('xb')as out,(O/'download.stderr').open('xb')as err:
    r=subprocess.run(['gh','api','repos/'+repo+'/releases/assets/'+str(asset['id']),'-H','Accept: application/octet-stream'],stdout=out,stderr=err,timeout=120)
assert r.returncode==0 and download.stat().st_size==upload.stat().st_size and sha(download)==sha(original)==sha(upload)
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,private=True,draft=True,
    releaseId=release['id'],releaseTag=tag,targetCommit=source,assetId=asset['id'],assetName=asset['name'],assetApiUrl=asset['url'],
    bytes=asset['size'],sha256=sha(download),serverDigest=asset.get('digest'),
    completeAuthenticatedDownloadVerified=True,originalLocalFileUnchanged=sha(original)==registration['sha256'],
    noNewWorkload=True,noNewPaidResource=True,sourceSha256=sha(Path(__file__)),
    scope='Existing authorized private-repository synthetic CI5 collection only. Complete uploaded and authenticated-downloaded bytes agree. This storage proof is not application durability or performance evidence.')
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result))
