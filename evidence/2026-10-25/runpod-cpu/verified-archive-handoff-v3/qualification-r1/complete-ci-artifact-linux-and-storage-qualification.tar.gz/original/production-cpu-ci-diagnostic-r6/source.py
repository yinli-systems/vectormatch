from pathlib import Path
import json
r=Path('/opt/vectormatch-cpu/ci/production-correctness-r6/runner/_work/vectormatch/vectormatch/runtime/ci')
result=[]
if r.is_dir():
 for p in sorted(r.glob('*.log')):
  if p.name not in ('java-check.log','failover.log','python-tests.log','web.log','postgres.log'):continue
  b=p.read_bytes();result.append(dict(name=p.name,bytes=len(b),last2048=b[-2048:].decode(errors='replace')))
print(json.dumps(result))
