from pathlib import Path
import hashlib,json,subprocess
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-handoff-client-jfr-7500-recording-summary-parity-r2';assert not O.exists();O.mkdir()
p=B/'verified-handoff-client-jfr-7500-d1-root-review-r1/materialized/attempt-7500/client.jfr';analysis=B/'verified-handoff-client-jfr-7500-recording-analysis-r1/JFR.json';j=json.loads(analysis.read_text());args=[str(R/'.tools/jdk/bin/jfr'),'summary',str(p)];r=subprocess.run(args,capture_output=True,text=True,timeout=30);(O/'stdout').write_text(r.stdout);(O/'stderr').write_text(r.stderr);assert r.returncode==0
counts={}
for line in r.stdout.splitlines():
 fields=line.split()
 if len(fields)==3 and fields[0].startswith('jdk.')and fields[1].isdigit():counts[fields[0]]=int(fields[1])
assert all(counts[k]==v['count']for k,v in j['allRecordingTypes'].items())
extra={k:v for k,v in counts.items()if v and k not in j['allRecordingTypes']};assert set(extra)=={'jdk.Checkpoint','jdk.Metadata'}and extra['jdk.Metadata']==1
assert sum(v for k,v in counts.items()if k not in extra)==j['events']
result=dict(passed=True,arguments=args,exitCode=r.returncode,everyExposedEventTypeCountMatches=True,exposedRecordedEvents=j['events'],internalFormatEntriesSeparate=extra,recordingBytes=p.stat().st_size,recordingSha256=hashlib.sha256(p.read_bytes()).hexdigest(),analysisSha256=hashlib.sha256(analysis.read_bytes()).hexdigest(),sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),spanCoversArrivalWindow=j['observedSpanCoversArrivalWindow'],dataLossEventPresent='jdk.DataLoss'in j['allRecordingTypes'],jfrChunkSummary=[line.strip()for line in r.stdout.splitlines()if any(k in line for k in('Version:','Chunks:','Start:','Duration:'))],noNewWorkload=True)
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
