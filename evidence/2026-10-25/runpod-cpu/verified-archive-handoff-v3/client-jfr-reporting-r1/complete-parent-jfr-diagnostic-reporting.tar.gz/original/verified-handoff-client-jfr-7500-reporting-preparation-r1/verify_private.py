from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/client-jfr-reporting-r1';O=B/'verified-handoff-client-jfr-7500-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
def package(p):
 inv=json.loads((p/'INVENTORY.json').read_text());closed=json.loads((p/'CLOSED.json').read_text());actual=tree(p);assert closed['passed']and closed['inventorySha256']==sha(p/'INVENTORY.json');assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
 prefix=p.relative_to(R).as_posix();blobs={}
 for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
  if row:
   meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
 paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
 return closed,len(paths)
closed,count=package(A)
for n in('README.md','docs/CLIENT_JFR_DIAGNOSTIC_RESULTS_V3.md','docs/CLIENT_JFR_DIAGNOSTIC_V3.md','evidence/index.json'):assert git('show',head+':'+n)==(R/n).read_bytes()==(A/'published'/n).read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+A.relative_to(R).as_posix()+'/complete-parent-jfr-diagnostic-reporting.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
p=B/'verified-handoff-client-jfr-7500-d1-private-proof-r1/PRIVATE_PUSH.json';native=json.loads(p.read_text());assert native['passed']and native['completeAuthenticatedAssetDownloadVerified']and native['diagnosticOnly']and not native['finiteProgressionPermitted']and native['nextRegisteredRate']is None
point=A.parent/'client-jfr-7500-arm-d1-native-r1';pc,pn=package(point);manifest=json.loads(git('show',head+':'+point.relative_to(R).as_posix()+'/ASSET_MANIFEST.json'));assert manifest==json.loads((point/'ASSET_MANIFEST.json').read_text())
assert manifest['assetId']==native['assetId']and manifest['sha256']==native['assetSha256']and manifest['bytes']==native['assetBytes']and native['allOriginalCompressedScopeMembersVerified']==pc['originalScopeReview']
subprocess.run(['git','merge-base','--is-ancestor',native['commit'],head],check=True)
index=json.loads((R/'evidence/index.json').read_text());before=json.loads((B/'verified-handoff-client-jfr-7500-reporting-r1/index-before.json').read_text());assert len(index['runs'])==68 and len(index['capacityCohorts'])==30 and index['runs'][:67]==before['runs']and index['capacityCohorts'][:29]==before['capacityCohorts']and index['capacity']==before['capacity'];assert index['runs'][-1]['p99Millis']is None
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='yinli-systems/vectormatch',private=True,commit=head,bothRemoteBranchesVerified=True,allReportingGitBlobsVerified=count,wholeActualReportingGitTarRestored=True,everyOriginalReportingMemberVerified=members,committedNativeMetadataBlobsVerified=pn,previousFullAuthenticatedNativeAssetProofCommit=native['commit'],nativeAssetId=native['assetId'],nativeAssetSha256=native['assetSha256'],nativePrivateProofSha256=sha(p),all67PriorRunsAnd29CohortsPreserved=True,records=68,cohorts=30,diagnosticOnly=True,globalAcceptedArrivalP99Ns=None,higherLoadPermitted=False,browserRenderVerified=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
