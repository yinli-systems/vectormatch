from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/client-jfr-reporting-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=B/'verified-handoff-client-jfr-7500-reporting-r1';applied=json.loads((O/'APPLIED.json').read_text());assert applied['passed']and applied['indexSha256']==sha(R/'evidence/index.json')
names=[P.name,O.name,'verified-handoff-client-jfr-7500-recording-summary-parity-failed-r1','verified-handoff-client-jfr-7500-recording-summary-parity-preparation-r1','verified-handoff-client-jfr-7500-recording-summary-parity-r2','verified-handoff-client-jfr-7500-recorded-errors-review-r1','verified-handoff-client-jfr-7500-linux-smoke-original-recovery-r1','verified-handoff-client-jfr-7500-registration-private-proof-r1','dispatch-capacity-scope-tar-preparation-r1']
for suffix in('private-proof','workload-audit','schema-audit','bottleneck','cut-recovery','maintenance-phases','duplicate-retirement'):names.append('verified-handoff-client-jfr-7500-d1-'+suffix+'-r1')
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-parent-jfr-diagnostic-reporting.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(O/'DIAGNOSTIC.json',A/'DIAGNOSTIC.json')
for n in('README.md','docs/CLIENT_JFR_DIAGNOSTIC_RESULTS_V3.md','docs/CLIENT_JFR_DIAGNOSTIC_V3.md','evidence/index.json'):
 p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(A/'README.md').write_text('''# Completed parent/client JFR diagnostic reporting

One separate instrumented7500/s20s lineage.142,548 accepted unique synthetic trades and7,452 definite NOT_SENT/QUEUE_FULL;global accepted-arrival p99 undefined,conditional accepted-only p991418.100777ms. All outcomes reconcile;rejection/observed UNKNOWN/final UNKNOWN0.0/41 comparable intervals clear waiting. No optimization gain,capacity progression or millisecond SLA.

All original native/raw/JFR/GC bodies remain in the sibling committed private asset,fully authenticated-downloaded and member-verified. This package preserves that proof,the full reporting sources/results,phase/recovery/trade audits,independent JDK JFR event-count parity and its original failed total-count check,all six original Linux configuration-smoke bodies,recorded VM errors/compiler event review and complete UI before/after/HTTP receipts. The native asset itself retains the streaming JFR analyzer source/classes/results. No original failed capacity point is replaced. All67 prior runs/29 cohorts remain;one separate diagnostic makes68/30. Parent-only recording does not establish node GC,pure network or a unique service bottleneck. Sampling and thresholded event durations are not exact disjoint wall-time costs. HTTP checks are not browser rendering.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,records=68,cohorts=30,diagnosticOnly=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
