from pathlib import Path
import datetime,hashlib,json,math
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';I=B/'verified-handoff-capacity-telemetry-input-r1';O=B/'verified-handoff-capacity-telemetry-diagnosis-r1';assert not O.exists()
result=[]
for rate in(6000,7000,7500):
 p=I/f'{rate}.jsonl';pin=json.loads((I/f'{rate}.pin.json').read_text());assert pin['passed']and hashlib.sha256(p.read_bytes()).hexdigest()==pin['expected']['sha256']
 rows=[json.loads(line)for line in p.read_text().splitlines()];L=B/f'verified-handoff-capacity-{rate}-d1-root-review-r1/materialized/attempt-{rate}/idle-arm/load';cfg=json.loads((L/'configuration.json').read_text());start=datetime.datetime.fromisoformat(cfg['scheduledOriginUTC'].replace('Z','+00:00')).timestamp()
 selected=[r for r in rows if start<=datetime.datetime.fromisoformat(r['atUtc']).timestamp()<=start+20]
 assert len(selected)>=10
 result.append(dict(rate=rate,samplesInWindow=len(selected),clockSelection='UTC selects arrival window;raw monotonic deltas and kernel counters remain original. No one-way latency inference.',first=selected[0],last=selected[-1]))
O.mkdir();(O/'WINDOWS.json').write_text(json.dumps(dict(passed=True,observations=result,sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2,sort_keys=True)+'\n')
for r in result:print(json.dumps(dict(rate=r['rate'],first=r['first'],last=r['last'])))
