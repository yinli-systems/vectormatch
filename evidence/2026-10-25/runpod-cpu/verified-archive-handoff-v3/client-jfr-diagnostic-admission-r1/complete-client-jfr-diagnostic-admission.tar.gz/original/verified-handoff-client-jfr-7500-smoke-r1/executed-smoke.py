
from pathlib import Path
import hashlib,json,os,socket,subprocess
assert socket.gethostname()=='33ace3d92505'and os.geteuid()==0
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='8d765c71-dbfa-4354-8db0-6c392e701e6f'
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:cmd=(p/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(cmd[0])).name
 except(FileNotFoundError,ProcessLookupError):continue
 assert name not in('java','javaw','postgres','postmaster')
O=Path('/opt/vectormatch-cpu/experiments/verified-handoff-client-jfr-7500-smoke-r1');assert not O.exists();O.mkdir(mode=0o700)
java=Path('/opt/vectormatch-cpu/tools/jdk-21.0.13+9/bin/java');assert hashlib.sha256(java.read_bytes()).hexdigest()=='9cad3f2620d3ef2ed10b26f922af7e773d54fdaa05f615d6d6df014f3fec4155'
flags=['-Xmx256m','-XX:FlightRecorderOptions=repository='+str(O/'repository'),'-XX:StartFlightRecording=name=VectorMatchClientDiagnostic,settings=profile,filename='+str(O/'client.jfr')+',dumponexit=true,disk=true,maxsize=32m,maxage=120s,jdk.FileWrite#threshold=1ms,jdk.FileRead#threshold=1ms,jdk.FileForce#enabled=true,jdk.FileForce#threshold=1ms,jdk.ThreadPark#threshold=1ms,jdk.JavaMonitorEnter#threshold=1ms','-Xlog:gc*,safepoint:file='+str(O/'client-gc.log')+':utctime,uptimenanos,level,tags:filecount=1,filesize=4m']
args=[str(java)]+flags+['-version'];env={k:v for k,v in os.environ.items()if k not in('JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS')}
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env)
pid=p.pid;exitcode=p.wait(timeout=30);assert exitcode==0 and not Path('/proc/'+str(pid)).exists()
summary=subprocess.run([str(java.parent/'jfr'),'summary',str(O/'client.jfr')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);assert summary.returncode==0
(O/'jfr-summary.txt').write_bytes(summary.stdout);(O/'summary.stderr').write_bytes(summary.stderr)
rows={str(p.relative_to(O)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in O.rglob('*')if p.is_file()}
result=dict(passed=True,javaPid=pid,exitCode=exitcode,strictOwnedPidAbsent=True,arguments=args,files=rows,noOrdersOrApplicationClasses=True,scope='Actual pinned Linux JDK accepts diagnostic settings and produces readable JFR plus GC log. Not application/native/performance qualification.')
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
