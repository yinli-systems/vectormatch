from pathlib import Path
import hashlib,importlib.util,json,shlex,subprocess
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-handoff-capacity-telemetry-input-r1';assert not O.exists();O.mkdir()
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');remote=importlib.util.module_from_spec(s);s.loader.exec_module(remote)
for rate in(6000,7000,7500):
 package=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-{rate}-arm-d1-native-r1';inv=json.loads((package/'ORIGINAL_SCOPE_INVENTORIES.json').read_text());scope=f'verified-handoff-capacity-{rate}-d1-collection-r1';manifest=inv[scope]['files']['remote-manifest.json'];local=B/scope/'remote-manifest.json';assert hashlib.sha256(local.read_bytes()).hexdigest()==manifest['sha256']
 inventory=json.loads(local.read_text())['fullOriginalInventory'];member=f'attempt-{rate}/owned-cpu-rss-io-1hz.jsonl';pin=inventory['files'][member];path=f'/opt/vectormatch-cpu/experiments/verified-handoff-capacity-{rate}-d1-r1/'+member
 p=O/f'{rate}.jsonl'
 with p.open('xb')as out,(O/f'{rate}.stderr').open('xb')as err:r=subprocess.run(remote.sshargs()+['test "$(hostname)" = 33ace3d92505 && cat -- '+shlex.quote(path)],stdout=out,stderr=err,timeout=60)
 assert r.returncode==0 and p.stat().st_size==pin['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
 (O/f'{rate}.pin.json').write_text(json.dumps(dict(passed=True,readOnlyOriginalPath=path,expected=pin,originalClosedInventorySha256=hashlib.sha256(local.read_bytes()).hexdigest()),indent=2)+'\n')
 rows=[json.loads(line)for line in p.read_text().splitlines()];active=next(row for row in rows if len(row['owned'])==4 and all(o['available']for o in row['owned']))
 print(json.dumps(dict(rate=rate,samples=len(rows),sample=active)))
