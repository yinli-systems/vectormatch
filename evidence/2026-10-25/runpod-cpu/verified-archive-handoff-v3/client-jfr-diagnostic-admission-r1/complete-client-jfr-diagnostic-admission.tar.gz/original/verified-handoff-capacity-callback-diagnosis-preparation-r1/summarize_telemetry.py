from pathlib import Path
import datetime,hashlib,json,math
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';I=B/'verified-handoff-capacity-telemetry-input-r1';O=B/'verified-handoff-capacity-telemetry-diagnosis-r2';assert not O.exists()
def utc(value):
 base=datetime.datetime.strptime(value[:19],'%Y-%m-%dT%H:%M:%S').replace(tzinfo=datetime.timezone.utc).timestamp()
 fraction=value[19:].removesuffix('Z') if value.endswith('Z') else value[19:].split('+')[0]
 return base+(float('0'+fraction)if fraction else 0)
result=[]
for rate in(6000,7000,7500):
 p=I/f'{rate}.jsonl';pin=json.loads((I/f'{rate}.pin.json').read_text());assert pin['passed']and hashlib.sha256(p.read_bytes()).hexdigest()==pin['expected']['sha256']
 rows=[json.loads(line)for line in p.read_text().splitlines()];L=B/f'verified-handoff-capacity-{rate}-d1-root-review-r1/materialized/attempt-{rate}/idle-arm/load';cfg=json.loads((L/'configuration.json').read_text());start=utc(cfg['scheduledOriginUTC'])
 selected=[r for r in rows if start<=utc(r['atUtc'])<=start+20]
 assert len(selected)>=10
 result.append(dict(rate=rate,samplesInWindow=len(selected),clockSelection='UTC selects arrival window;raw monotonic deltas and kernel counters remain original. No one-way latency inference.',first=selected[0],last=selected[-1]))
O.mkdir();(O/'WINDOWS.json').write_text(json.dumps(dict(passed=True,observations=result,sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2,sort_keys=True)+'\n')
for r in result:
 elapsed=(r['last']['monotonicNs']-r['first']['monotonicNs'])/1e9;observations=[]
 for a,z in zip(r['first']['owned'],r['last']['owned']):
  assert a['available']and z['available']and all(a[k]==z[k]for k in('pid','startTicks','commandSha256','role'))
  observations.append(dict(role=a['role'],cpuCores=(z['userTicks']+z['systemTicks']-a['userTicks']-a['systemTicks'])/r['first']['clockTicksPerSecond']/elapsed,readBytes=z['io']['read_bytes']-a['io']['read_bytes'],writeBytes=z['io']['write_bytes']-a['io']['write_bytes']))
 print(json.dumps(dict(rate=r['rate'],elapsedSeconds=elapsed,owned=observations)))
