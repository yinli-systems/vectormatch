from pathlib import Path
import datetime,hashlib,importlib.util,json,shlex,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';rate=int(sys.argv[1]);assert rate in(6000,7000,7500)
O=B/f'verified-handoff-capacity-{rate}-callback-input-r1';assert not O.exists()
helper=B/'current-read-window32-collection-preparation-r2/remote_current.py';assert hashlib.sha256(helper.read_bytes()).hexdigest()=='b130d64cd6497c54df3dc1865e85520606880ecf9e117f8ab490c98960b405be'
s=importlib.util.spec_from_file_location('remote',helper);remote=importlib.util.module_from_spec(s);s.loader.exec_module(remote)
package=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/capacity-{rate}-arm-d1-native-r1'
inv=json.loads((package/'ORIGINAL_SCOPE_INVENTORIES.json').read_text());scope=f'verified-handoff-capacity-{rate}-d1-root-review-r1';member=f'materialized/attempt-{rate}/idle-arm/load/physical-replies.bin';pin=inv[scope]['files'][member]
proof=json.loads((B/f'verified-handoff-capacity-{rate}-d1-private-proof-r1/PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['completeAuthenticatedAssetDownloadVerified']
path=f'/opt/vectormatch-cpu/experiments/verified-handoff-capacity-{rate}-d1-r1/attempt-{rate}/idle-arm/load/physical-replies.bin'
O.mkdir();args=remote.sshargs()+['test "$(hostname)" = 33ace3d92505 && cat -- '+shlex.quote(path)]
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),rate=rate,readOnlyOriginalPath=path,expected=pin,assetId=proof['assetId'],assetSha256=proof['assetSha256'],originalArchiveMember='original/'+scope+'/'+member,helperSha256=hashlib.sha256(helper.read_bytes()).hexdigest()),indent=2)+'\n')
with(O/'physical-replies.bin').open('xb')as out,(O/'stderr').open('xb')as err:r=subprocess.run(args,stdout=out,stderr=err,timeout=600)
p=O/'physical-replies.bin';assert r.returncode==0 and p.stat().st_size==pin['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
(O/'COLLECTED.json').write_text(json.dumps(dict(passed=True,readOnly=True,allBytesMatchPrivatelyArchivedOriginal=True,bytes=p.stat().st_size,sha256=pin['sha256']),indent=2)+'\n');print(json.dumps(dict(passed=True,rate=rate,bytes=p.stat().st_size)))
