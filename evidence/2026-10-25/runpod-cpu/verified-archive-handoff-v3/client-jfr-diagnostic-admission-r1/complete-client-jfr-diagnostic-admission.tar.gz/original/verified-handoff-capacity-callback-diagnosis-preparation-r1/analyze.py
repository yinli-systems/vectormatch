from pathlib import Path
import csv,hashlib,json,math,struct,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';rate=int(sys.argv[1]);assert rate in(6000,7000,7500)
I=B/f'verified-handoff-capacity-{rate}-callback-input-r1';O=B/f'verified-handoff-capacity-{rate}-callback-diagnosis-r1';assert not O.exists()
col=json.loads((I/'COLLECTED.json').read_text());reg=json.loads((I/'REGISTRATION.json').read_text());assert col['passed']and col['allBytesMatchPrivatelyArchivedOriginal']
p=I/'physical-replies.bin';pin=reg['expected'];assert p.stat().st_size==pin['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
L=B/f'verified-handoff-capacity-{rate}-d1-root-review-r1/materialized/attempt-{rate}/idle-arm/load'
startup=json.loads((B/'verified-handoff-capacity-startup-reproduction-r1/RESULT.json').read_text());start=next(r['firstMaintenanceStartNs']for r in startup['observations']if r['rate']==rate)
first={};frames=0;duplicates=0;last=-10**30
with p.open('rb')as f:
 while (h:=f.read(12)):
  assert len(h)==12;stamp,n=struct.unpack('>qi',h);assert 0<n<1024*1024
  data=f.read(n);assert len(data)==n and struct.unpack_from('>IH',data)==(0x564d5233,3);pos=6
  def text(maximum):
   global pos
   size=struct.unpack_from('>i',data,pos)[0];pos+=4;assert 0<=size<=maximum and pos+size<=len(data)
   value=data[pos:pos+size].decode('utf-8',errors='strict');pos+=size;return value
  profile=text(64);lineage=text(64);correlation=struct.unpack_from('>q',data,pos)[0];pos+=8+7*8
  state=text(64);error=text(128);assert not error;kind=data[pos]
  assert stamp>=last;last=stamp;frames+=1
  if kind==5:
   count=struct.unpack_from('>i',data,pos+1)[0];assert 1<=count<=4
   if correlation in first:duplicates+=1
   else:first[correlation]=dict(stamp=stamp,members=count)
with(L/'arrivals.csv').open()as f:rows=list(csv.DictReader(f))
accepted=[r for r in rows if r['result_code']=='ACCEPTED'];assert accepted
seen={};decomp=[]
for r in accepted:
 correlation=int(r['correlation_id']);reply=first[correlation];seen[correlation]=seen.get(correlation,0)+1
 end=int(r['reply_completion_offset_ns']);offer=int(r['first_successful_offer_return_offset_ns']);stamp=reply['stamp']
 assert offer<=stamp<=end
 decomp.append(dict(index=int(r['arrival_index']),end=end,post=end-offer,beforeTapeTimestamp=stamp-offer,afterTapeTimestamp=end-stamp))
assert set(first)==set(seen)and all(first[c]['members']==count for c,count in seen.items())
def stats(v):
 v=sorted(v);return dict(count=len(v),meanNs=sum(v)/len(v),p50Ns=v[math.ceil(.5*len(v))-1],p99Ns=v[math.ceil(.99*len(v))-1],maxNs=v[-1],sumNs=sum(v))
def summary(items):
 result={key:stats([v[key]for v in items])for key in('post','beforeTapeTimestamp','afterTapeTimestamp')}
 result['afterTapeTimestampShareOfSummedPostOffer']=result['afterTapeTimestamp']['sumNs']/result['post']['sumNs'];return result
initial=[v for v in decomp if v['end']<=start];assert len(initial)==3069
result=dict(passed=True,rate=rate,accepted=len(accepted),allAcceptedRowsLinked=True,recordedFrames=frames,businessReplyFrames=len(first),duplicateBusinessFrames=duplicates,all=summary(decomp),beforeFirstMaintenance=summary(initial),originalReplyPin=pin,sourceCsvSha256=hashlib.sha256((L/'arrivals.csv').read_bytes()).hexdigest(),sourcePins={str(q.relative_to(R)):hashlib.sha256(q.read_bytes()).hexdigest()for q in(R/'cluster/src/main/java/io/vectormatch/cluster/RetentionReplyV3.java',R/'cluster/src/main/java/io/vectormatch/cluster/RetentionCapacityExperimentV3.java',R/'cluster/src/main/java/io/vectormatch/cluster/RetentionBatchOwnerV3.java')},scope='Read-only exact timestamps from privately archived canonical reply bytes and original CSV. Tape timestamp is after reply re-encoding and immediately before buffered raw writes;completion follows raw writes and owner callback. Earlier polling/decode/re-encoding,transport,replication,service,GC and scheduling remain combined before that timestamp. Not a causal attribution,network RTT or a new workload.',sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
O.mkdir();(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,rate=rate,accepted=len(accepted),startup=result['beforeFirstMaintenance'],all=result['all'])))
