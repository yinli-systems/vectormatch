from pathlib import Path
import os,json,sys,stat,time,datetime,hashlib,socket
case=sys.argv[1];assert case in('c1','d1','c2','d2')and os.geteuid()==0 and socket.gethostname()=='33ace3d92505'
root=Path('/opt/vectormatch-cpu');output=root/'experiments'/f'verified-handoff-client-jfr-7500-{case}-r1'/'cache-precondition.json';assert output.parent.is_dir()and not output.exists()
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='8d765c71-dbfa-4354-8db0-6c392e701e6f'
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=(p/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(args[0])).name
    except(FileNotFoundError,ProcessLookupError):continue
    assert name not in('java','javaw','postgres','postmaster'),'Java/SQL process active;no cache hints'
def memory():
    p=Path('/sys/fs/cgroup');s=dict(line.split()for line in(p/'memory.stat').read_text().splitlines())
    return dict(current=int((p/'memory.current').read_text()),maximum=int((p/'memory.max').read_text()),anon=int(s['anon']),file=int(s['file']),inactiveFile=int(s['inactive_file']),dirty=int(s['file_dirty']),writeback=int(s['file_writeback']))
def identity(s):return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns)
before=memory();assert before['maximum']==64000000000 and before['anon']<1024**3,'Only idle file-cache preconditioning is permitted'
rows=[];seen=set()
for p in sorted(root.rglob('*')):
    if p.is_symlink()or not p.is_file():continue
    s=p.stat()
    if s.st_size<4*1024**2 or(s.st_dev,s.st_ino)in seen:continue
    assert p.resolve().is_relative_to(root)if hasattr(p.resolve(),'is_relative_to')else str(p.resolve()).startswith(str(root)+'/')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        original=identity(os.fstat(fd));assert original==identity(s)
        os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
        assert identity(os.fstat(fd))==original and identity(p.stat())==original
    finally:os.close(fd)
    seen.add((s.st_dev,s.st_ino));rows.append(dict(path=str(p),**original,advice='POSIX_FADV_DONTNEED',openedReadOnly=True,metadataUnchanged=True))
time.sleep(.25);after=memory()
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),caseId=case,before=before,after=after,files=rows,
    advisedUniqueFiles=len(rows),allFileMetadataUnchanged=True,noFileDataWrittenOrDeleted=True,noGlobalDropCaches=True,
    scope='Same preconditioning before each registered arm:read-only advisory eviction of closed program files >=4MiB,under this project root only. It does not change limits,prove an exact reclaimed-byte amount or constitute an application optimization.')
output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
