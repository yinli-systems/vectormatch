from pathlib import Path
import datetime, hashlib, importlib.util, json, shlex, sys

B = Path(__file__).resolve().parent.parent
case = sys.argv[1]
assert case in ('c1', 'd1', 'c2', 'd2')
O = B / f'verified-handoff-client-jfr-7500-{case}-cache-precondition-r1'
assert not O.exists()
source = (Path(__file__).parent / 'advise_remote.py').read_text()
assert json.loads((B / f'verified-handoff-client-jfr-7500-{case}-controller-stage-r1/stdout.json').read_text())['passed']
O.mkdir()
registration = dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), caseId=case,
                    sourceSha256=hashlib.sha256(source.encode()).hexdigest(), oneAttemptOnly=True)
(O / 'REGISTRATION.json').write_text(json.dumps(registration, indent=2, sort_keys=True) + '\n')
spec = importlib.util.spec_from_file_location('remote', B / 'current-read-window32-collection-preparation-r2/remote_current.py')
remote = importlib.util.module_from_spec(spec)
spec.loader.exec_module(remote)
r = remote.run(shlex.join(['python3', '-B', '-c', source, case]), timeout=120)
(O / 'stdout.json').write_text(r.stdout)
(O / 'stderr').write_text(r.stderr)
(O / 'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode), indent=2) + '\n')
assert r.returncode == 0
result = json.loads(r.stdout)
assert result['passed'] and result['caseId'] == case and result['allFileMetadataUnchanged']
print(json.dumps({k: v for k, v in result.items() if k != 'files'}))
