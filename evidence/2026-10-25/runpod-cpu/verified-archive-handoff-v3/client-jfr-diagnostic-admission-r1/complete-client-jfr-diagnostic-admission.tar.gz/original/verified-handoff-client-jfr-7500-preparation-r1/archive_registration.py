from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;prefix='verified-handoff-client-jfr-7500';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/client-jfr-diagnostic-admission-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
prep=json.loads((P/'PREPARED.json').read_text());review=json.loads((B/(prefix+'-d1-controller-review-r1/SOURCE_REVIEW.json')).read_text());assert prep['passed']and review['passed']and review['diagnosticGuards']==6
names=[P.name,prefix+'-smoke-r1',prefix+'-d1-controller-preparation-r1',prefix+'-d1-controller-review-r1','verified-handoff-capacity-callback-diagnosis-preparation-r1','verified-handoff-capacity-telemetry-input-r1','verified-handoff-capacity-telemetry-diagnosis-failed-r1','verified-handoff-capacity-telemetry-diagnosis-r2','verified-handoff-capacity-reporting-private-proof-r1','dispatch-capacity-scope-tar-preparation-r1']
names.extend(prefix+'-'+n for n in prep['helperFamilies']);names.extend(f'verified-handoff-capacity-{rate}-callback-diagnosis-r1'for rate in(6000,7000,7500))
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-client-jfr-diagnostic-admission.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(P/'PREPARED.json',A/'PREPARED.json')
p=A/'published/docs/CLIENT_JFR_DIAGNOSTIC_V3.md';p.parent.mkdir(parents=True);shutil.copy2(R/'docs/CLIENT_JFR_DIAGNOSTIC_V3.md',p)
(A/'README.md').write_text('''# Parent/client JFR diagnostic admission

Fresh150000@7500/s synthetic diagnostic only. Original failed7500 capacity point is unchanged;8000 remains unexecuted,no escalation is permitted. Exact application,JDK,leader,durability,workload/window/readiness/sampler bodies are retained. Only parent JFR/GC flags and an additional128MiB diagnostic allocation reserve change;three node JVM arguments do not. This cannot establish node GC,pure network or an optimization gain.

Whole original admission scopes include every actual controller/helper/frozen-source byte,strict guard review,actual Linux JDK argument/JFR smoke,private original-curve proof and read-only reply-callback/CPU telemetry diagnosis. The previous telemetry parser failure is retained. Original large reply inputs remain in the three sibling private assets with complete SHA/member proofs;the derived timestamp results pin those exact bodies. Registration restoration from actual private Git blobs is required before stage/launch. No new workload or capacity result is claimed by this package.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,diagnosticOnly=True,sourceFreezeSha256=prep['sourceFreezeSha256'],noApplicationOrOrdersExecuted=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'],scopeCount=len(names))))
