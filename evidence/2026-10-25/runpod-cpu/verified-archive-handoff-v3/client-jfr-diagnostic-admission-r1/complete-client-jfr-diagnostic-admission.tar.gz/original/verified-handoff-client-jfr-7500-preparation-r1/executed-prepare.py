from pathlib import Path
import ast,hashlib,json,shutil,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent
old='verified-handoff-capacity-7500';new='verified-handoff-client-jfr-7500';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((B/'verified-handoff-capacity-reporting-private-proof-r1/PRIVATE_PUSH.json').read_text())['passed']
smoke=json.loads((B/(new+'-smoke-r1')/'RESULT.json').read_text());assert smoke['passed']and smoke['strictOwnedPidAbsent']
controller=B/(new+'-d1-controller-preparation-r1');assert not controller.exists();shutil.copytree(B/(old+'-d1-controller-preparation-r1'),controller)
release=json.loads((controller/'release.json').read_text());job='/opt/vectormatch-cpu/experiments/'+new+'-d1-r1/attempt-7500'
flags=smoke['arguments'][1:-1];smokeRoot='/opt/vectormatch-cpu/experiments/'+new+'-smoke-r1';flags=[f.replace(smokeRoot,job)for f in flags]
assert flags[0]=='-Xmx256m'and len(flags)==4
release['parentJvmArguments']=release['parentJvmArguments']+flags[1:]
release.update(scope='CLIENT_JFR_DIAGNOSTIC_7500_20S_NOT_CAPACITY_PROGRESSION',instrumentationEnabled=True,diagnosticOnly=True,diagnosticAllocationReserveBytes=128*1024**2,diagnosticRegistrationPrivateSha256=sha(B/'verified-handoff-capacity-reporting-private-proof-r1/PRIVATE_PUSH.json'))
(controller/'release.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\n');shutil.copy2(B/'verified-handoff-capacity-reporting-private-proof-r1/PRIVATE_PUSH.json',controller/'diagnostic-registration-private.json')
shutil.copy2(B/(old+'-d1-private-proof-r1')/'PRIVATE_PUSH.json',controller/'failed-capacity-private.json')
s=(controller/'first_pilot.py').read_text().replace(old+'-d1-r1',new+'-d1-r1')
a=s.index("        if sampler['priorRate'] is not None:");z=s.index("        qualified=json.loads",a)
gate="""        diagnostic=json.loads((HERE/'diagnostic-registration-private.json').read_text())
        failed=json.loads((HERE/'failed-capacity-private.json').read_text())
        require(digest(HERE/'diagnostic-registration-private.json')==r['diagnosticRegistrationPrivateSha256']and diagnostic['passed']and diagnostic['private']and diagnostic['stoppedAtRate']==7500 and diagnostic['unexecutedRates']==[8000]and diagnostic['higherLoadPermitted']is False,'Failed curve must remain stopped;this is a separate diagnostic only')
        require(failed['passed']and failed['private']and failed['completeAuthenticatedAssetDownloadVerified']and failed['finiteProgressionPermitted']is False and failed['nextRegisteredRate']is None and failed['allArrivalP99Ns']is None,'Original severe overload cannot be overwritten or promote higher load')
        validate_diagnostics(r)
"""
s=s[:a]+gate+s[z:]
s=s.replace('    m.parent_argv=parent_argv;m.preflight=preflight','    original_allocation_limit=m.allocation_limit\n    m.allocation_limit=lambda r:original_allocation_limit(r)+r[\'diagnosticAllocationReserveBytes\']\n    m.parent_argv=parent_argv;m.preflight=preflight')
expected=release['parentJvmArguments']
guard="\ndef validate_diagnostics(r):\n    require(r.get('diagnosticOnly')is True and r.get('instrumentationEnabled')is True and r.get('higherLoadPermitted')is False,'Explicit diagnostic-only mode required')\n    require(r['parentJvmArguments']=="+repr(expected)+",'Exact parent-only JFR/GC flags required')\n    require(r['diagnosticAllocationReserveBytes']==134217728,'Additional diagnostic allocation reserve required')\n\n"
s=s.replace('\ndef main():',guard+'def main():').replace('Fresh150000@7500 registered common-sampler handoff retest','Fresh150000@7500 parent-JFR diagnostic;not capacity progression')
(controller/'first_pilot.py').write_text(s)
# Source bodies that own PID/signals/readiness stay byte-identical to the qualified sampler.
sampler=json.loads((controller/'sampler-qualification-private.json').read_text());assert sampler['newComparisonPrefix']==old
for n,pin in sampler['controllerInputRows'].items():assert sha(controller/n)==pin['sha256']
shutil.copy2(P/'prepare.py',P/'executed-prepare.py')
helperSuffixes=['controller-review-preparation-r1','runner-r1','root-review-preparation-r1','schema-audit-preparation-r1','workload-audit-preparation-r1','bottleneck-preparation-r1','recovery-preparation-r1','maintenance-phases-preparation-r1','native-archive-preparation-r1','native-private-proof-preparation-r2','local-duplicate-retirement-preparation-r1','cache-precondition-preparation-r1']
for suffix in helperSuffixes:
 dst=B/(new+'-'+suffix);assert not dst.exists();shutil.copytree(B/(old+'-'+suffix),dst)
 for p in dst.rglob('*.py'):
  text=p.read_text().replace(old,new).replace('capacity-7500-arm-', 'client-jfr-7500-arm-').replace('handoff-capacity-7500-', 'handoff-client-jfr-7500-')
  if suffix=='controller-review-preparation-r1':text=text.replace("sampler['newComparisonPrefix']=='"+new+"'","sampler['newComparisonPrefix']=='"+old+"'")
  if suffix=='native-archive-preparation-r1':
   text=text.replace("'controller-generator','controller-review-preparation'","'controller-review-preparation'")
   text=text.replace("names.extend(['exitwait-local-sparse-cache-r1','verified-handoff-capacity-admission-preparation-r1',f'{prefix}-admission-private-proof-r1'])","names.extend(['"+new+"-preparation-r1','"+new+"-smoke-r1','"+old+"-admission-private-proof-r1','verified-handoff-capacity-reporting-private-proof-r1','verified-handoff-capacity-callback-diagnosis-preparation-r1','verified-handoff-capacity-telemetry-input-r1','verified-handoff-capacity-telemetry-diagnosis-failed-r1','verified-handoff-capacity-telemetry-diagnosis-r2'])\nfor rate in (6000,7000,7500):names.append(f'verified-handoff-capacity-{rate}-callback-diagnosis-r1')")
   text=text.replace("R/'docs/VERIFIED_HANDOFF_CAPACITY_V3.md'","R/'docs/CLIENT_JFR_DIAGNOSTIC_V3.md'")
   text=text.replace('One finite comparison observation','One instrumented diagnostic observation')
  if suffix=='native-private-proof-preparation-r2':
   text=text.replace("permitted=known and root['windowConfirmationFraction']>=.99 and root['allArrivalP99Ns']is not None and root['allArrivalP99Ns']<=1000000000","permitted=False # Instrumented diagnostic can never reopen failed capacity progression")
   text=text.replace('nextRegisteredRate=8000 if permitted else None','nextRegisteredRate=None').replace('noSustainedCapacityOrRealtimeClaim=True','diagnosticOnly=True,noSustainedCapacityOrRealtimeClaim=True')
  if suffix=='root-review-preparation-r1':
   text=text.replace("or n.endswith('.py')or n.endswith('pilot-after-clean-stop.tar.gz')","or n.endswith('.py')or n.endswith('client.jfr')or n.endswith('pilot-after-clean-stop.tar.gz')")
  if suffix=='runner-r1' and p.name=='stage.py':
   text=text.replace("O.mkdir();assert json.loads", "O.mkdir();assert json.loads((B/'"+new+"-registration-private-proof-r1/PRIVATE_PUSH.json').read_text())['passed'];assert json.loads")
  p.write_text(text)
# Exact flags/extra allocation are checked by the real preflight and hostile fixtures.
review=B/(new+'-controller-review-preparation-r1/review.py');text=review.read_text();needle='O.mkdir()'
extra="""import importlib.util
spec=importlib.util.spec_from_file_location('diagnostic_first',P/'first_pilot.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
d.validate_diagnostics(r);diagnosticGuards=1
for key,value in [('parentJvmArguments',r['parentJvmArguments'][:-1]),('diagnosticOnly',False),('instrumentationEnabled',False),('higherLoadPermitted',True),('diagnosticAllocationReserveBytes',0)]:
 bad=copy.deepcopy(r);bad[key]=value
 try:d.validate_diagnostics(bad)
 except RuntimeError:diagnosticGuards+=1
 else:raise AssertionError('diagnostic guard admitted '+key)
assert d.PREP==Path('/opt/vectormatch-cpu/experiments/verified-handoff-client-jfr-7500-d1-r1')
"""
assert text.count(needle)==1;text=text.replace(needle,extra+needle).replace('rate=rate,pureFixtureGuards=guards,','rate=rate,pureFixtureGuards=guards,diagnosticOnly=True,diagnosticGuards=diagnosticGuards,')
review.write_text(text)
files={}
for p in sorted(controller.iterdir()):
 if p.name in('FROZEN.json','source-package.tar.gz')or not p.is_file():continue
 if p.suffix=='.py':ast.parse(p.read_text())
 p.chmod(0o644);files[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p),mode=420)
(controller/'FROZEN.json').write_text(json.dumps(dict(schemaVersion=1,files=files,caseId='d1',onlySelectedOfferedRate=7500,diagnosticOnly=True,parentOnlyJfr=True,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
with tarfile.open(controller/'source-package.tar.gz','w:gz')as t:
 for n in list(files)+['FROZEN.json']:t.add(controller/n,arcname=n,recursive=False)
for suffix in helperSuffixes:
 for p in (B/(new+'-'+suffix)).rglob('*.py'):ast.parse(p.read_text())
(P/'PREPARED.json').write_text(json.dumps(dict(passed=True,prefix=new,sourceFreezeSha256=sha(controller/'FROZEN.json'),samplerSevenBodiesUnchanged=True,applicationJarsUnchanged=True,sourceCommit=release['sourceCommit'],codeFingerprint=release['codeFingerprint'],diagnosticOnly=True,parentJvmArguments=expected,extraAllocationReserveBytes=134217728,helperFamilies=helperSuffixes),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,helperFamilies=len(helperSuffixes),samplerSevenBodiesUnchanged=True,sourceFreezeSha256=sha(controller/'FROZEN.json'))))
