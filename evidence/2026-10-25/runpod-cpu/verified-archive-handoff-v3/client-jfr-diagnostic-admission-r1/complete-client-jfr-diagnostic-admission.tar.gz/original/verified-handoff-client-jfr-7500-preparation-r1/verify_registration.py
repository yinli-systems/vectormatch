from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/client-jfr-diagnostic-admission-r1';O=B/'verified-handoff-client-jfr-7500-registration-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A);assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(R).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
assert git('show',head+':docs/CLIENT_JFR_DIAGNOSTIC_V3.md')==(A/'published/docs/CLIENT_JFR_DIAGNOSTIC_V3.md').read_bytes()==(R/'docs/CLIENT_JFR_DIAGNOSTIC_V3.md').read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/complete-client-jfr-diagnostic-admission.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='yinli-systems/vectormatch',private=True,commit=head,bothRemoteBranchesVerified=True,allGitMetadataBlobsVerified=len(paths),wholeAdmissionTarRestoredFromActualGitBlob=True,everyOriginalMemberVerified=members,sourceFreezeSha256=closed['sourceFreezeSha256'],diagnosticOnly=True,onlyRegisteredRate=7500,onlyRegisteredCase='d1',parentOnlyJfr=True,failedCapacityCurvePreserved=True,unexecutedRates=[8000],higherLoadPermitted=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
