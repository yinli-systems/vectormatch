from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-incomplete-reporting-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
report=B/'verified-archive-handoff-retest-incomplete-reporting-r1';c=json.loads((report/'COMPARISON.json').read_text());applied=json.loads((report/'APPLIED.json').read_text())
assert c['passed'] and c['campaignComplete']is False and applied['passed'] and applied['indexSha256']==sha(R/'evidence/index.json')
names=['verified-archive-handoff-retest-incomplete-reporting-r1',P.name,'verified-archive-handoff-retest-reporting-preparation-r1',
 'verified-archive-handoff-retest-workload-audit-preparation-r1','verified-archive-handoff-retest-bottleneck-preparation-r1',
 'verified-archive-handoff-retest-recovery-preparation-r1','verified-archive-handoff-retest-maintenance-phases-preparation-r1',
 'verified-archive-handoff-retest-schema-audit-preparation-r1','verified-archive-handoff-retest-c1-private-proof-r1',
 'verified-archive-handoff-retest-c1-workload-audit-r1','verified-archive-handoff-retest-c1-schema-audit-r1',
 'verified-archive-handoff-retest-c1-bottleneck-r1','verified-archive-handoff-retest-c1-cut-recovery-r1',
 'verified-archive-handoff-retest-c1-maintenance-phases-r1','verified-archive-handoff-retest-c1-duplicate-retirement-r1',
 'verified-archive-handoff-retest-d1-invalid-review-preparation-r1','verified-archive-handoff-retest-d1-invalid-review-r1',
 'verified-archive-handoff-retest-d1-invalid-archive-preparation-r1','verified-archive-handoff-retest-d1-invalid-private-proof-preparation-r1',
 'verified-archive-handoff-retest-d1-invalid-private-proof-preparation-r2','verified-archive-handoff-retest-d1-invalid-private-proof-r1',
 'verified-archive-handoff-retest-d1-invalid-private-proof-r2','verified-archive-handoff-retest-d1-invalid-local-retirement-preparation-r1',
 'verified-archive-handoff-retest-d1-invalid-duplicate-retirement-r1','verified-archive-handoff-retest-d1-workload-audit-r1',
 'verified-archive-handoff-retest-d1-schema-audit-r1','process-identity-r-state-exit-diagnosis-r1',
 'process-identity-exit-wait-linux-r1','dispatch-capacity-scope-tar-preparation-r1']
assert len(set(names))==len(names);before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-incomplete-retest-and-exit-diagnosis.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
review=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for n in ['README.md','docs/VERIFIED_ARCHIVE_HANDOFF_RETEST_RESULTS_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md','evidence/index.json']:
 p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
shutil.copy2(report/'COMPARISON.json',A/'COMPARISON.json')
(A/'README.md').write_text('''# Common-sampler retest remains incomplete

C1 is a valid finite4000/s20s observation:80,000 orders/trades,0 missing/rejected/unknown,p99241.521518ms. D1 reconciles all80,000 orders/trades but fails process identity for follower89217,R/R,empty argv;its218.194957ms quantile is diagnostic. C2/D2 are never executed. Neither failed native status is waived. No valid paired comparison exists.

The original native/raw bytes remain in the two committed private-release manifests,already authenticated-downloaded in full and member-verified. This package preserves those private proofs,all analysis/audit sources and results,the failed first D1 download and successful same-asset retry,local redundant-copy retirement receipts,the prepared but unexecuted four-case reporting source,and original/derived UI index and HTTP receipts. The same-kernel six512MiB natural-exit observation and complete26-test Python3.8 focused output are retained with source. PF_EXITING alone never proves absence. Full CI and new controller qualification remain separate. All58 earlier runs/24 cohorts are unchanged;60/26 now expose both incomplete campaigns. No performance gain,SLA,100M or production certification is claimed.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=review,campaignComplete=False,records=60,cohorts=26,validCases=['c1'],invalidCases=['d1'],unexecutedCases=['c2','d2'],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalReportingFiles=review['originalFiles'],payloadFiles=len(inv['files']))))
