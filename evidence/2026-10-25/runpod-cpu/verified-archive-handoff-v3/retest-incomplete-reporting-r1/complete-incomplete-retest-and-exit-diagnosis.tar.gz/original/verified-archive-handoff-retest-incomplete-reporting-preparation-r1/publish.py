from pathlib import Path
import json,hashlib,datetime,urllib.request
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-archive-handoff-retest-incomplete-reporting-r1'
x=json.loads((O/'COMPARISON.json').read_text());assert x['passed'] and not x['campaignComplete'] and x['unexecutedCases']==['c2','d2']
assert not(O/'APPLIED.json').exists() and (R/'evidence/index.json').read_bytes()==(O/'index-before.json').read_bytes()
text='''# Common-sampler immutable handoff retest: incomplete

C1 passes complete native/readiness/raw/private-closure gates. D1 reconciles every original business outcome but fails the common CI7 process-identity sampler. D1 remains invalid;C2/D2 never execute. This campaign contains no valid paired performance comparison.

Each arm uses80,000 fresh one-unit IOC orders at4,000 scheduled arrivals/s for20s,matching one pre-funded seeded maker at10 ticks. Every original order agrees with one unique trade event. Zero notSent,rejection,observed UNKNOWN and final UNKNOWN;all three snapshot logs agree. This is synthetic trading through the actual matching/replication path,not an external venue or funded account.

Both arms fix leader0,sync2,ROTATING_CONTINUE,read128/page32/batch4/chunk6144,owner1ms/driver100us,W128/Q64,one physical session and three JVMs on one CPU. The pinned JDK,boot,affinity,cgroups,two2s readiness observations around setup/5s warm-up,and project-only cache preconditioning match the registration. No JFR. C uses CI5 sourceaed9430d/codef3a5745c;D uses CI6 source23f9c070/code79e5a932. The common sampler is CI7 source4198aadd/bodycf2dd046;it is separate from the application artifacts. Full forced canonical readback and durable receipt completion precede either destructive ACK.

| Arm | Native gate | Orders / trade events | In-window goodput/s | Qualified all-arrival p99 ms | Diagnostic p99 ms |
| --- | --- | ---: | ---: | ---: | ---: |
'''
for r in x['observations']:
 qualified=f"{r['globalQualifiedP99Ns']/1e6:.6f}" if r['valid'] else '—'
 text+=f"| {r['caseId'].upper()} | {'Valid finite observation' if r['valid'] else 'INVALID process identity'} | 80,000 / 80,000 | {r['goodput']:.2f} | {qualified} | {r['diagnosticAllArrivalP99Ns']/1e6:.6f} |\n"
text+='''
The D1 exception identifies follower PID89217,start15735209,phase cmdline,state R/R,argvBytes0. All four owned JVMs subsequently stop without forced kill or numeric-PID signal fallback. Complete original frames,offers,CSV,events,readiness,configuration,source and lifecycle records remain archived. Its diagnostic218.194957ms p99 is not a qualified treatment measurement and is not used to claim a performance gain.

The [exit-window investigation](PROCESS_IDENTITY_OBSERVATION.md) observes six same-kernel owned512MiB natural exits with an18–20ms empty-argv/PF_EXITING/R interval before terminal proof. The first sampler retries only2ms. The revised sampler waits boundedly for proven exit after PF_EXITING;that flag alone never counts as absence. The historical D1 error does not contain flags,so no claim is made that every kernel step has been established for that exact JVM. The revised helper needs separate full CI/controller qualification and a fresh campaign;neither frozen lineage is rerun.

## Full private evidence

'''
for r in x['observations']:
 text+=f"- [{r['caseId'].upper()} complete original archive](../{r['archivePath']}/README.md):asset{r['assetId']},{r['assetBytes']:,} bytes,SHA-256`{r['assetSha256']}`;every authenticated byte/member verified at`{r['privateCommit']}`.\n"
text+='''
The reporting package retains both original closure proofs,all counting/audit sources and results,the failed first authenticated-download attempt and its successful same-asset retry,diagnosis observations,the prepared but unexecuted four-arm report,and unchanged/derived index. Every58 earlier run and24 earlier cohort is retained;the two new observations occupy separate artifact cohorts:60 runs/26 cohorts. D1 is visibly invalid and has no qualified p99 or stability marker. HTTP verification does not constitute browser rendering. Neither this incomplete retest nor separate fresh lineages establish sustained capacity,a millisecond SLA,physical-host isolation,100M endurance,production certification or HFT endorsement.
'''
target=R/'docs/VERIFIED_ARCHIVE_HANDOFF_RETEST_RESULTS_V3.md';assert not target.exists();target.write_text(text)
(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
applied=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),indexSha256=sha(R/'evidence/index.json'),reportSha256=sha(target),records=60,cohorts=26,all58PriorRunsAnd24CohortsPreserved=True,campaignComplete=False)
(O/'APPLIED.json').write_text(json.dumps(applied,indent=2,sort_keys=True)+'\n')
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10)as response:body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body);j=json.loads(body)
http=dict(passed=status==200 and j==json.loads((R/'evidence/index.json').read_text()),status=status,records=len(j['runs']),cohorts=len(j['capacityCohorts']),bodySha256=hashlib.sha256(body).hexdigest(),browserRenderVerified=False)
(O/'HTTP_REVIEW.json').write_text(json.dumps(http,indent=2,sort_keys=True)+'\n');assert http['passed'];print(json.dumps(dict(applied=applied,http=http)))
