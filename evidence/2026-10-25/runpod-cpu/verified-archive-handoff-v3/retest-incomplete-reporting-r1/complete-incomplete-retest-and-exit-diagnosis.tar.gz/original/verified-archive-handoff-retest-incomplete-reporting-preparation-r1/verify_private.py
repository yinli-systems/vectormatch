from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-incomplete-reporting-r1';O=B/'verified-archive-handoff-retest-incomplete-reporting-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
closed=json.loads((A/'CLOSED.json').read_text());inv=json.loads((A/'INVENTORY.json').read_text());actual=tree(A)
assert closed['passed'] and closed['inventorySha256']==sha(A/'INVENTORY.json') and closed['campaignComplete']is False
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'} and actual['directories']==inv['directories'] and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(R).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
for n in ['README.md','docs/VERIFIED_ARCHIVE_HANDOFF_RETEST_RESULTS_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md','evidence/index.json']:assert git('show',head+':'+n)==(R/n).read_bytes()==(A/'published'/n).read_bytes()
O.mkdir();restored=O/'restored-report.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/complete-incomplete-retest-and-exit-diagnosis.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes'] and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
c=json.loads((A/'COMPARISON.json').read_text());native=[]
for case,invalid,proofName in [('c1',False,'private-proof-r1'),('d1',True,'invalid-private-proof-r2')]:
 p=B/f'verified-archive-handoff-retest-{case}-{proofName}/PRIVATE_PUSH.json';proof=json.loads(p.read_text());assert proof['passed'] and proof['completeAuthenticatedAssetDownloadVerified'] and proof['nativeControlPassed']is(not invalid)
 point=A.parent/(f'retest-arm-{case}-'+('invalid-native-r1'if invalid else'native-r1'));manifest=point/'ASSET_MANIFEST.json';a=json.loads(git('show',head+':'+manifest.relative_to(R).as_posix()));assert a==json.loads(manifest.read_text())
 assert a['assetId']==proof['assetId'] and a['sha256']==proof['assetSha256'] and a['bytes']==proof['assetBytes'] and sha(point/'INVENTORY.json')==proof['archiveInventorySha256']
 assert proof['allOriginalCompressedScopeMembersVerified']==json.loads((point/'CLOSED.json').read_text())['originalScopeReview']
 subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],head],check=True)
 native.append(dict(caseId=case,valid=not invalid,assetId=a['assetId'],assetSha256=a['sha256'],previousCompleteAuthenticatedMemberProofCommit=proof['commit'],proofSha256=sha(p)))
assert c['executedCases']==['c1','d1'] and c['unexecutedCases']==['c2','d2'] and c['all58PriorRunsAnd24CohortsPreserved']
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='yinli-systems/vectormatch',private=True,commit=head,bothRemoteBranchesVerified=True,reportingGitBlobsVerified=len(paths),reportingRestoredFromActualGitBlob=True,allOriginalReportingMembersVerified=members,native=native,bothNativeAssetsAlreadyFullyDownloadedAndMemberVerified=True,campaignComplete=False,validCases=['c1'],invalidCases=['d1'],unexecutedCases=['c2','d2'],originalInvalidQualificationRetained=True,repeatableOptimizationEstablished=False,all58PriorRunsAnd24CohortsPreserved=True,records=60,cohorts=26,browserRenderVerified=False,higherLoadPermitted=False,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
