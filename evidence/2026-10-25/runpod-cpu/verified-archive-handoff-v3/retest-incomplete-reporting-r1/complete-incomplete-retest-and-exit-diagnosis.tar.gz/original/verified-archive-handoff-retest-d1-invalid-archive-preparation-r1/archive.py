from pathlib import Path
import datetime,json,shutil,subprocess,sys,tarfile

R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';case=sys.argv[1];assert case=='d1'
prefix='verified-archive-handoff-retest';A=R/f'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-arm-{case}-invalid-native-r1';T=B/f'{prefix}-{case}-invalid-archive-r1'
assert not A.exists() and not T.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'))
from scope_tar import tree,verify,sha
root=B/f'{prefix}-{case}-root-review-r1'
r=json.loads((root/'ROOT_REVIEW.json').read_text());raw=json.loads((root/'RAW_AUDIT.json').read_text());ready=json.loads((root/'INVALID_READINESS_REVIEW.json').read_text())
schema=json.loads((B/f'{prefix}-{case}-schema-audit-r1/SCHEMA_AUDIT.json').read_text())
assert all(x['passed']for x in (r,raw,ready,schema)) and r['nativeControlPassed']is False and r['performanceQualified']is False and ready['nextRunQualified']is False
assert r['caseId']==raw['caseId']==ready['caseId']==schema['caseId']==case and schema['verifiedArchiveHandoffExpected']==case.startswith('d')
names=[f'{prefix}-{case}-{suffix}-r1'for suffix in ('controller-preparation','controller-review','controller-stage','launch','collection','root-review','review-execution','cache-precondition','schema-audit')]
for pattern in (f'{prefix}-{case}-preflight-r*',f'{prefix}-{case}-probe-r*'):names.extend(p.name for p in sorted(B.glob(pattern)))
names.extend([f'{prefix}-{n}-r1'for n in ('controller-generator','controller-review-preparation','runner','root-review-preparation',
    'native-archive-preparation','native-private-proof-preparation','bottleneck-preparation','recovery-preparation','maintenance-phases-preparation')])
names.extend(['verified-archive-handoff-retest-schema-audit-preparation-r1','verified-archive-handoff-retest-cache-precondition-preparation-r1',
    'verified-archive-handoff-qualification-private-proof-r1','verified-archive-handoff-qualification-private-proof-preparation-r1',
    'dispatch-capacity-scope-tar-preparation-r1','dispatch-capacity-scope-tar-validation-r1',
    'current-maintained-capacity-streaming-decoder-preparation-r1','current-maintained-capacity-streaming-decoder-validation-r1'])
names.extend(['verified-archive-handoff-retest-d1-invalid-archive-preparation-r1','verified-archive-handoff-retest-d1-invalid-private-proof-preparation-r1','verified-archive-handoff-retest-d1-invalid-review-preparation-r1','verified-archive-handoff-retest-d1-invalid-review-r1','verified-archive-handoff-retest-workload-audit-preparation-r1','verified-archive-handoff-retest-d1-workload-audit-r1'])
names.extend(['process-identity-retest-qualification-private-proof-r1','process-identity-retest-qualification-preparation-r1','process-identity-controller-bridge-preparation-r1','process-identity-controller-native-proof-r1','process-identity-r-state-exit-diagnosis-r1'])
assert len(set(names))==len(names)
before={n:tree(B/n)for n in names};logical=sum(sum(v['bytes']for v in scope['files'].values())for scope in before.values())
assert logical<12*1024**3 and shutil.disk_usage(R).free>=1024**3+min(logical,1024**3)
T.mkdir();bundle=T/f'handoff-retest-{case}-invalid-complete-original-scopes-r1.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(bundle,before);assert bundle.stat().st_size<1024**3 and all(tree(B/n)==before[n]for n in names)
repo='yinli-systems/vectormatch';releaseId=423510304;tag='evidence-private-20261025'
def api(path):return json.loads(subprocess.check_output(['gh','api',path]))
assert api('repos/'+repo)['private']
release=api('repos/'+repo+'/releases/'+str(releaseId));assert release['draft'] and release['tag_name']==tag
assert not any(a['name']==bundle.name for a in release['assets'])
registration=dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo,releaseId=releaseId,releaseTag=tag,
    assetName=bundle.name,bytes=bundle.stat().st_size,sha256=sha(bundle),completeScopeMembers=members,oneUploadOnly=True)
(T/'UPLOAD_REGISTRATION.json').write_text(json.dumps(registration,indent=2,sort_keys=True)+'\n')
with(T/'upload.stdout').open('xb')as out,(T/'upload.stderr').open('xb')as err:
    upload=subprocess.run(['gh','release','upload',tag,str(bundle),'--repo',repo],stdout=out,stderr=err,timeout=300)
(T/'UPLOAD_EXECUTION.json').write_text(json.dumps(dict(exitCode=upload.returncode),indent=2)+'\n')
assert upload.returncode==0,'Preserve files and inspect remote asset;no overwrite or blind re-upload'
after=api('repos/'+repo+'/releases/'+str(releaseId));matches=[a for a in after['assets']if a['name']==bundle.name];assert len(matches)==1
asset=matches[0];assert asset['state']=='uploaded' and asset['size']==bundle.stat().st_size and asset['digest']=='sha256:'+sha(bundle)
assert all(tree(B/n)==before[n]for n in names)
A.mkdir(parents=True)
manifest=dict(schemaVersion=1,repository=repo,private=True,draft=True,releaseId=releaseId,releaseTag=tag,assetId=asset['id'],
    assetName=asset['name'],assetApiUrl=asset['url'],bytes=asset['size'],sha256=sha(bundle),serverDigest=asset['digest'],
    localOriginalArchive=str(bundle),caseId=case,codeFingerprint=r['codeFingerprint'],archiveFormat='complete-original-scope-tar-gzip',authenticatedFullDownloadRequired=True)
(A/'ASSET_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(A/'UPLOAD_METADATA.json').write_text(json.dumps(asset,indent=2,sort_keys=True)+'\n')
for name in ('UPLOAD_REGISTRATION.json','UPLOAD_EXECUTION.json','upload.stdout','upload.stderr'):shutil.copy2(T/name,A/name)
for name in ('ROOT_REVIEW.json','RAW_AUDIT.json','INVALID_READINESS_REVIEW.json'):
    p=A/'root-review'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
shutil.copy2(B/f'{prefix}-{case}-schema-audit-r1/SCHEMA_AUDIT.json',A/'SCHEMA_AUDIT.json')
qualification=A.parent/'qualification-r1'
(A/'SHARED_EVIDENCE_REFERENCES.json').write_text(json.dumps({n:dict(bytes=(qualification/n).stat().st_size,sha256=sha(qualification/n))for n in ('INVENTORY.json','CLOSED.json')},indent=2,sort_keys=True)+'\n')
shutil.copy2(R/'docs/VERIFIED_ARCHIVE_HANDOFF_V3.md',A/'REGISTERED_PLAN.md')
(A/'README.md').write_text('''# INVALID retest D1: complete original evidence

The original controller fails with Incomplete process identity during execution. All owned processes are confirmed stopped. Every planned80,000 order and trade reconciles with0 notSent/rejection/UNKNOWN,and all three snapshot logs agree,but nativeControlPassed and performanceQualified remain false. This is an invalid observation,not a valid capacity/latency point;Retest C2/D2 are not authorized by this archive.

The exception identifies follower PID89217,phase cmdline,state R/R,start15735209,argvBytes0. Six same-kernel owned512MiB natural exits reproduce an18-20ms R/empty/PF_EXITING interval. The original failure did not record flags;the original native failure stays invalid. Preserve every original file,source,error,process/readiness record and raw order/event tape. No original metric/status is overwritten or reclassified as a valid benchmark. The full compressed scope body is an attachment under the same private repository;the committed manifest and full member inventory identify its exact bytes. The independent private proof must download all bytes and verify every member. Qualified source and timing gates do not override the original native failure.
''')

inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),caseId=case,
    inventorySha256=sha(A/'INVENTORY.json'),assetManifestSha256=sha(A/'ASSET_MANIFEST.json'),archiveBytes=bundle.stat().st_size,
    archiveSha256=sha(bundle),originalScopeReview=members,allSourcesUnchanged=True,assetDownloadRequiredBeforeProgression=True,nativeControlPassed=False,performanceQualified=False,nextRunQualified=False,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,caseId=case,assetId=asset['id'],archiveBytes=bundle.stat().st_size,gitPayloadFiles=len(inv['files']),originalFiles=members['originalFiles'])))
