from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent.parent;P=B/'verified-archive-handoff-retest-d1-root-review-r1';O=B/'verified-archive-handoff-retest-d1-invalid-review-r1'
assert not O.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=json.loads((P/'ROOT_REVIEW.json').read_text());raw=json.loads((P/'RAW_AUDIT.json').read_text())
assert root['passed'] and raw['passed'] and root['nativeControlPassed']is False and root['performanceQualified']is False
assert root['nativeControlErrors']==[dict(error="IdentityReadError('Incomplete process identity pid=89217 phase=cmdline state=R/R startTicks=15735209 argvBytes=0')",phase='execution')]
assert root['confirmedAcceptedUniqueOrders']==80000 and root['notSent']==root['serverRejected']==root['unknownObserved']==root['unknownFinal']==0
A=P/'materialized/attempt-4000/idle-arm';cfg=json.loads((A/'load/configuration.json').read_text());warm=json.loads((A/'preload-warmup.json').read_text())
nodes={n:json.loads((A/f'node-{n}-identity.json').read_text())['pid']for n in range(3)}
sys.path.insert(0,str(B/'startup-readiness-controller-preparation-r2'));from readiness_validation import validate_readiness
gates=[]
for name in ('startup-readiness.json','preload-readiness.json'):
    p=A/name;gates.append(dict(file=name,sha256=sha(p),review=validate_readiness(json.loads(p.read_text()),nodes,cfg['scheduledOriginMonotonicNs'])))
assert gates[0]['review']['endedMonotonicNs']<=warm['startedMonotonicNs'] and warm['endedMonotonicNs']<=gates[1]['review']['startedMonotonicNs']
stop=json.loads((P/'materialized/attempt-4000/python-owned-stop.json').read_text());assert stop['allOwnedStopped']
functional=json.loads((A/'capacity-correctness-result.json').read_text());assert functional['passed'] and functional['allThreeSnapshotLogsMatched']
workload=json.loads((B/'verified-archive-handoff-retest-d1-workload-audit-r1/WORKLOAD.json').read_text())
assert workload['passed'] and workload['resultTradeCount']==workload['uniqueTradeEvents']==80000
O.mkdir();result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),caseId='d1',nativeControlPassed=False,
    performanceQualified=False,nextRunQualified=False,allOwnedStopped=True,knownOriginalOutcomesComplete=True,acceptedOrders=80000,tradeEvents=80000,
    notSent=0,rejected=0,unknownObserved=0,unknownFinal=0,originalNativeErrors=root['nativeControlErrors'],gates=gates,
    rawAuditSha256=sha(P/'RAW_AUDIT.json'),rootReviewSha256=sha(P/'ROOT_REVIEW.json'),workloadReviewSha256=sha(B/'verified-archive-handoff-retest-d1-workload-audit-r1/WORKLOAD.json'),
    originalExceptionPidAndExactReadPhaseUnavailable=False,failingPid=89217,failingRole='window-128-node-1',
    hypothesis='Follower pid89217 had empty cmdline with R/R state during execution. Actual same-kernel owned512MiB natural exits reproduce R/empty with PF_EXITING for18-20ms before terminal proof. Original D1 did not capture flags,so this supports the exit-teardown explanation without proving every historical kernel step. Preserve invalid status and do not advance retest C2/D2.',
    sources=['https://man7.org/linux/man-pages/man5/proc_pid_cmdline.5.html','https://docs.kernel.org/filesystems/proc.html'],sourceSha256=sha(Path(__file__)))
(O/'INVALID_CONTROL_REVIEW.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(P/'INVALID_READINESS_REVIEW.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='gates'}))
