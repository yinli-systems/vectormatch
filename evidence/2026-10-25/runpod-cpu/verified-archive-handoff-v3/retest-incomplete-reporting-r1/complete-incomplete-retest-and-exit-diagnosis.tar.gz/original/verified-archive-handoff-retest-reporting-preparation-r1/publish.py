from pathlib import Path
import datetime,hashlib,json,urllib.request
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=B/'verified-archive-handoff-retest-reporting-r1';assert not(O/'APPLIED.json').exists()
c=json.loads((O/'COMPARISON.json').read_text());assert c['passed']and c['all58PriorRunsAnd24CohortsPreserved']
assert(R/'evidence/index.json').read_bytes()==(O/'index-before.json').read_bytes()
rows=c['observations'];criterion=c['repeatedFiniteP99AndMaintenanceReduction']
text='''# Immutable handoff retest:one common qualified sampler

'''+('Both paired finite observations meet the registered criterion of lower all-arrival p99 and maintenance wall time.'if criterion else'The four observations do not meet the registered criterion of lower all-arrival p99 and maintenance wall time in both pairs.')+''' This is a finite descriptive comparison,not statistical significance,sustained capacity or a production SLA. All offer-to-reply and phase tradeoffs remain visible below.

Each arm contains80,000 fresh one-unit IOC orders at4,000 scheduled arrivals/s for20s,against one pre-funded seeded sell order at10 ticks. Every arm reconciles80,000 distinct accepted orders and80,000 trade events,with zero notSent,rejection,observed UNKNOWN or final UNKNOWN. This workload exercises one price,maker and fill per order;multi-level sweeps,cancel/replace,external venues and funded trading require separate evidence.

The [prospective retest registration](VERIFIED_ARCHIVE_HANDOFF_RETEST_V3.md) fixes leader0,sync2,ROTATING_CONTINUE,read128,page32,batch4,chunk6144,owner1ms,driver100us,W128/Q64,one physical session/three JVMs on one CPU host,JDK/boot/affinity/cgroups,readiness around setup/5s warm-up,no JFR,and the same project-only cache preconditioning. All four use the same qualified proc-directory/stat/cmdline/stat sampler. C uses sourceaed9430d/codef3a5745c;D uses source23f9c070/code79e5a932. All227 CI7 application classes equal qualified CI6 classes;actual benchmark JAR identities remain unchanged.

The [initial comparison](VERIFIED_ARCHIVE_HANDOFF_INITIAL_RESULTS_V3.md) remains separate and incomplete:C1/D1 valid,C2 invalid,D2 unexecuted. Its failure is never renamed or added as a valid retest observation. The sampler changes control-plane observation;the two campaigns are not merged into one capacity curve.

| Arm | Accepted / trade events | In-window goodput/s | All-arrival p50 ms | All-arrival p99 ms | After-positive-offer p99 ms | Clearing comparable intervals | Maintenance wall s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for r in rows:
    text+=f"| {r['caseId'].upper()} | 80,000 / 80,000 | {r['goodput']:.2f} | {r['p50Ns']/1e6:.6f} | {r['p99Ns']/1e6:.6f} | {r['afterOfferP99Ns']/1e6:.6f} | {r['clearingIntervals']}/{r['fullOfferedCutIntervals']} | {r['maintenanceWallNs']/1e9:.9f} |\n"
text+='\n## Paired observations\n\n'
for a,b in ((rows[0],rows[1]),(rows[2],rows[3])):
    text+=f"{a['caseId'].upper()}→{b['caseId'].upper()}:all-arrival p99 changes{(b['p99Ns']/a['p99Ns']-1)*100:+.2f}%;maintenance wall{(b['maintenanceWallNs']/a['maintenanceWallNs']-1)*100:+.2f}%;after-positive-offer p99{(b['afterOfferP99Ns']/a['afterOfferP99Ns']-1)*100:+.2f}%.\n\n"
text+='''In-window goodput counts confirmations inside the20s arrival window;all80,000 originals reconcile after drain. Comparable full-cut recovery intervals exclude setup and post-arrival drain. Two short observations per artifact do not establish a sustained throughput ceiling. After-positive-offer latency includes client polling,loopback transport,replication and service;it is not isolated network RTT.

## Complete phase accounting

Durations below are seconds summed over each arm. Source-RPC intervals are merged by monotonic union,not summed across concurrent calls. Writer subphases are components of elapsed and must not be added to elapsed again. Copy/queue precede elapsed. Remaining coordinator/observation/encoding costs stay in an explicit residual;no phase is labelled pure hardware or CPU latency.

| Duration,s | C1 | D1 | C2 | D2 |
| --- | ---: | ---: | ---: | ---: |
'''
metrics=[('Maintenance wall',lambda r:r['maintenanceWallNs']),('Source-RPC interval union',lambda r:r['rpcIntervalUnionNs']),
    ('Coordinator archive verification',lambda r:r['coordinatorArchiveVerificationNs']),
    ('Archive writer elapsed',lambda r:r['writerTotals']['archive']['ElapsedNs']),
    ('Archive repeated prevalidation,inside elapsed',lambda r:r['writerTotals']['archive']['PrevalidationNs']),
    ('Archive full readback,inside elapsed',lambda r:r['writerTotals']['archive']['ReadbackNs']),
    ('Event writer elapsed',lambda r:r['writerTotals']['events']['ElapsedNs']),
    ('All payload/receipt forces,inside writer elapsed',lambda r:sum(t['ForceNs']+t['ReceiptForceNs']for t in r['writerTotals'].values())),
    ('All handoff copy/queue,outside elapsed',lambda r:sum(t['CopyNs']+t['QueueWaitNs']for t in r['writerTotals'].values())),
    ('Remaining coordinator/uninstrumented residual',lambda r:r['detailedUninstrumentedResidualNs'])]
for label,fn in metrics:text+='| '+label+' | '+' | '.join(f'{fn(r)/1e9:.9f}'for r in rows)+' |\n'
text+='''
Every original cycle and all corresponding payloads/receipts are audited. C archive receipts retain the legacy handoff fields;D archive cycles explicitly identify the immutable verified handoff,with zero second handoff copy. Event persistence remains unchanged. Exported write/force/readback values match their receipts exactly;all seven serial writer phases fit within elapsed. Every byte length and payload hash agrees. Complete canonical forced readback,payload/receipt forces and ticket completion still precede either destructive ACK. Directory-entry/independent-storage crash durability is not established by file force/readback alone.

## Original evidence and practical limits

'''
for r in rows:
    case=r['caseId'];text+=f"- [{case.upper()} complete native/raw archive](../evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-arm-{case}-native-r1/README.md),privately closed at`{r['privateCommit']}`.\n"
text+='''
The [complete reporting package](../evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/retest-reporting-r1/README.md) retains all analysis sources/results,trade/event checks,per-arrival decomposition,recovery intervals,schema/receipt checks,private proofs,previous/derived index and publication receipts. Each native asset preserves every original closed native TAR,CSV,wire/frame/offer,configuration,identity,source,readiness and lifecycle body. Complete authenticated downloads and member SHA/size/mode/owner/directory verification precede every next case. Candidate-codec checks are not an independent matching oracle or binary cold recovery.

All58 previous runs/24 cohorts remain unchanged;the index appends4 observations in2 common-sampler artifact cohorts,62 runs/26 cohorts. No stable marker or earlier capacity curve is inferred from this fixed-rate retest. HTTP verification is not browser rendering. Separate fresh lineages are not continuous endurance. No5ms p99 SLA,independent physical-host isolation,production certification,HFT endorsement,external/funded trading readiness or100M target is established. Those [production acceptance gates](PRODUCTION_ACCEPTANCE.md) remain separate.
'''
target=R/'docs/VERIFIED_ARCHIVE_HANDOFF_RETEST_RESULTS_V3.md';assert not target.exists();target.write_text(text)
(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
applied=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),indexSha256=sha(R/'evidence/index.json'),reportSha256=sha(target),
    records=62,cohorts=26,all58PriorRunsAnd24CohortsPreserved=True,repeatedFiniteP99AndMaintenanceReduction=criterion)
(O/'APPLIED.json').write_text(json.dumps(applied,indent=2,sort_keys=True)+'\n')
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10)as response:body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body);j=json.loads(body)
http=dict(passed=status==200 and j==json.loads((R/'evidence/index.json').read_text()),status=status,records=len(j['runs']),cohorts=len(j['capacityCohorts']),bodySha256=hashlib.sha256(body).hexdigest(),browserRenderVerified=False)
(O/'HTTP_REVIEW.json').write_text(json.dumps(http,indent=2,sort_keys=True)+'\n');assert http['passed'];print(json.dumps(dict(applied=applied,http=http)))
