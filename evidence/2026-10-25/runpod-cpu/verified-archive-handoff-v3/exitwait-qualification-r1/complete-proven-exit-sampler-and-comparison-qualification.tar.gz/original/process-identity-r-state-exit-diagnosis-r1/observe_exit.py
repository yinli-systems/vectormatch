"""One bounded, owned, natural-exit experiment; no process signaling."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

assert platform.node() == '33ace3d92505'
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == '8d765c71-dbfa-4354-8db0-6c392e701e6f'
foreign = []
for p in Path('/proc').iterdir():
    if p.name.isdigit():
        try:
            name = (p/'comm').read_text().strip()
        except FileNotFoundError:
            continue
        if name in ('java', 'postgres'):
            foreign.append((p.name, name))
assert not foreign, foreign

child_source = '''import mmap,os,sys
m=mmap.mmap(-1,512*1024*1024,flags=mmap.MAP_PRIVATE|mmap.MAP_ANONYMOUS)
m.madvise(mmap.MADV_NOHUGEPAGE)
for i in range(0,len(m),4096):m[i]=1
print("READY",flush=True)
assert sys.stdin.buffer.read(1)==b"x"
os._exit(0)
'''
results=[]
for trial in range(6):
    child=subprocess.Popen([sys.executable,'-c',child_source],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert child.stdout.readline()==b'READY\n'
    fd=os.open('/proc/'+str(child.pid),os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC|os.O_NOFOLLOW)
    def read(name):
        f=os.open(name,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW,dir_fd=fd)
        try:return os.read(f,65536)
        finally:os.close(f)
    def stat(body):
        f=body[body.rfind(b')')+2:].split()
        return dict(state=f[0].decode(),flags=int(f[6]),startTicks=int(f[19]))
    birth=stat(read('stat'))['startTicks']
    child.stdin.write(b'x');child.stdin.flush()
    started=time.monotonic_ns();deadline=started+5_000_000_000;samples=[];count=0;terminal=None
    try:
        while time.monotonic_ns()<deadline:
            try:
                first=stat(read('stat'));argv=read('cmdline');second=stat(read('stat'))
            except (FileNotFoundError,ProcessLookupError):
                terminal='absent';break
            count+=1
            assert first['startTicks']==second['startTicks']==birth
            if not argv or second['state'] in ('Z','X','x'):
                samples.append(dict(elapsedNs=time.monotonic_ns()-started,before=first,after=second,argvBytes=len(argv)))
            if second['state'] in ('Z','X','x'):
                terminal=second['state'];break
        assert terminal is not None
    finally:os.close(fd)
    assert child.wait(timeout=5)==0
    assert child.stderr.read()==b''
    assert not Path('/proc/'+str(child.pid)).exists()
    results.append(dict(trial=trial,pid=child.pid,startTicks=birth,reads=count,terminal=terminal,
                        samples=samples,elapsedNs=time.monotonic_ns()-started,exitCode=child.returncode,strictAbsence=True))
print(json.dumps(dict(passed=True,kernel=platform.release(),memoryBytesPerChild=512*1024*1024,
                     naturalExit=True,signalsSent=0,childSource=child_source,
                     observerSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),trials=results)))
