from pathlib import Path
import sys,json,hashlib,base64,tarfile,io,socket,subprocess,os
c=json.loads(base64.b64decode(sys.argv[1]));root=Path(c['root']);assert root==Path('/opt/vectormatch-cpu/tools/process-identity-exit-wait-controller-proof-r1')and not root.exists()
assert socket.gethostname()=='33ace3d92505'and os.geteuid()==0 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='8d765c71-dbfa-4354-8db0-6c392e701e6f'
body=sys.stdin.buffer.read();assert len(body)<1024**2 and hashlib.sha256(body).hexdigest()==c['bundleSha256'];root.mkdir()
with tarfile.open(fileobj=io.BytesIO(body))as t:
 members=t.getmembers();assert len(members)==len(c['rows'])
 for m in members:
  assert m.isfile()and m.name in c['rows'];data=t.extractfile(m).read();pin=c['rows'][m.name]
  assert len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'];p=root/m.name;p.write_bytes(data);p.chmod(0o644)
sys.path.insert(0,str(root));import cpu_read_window32_abab as controller
b=controller.load_base();b.enable_pidfd()
args=[sys.executable,'-c','import time; time.sleep(30)'];child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
(root/'CHILD_LAUNCH.json').write_text(json.dumps(dict(pid=child.pid,expectedArguments=args))+'\n');identity=None
try:
 identity=b.process_identity(child.pid);assert identity and identity['arguments']==args
 (root/'CHILD_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
 bad=dict(identity,commandSha256='0'*64);rejected=False
 try:b.stop_owned(bad,.1)
 except RuntimeError as failure:
  rejected='Owned PID/startTicks/argv differs; no signal'in str(failure)
 assert rejected and child.poll()is None,'Mismatched identity must never authorize a signal'
 stop=b.stop_owned(identity,5);code=child.wait(timeout=5)
 assert stop['stopped']and stop['signal']=='SIGTERM'and code==-15 and b.process_identity(child.pid)is None
 result=dict(passed=True,pythonVersion=sys.version,actualMatchedIdentity=identity,mismatchedIdentityRejectedWithoutSignal=True,
  originalPidfdSigtermStopPassed=True,strictIdentityAbsentAfterWait=True,childExitCode=code,noForcedKill=True,noJavaSqlOrTradingWorkload=True,
  allInputSourcesUnchanged=all((root/n).stat().st_size==v['bytes']and hashlib.sha256((root/n).read_bytes()).hexdigest()==v['sha256']for n,v in c['rows'].items()),
  ownedWrapperSha256=c['ownedWrapperSha256'],cpuLoaderSha256=c['cpuLoaderSha256'])
 assert result['allInputSourcesUnchanged'];(root/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
finally:
 if child.poll()is None and identity is not None:
  b.stop_owned(identity,5);child.wait(timeout=5)
