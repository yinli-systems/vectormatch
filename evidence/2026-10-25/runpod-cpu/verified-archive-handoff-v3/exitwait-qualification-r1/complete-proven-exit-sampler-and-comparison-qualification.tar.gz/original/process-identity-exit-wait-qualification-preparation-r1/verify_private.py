from pathlib import Path
import ast,datetime,hashlib,json,subprocess,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/exitwait-qualification-r1';O=B/'process-identity-exit-wait-qualification-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo=json.loads(subprocess.check_output(['gh','repo','view','yinli-systems/vectormatch','--json','isPrivate,nameWithOwner']));assert repo['isPrivate']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')and closed['newComparisonExecuted']is False
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(R).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
    if row:
        meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*paths).decode().splitlines()==[blobs[n]for n in paths]
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/complete-proven-exit-sampler-and-comparison-qualification.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256']
members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview']
bridge=json.loads((A/'CONTROLLER_BRIDGE.json').read_text());native=json.loads((A/'OWNED_PIDFD_PROOF.json').read_text());prior=json.loads((A/'INITIAL_CAMPAIGN_PRIVATE_PROOF.json').read_text());ci=json.loads((A/'FORCED_CI8_REVIEW.json').read_text())
assert ci['passed']and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0)and ci['pythonTests']==197 and ci['allTestTasksExecutedWithoutResultCache']
assert prior['passed']and prior['private']and prior['bothNativeAssetsAlreadyFullyDownloadedAndMemberVerified']and prior['originalInvalidQualificationRetained']and prior['campaignComplete']is False
subprocess.run(['git','merge-base','--is-ancestor',prior['commit'],head],check=True)
assert native['passed']and native['mismatchedIdentityRejectedWithoutSignal']and native['originalPidfdSigtermStopPassed']and native['strictIdentityAbsentAfterWait']and native['noForcedKill']
with tarfile.open(restored)as t:
    base='original/process-identity-exit-wait-controller-bridge-preparation-r1/inputs/';original='original/process-identity-controller-original-sources-r1/'
    values={n:t.extractfile(base+n).read()for n in bridge['rows']}
    assert all(len(values[n])==v['bytes']and hashlib.sha256(values[n]).hexdigest()==v['sha256']for n,v in bridge['rows'].items())
    def normalized(body,kind):
        nodes=ast.parse(body).body
        if kind=='owned':nodes=[n for n in nodes if not(isinstance(n,ast.FunctionDef)and n.name=='process_identity')]
        else:nodes=[n for n in nodes if not(isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='BASE_SHA'for x in n.targets))]
        return ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False)
    assert normalized(values['owned_linux_base_8eeb.py'],'owned')==normalized(t.extractfile(original+'owned_linux_base_8eeb.py').read(),'owned')
    assert normalized(values['cpu_read_window32_abab.py'],'cpu')==normalized(t.extractfile(original+'cpu_read_window32_abab.py').read(),'cpu')
    for n in ('idle_attestation.py','owner_poll_attestation.py','shutdown_warning.py','readiness_validation.py'):assert values[n]==t.extractfile(original+n).read()
    source=git('show',ci['sourceCommit']+':scripts/owned_process_identity.py');assert values['owned_process_identity.py']==source
    assert hashlib.sha256(source).hexdigest()==closed['identityReaderSha256']==bridge['identityReaderSha256']
    jdk=json.load(t.extractfile('original/process-identity-ci8-jdk-equivalence-r1/stdout.json'));assert jdk['passed']and jdk['files']==[454,454]
# Verify every nested original CI8 source/compiler/test/log file as well.
with tarfile.open(restored) as outer:
    cp='original/production-ci-attempt-8-collection-r1/'
    manifest=json.load(outer.extractfile(cp+'remote-manifest.json'));seen=set()
    with tarfile.open(fileobj=outer.extractfile(cp+'complete-code-compiled-tests-and-public-logs.tar.gz'),mode='r|gz')as nested:
        for item in nested:
            assert item.isfile() and item.name.startswith('original/');n=item.name[len('original/'):];assert n not in seen;seen.add(n);pin=manifest['originalFiles'][n]
            stream=nested.extractfile(item);h=hashlib.sha256()
            for block in iter(lambda:stream.read(1024**2),b''):h.update(block)
            assert item.size==pin['bytes'] and h.hexdigest()==pin['sha256'] and item.mode==pin['mode'] and item.uid==pin['uid'] and item.gid==pin['gid']
    assert seen==set(manifest['originalFiles']) and len(seen)==786
restored.unlink()
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository=repo['nameWithOwner'],private=True,commit=head,bothRemoteBranchesVerified=True,
    allQualificationGitBlobsVerified=len(paths),restoredWholeScopeArchiveFromActualGitBlob=True,allOriginalScopeMembersVerified=members,
    controllerBridgeQualified=True,allOtherOwnedSignalAndLifecycleAstUnchanged=True,fourAttestationAndReadinessSourcesByteIdentical=True,
    identityReaderSha256=bridge['identityReaderSha256'],ownedWrapperSha256=bridge['ownedWrapperSha256'],cpuLoaderSha256=bridge['cpuLoaderSha256'],controllerInputRows=bridge['rows'],
    identityReaderCiSourceCommit=ci['sourceCommit'],junit=ci['junit'],pythonTests=197,pythonSkipped=0,actualPython38Tests=26,actualPython38Skipped=0,
    actualOwnedPidfdProbePassed=True,allTestTasksActuallyExecuted=True,initialCampaignIncompletePreserved=True,initialInvalidCases=['c2'],initialUnexecutedCases=['d2'],firstRetestIncompletePreserved=True,firstRetestInvalidCases=['d1'],firstRetestUnexecutedCases=['c2','d2'],all786NestedCi8OriginalFilesVerified=len(seen),
    newComparisonPrefix='verified-archive-handoff-exitwait',onlyRegisteredCases=['c1','d1','c2','d2'],fixedPlanComparisonRate=4000,higherLoadPermitted=False,newComparisonExecuted=False,
    codeFingerprints=dict(control='f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca',candidate='79e5a932a4c22a3abe3cf9199938975478aff6c49bccf74b8e729b29dd228e2f'),
    inventorySha256=sha(A/'INVENTORY.json'),closedSha256=sha(A/'CLOSED.json'),sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='controllerInputRows'}))
