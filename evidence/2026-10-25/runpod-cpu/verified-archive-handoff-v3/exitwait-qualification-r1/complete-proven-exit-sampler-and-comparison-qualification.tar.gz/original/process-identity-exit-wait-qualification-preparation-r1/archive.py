from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/verified-archive-handoff-v3/exitwait-qualification-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
bridge=json.loads((B/'process-identity-exit-wait-controller-bridge-preparation-r1/PREPARATION.json').read_text())
native=json.loads((B/'process-identity-exit-wait-controller-native-proof-r1/stdout.json').read_text())
prior=json.loads((B/'verified-archive-handoff-retest-incomplete-reporting-private-proof-r2/PRIVATE_PUSH.json').read_text())
jdk=json.loads((B/'process-identity-ci8-jdk-equivalence-r1/stdout.json').read_text())
assert bridge['passed'] and bridge['all227ActualCi8ApplicationClassesEqualQualifiedCi6'] and bridge['allOtherOwnedSignalAndLifecycleAstUnchanged']
assert native['passed']and native['mismatchedIdentityRejectedWithoutSignal']and native['originalPidfdSigtermStopPassed']and native['noForcedKill']
assert prior['passed']and prior['private']and prior['bothNativeAssetsAlreadyFullyDownloadedAndMemberVerified']and prior['campaignComplete']is False and prior['invalidCases']==['d1']
ci=json.loads((B/'process-identity-exit-wait-forced-correctness-r1/RESULT.json').read_text());assert ci['passed']and ci['allTestTasksExecutedWithoutResultCache']and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0)and ci['pythonTests']==197
assert jdk['passed']and jdk['files']==[454,454]
names=['process-identity-exit-wait-qualification-preparation-r1','process-identity-exit-wait-controller-bridge-preparation-r1',
    'process-identity-controller-original-sources-r1','process-identity-exit-wait-controller-native-proof-r1','process-identity-ci8-jdk-equivalence-r1',
    'process-identity-exit-wait-linux-r1','process-identity-exit-race-reproduction-r1','process-identity-exit-wait-forced-correctness-r1',
    'verified-archive-handoff-retest-incomplete-reporting-private-proof-r2','verified-archive-handoff-qualification-private-proof-r1',
    'writer-phase-timing-linux-metadata-execution-r1','verified-archive-handoff-linux-metadata-execution-r1',
    'dispatch-capacity-scope-tar-preparation-r1']
names.extend(['production-cpu-ci-controller-preparation-r8','production-cpu-ci-environment-r8','production-cpu-ci-registration-r8','production-cpu-ci-dispatch-r8','production-ci-evidence-collection-preparation-r5','production-ci-attempt-8-collection-r1','process-identity-exit-wait-forced-correctness-preparation-r1','process-identity-r-state-exit-diagnosis-r1','verified-archive-handoff-retest-incomplete-reporting-private-proof-r1','verified-archive-handoff-retest-incomplete-reporting-preparation-r2','verified-archive-handoff-incomplete-reporting-private-proof-r1'])
before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-proven-exit-sampler-and-comparison-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
for src,name in [(B/'process-identity-exit-wait-controller-bridge-preparation-r1/PREPARATION.json','CONTROLLER_BRIDGE.json'),
                 (B/'process-identity-exit-wait-controller-native-proof-r1/stdout.json','OWNED_PIDFD_PROOF.json'),
                 (B/'verified-archive-handoff-retest-incomplete-reporting-private-proof-r2/PRIVATE_PUSH.json','INITIAL_CAMPAIGN_PRIVATE_PROOF.json'),
                 (B/'process-identity-exit-wait-forced-correctness-r1/RESULT.json','FORCED_CI8_REVIEW.json')]:shutil.copy2(src,A/name)
for n in ('docs/VERIFIED_ARCHIVE_HANDOFF_EXIT_WAIT_V3.md','docs/PROCESS_IDENTITY_OBSERVATION.md'):
    p=A/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
(A/'README.md').write_text("# Proven-exit sampler qualification\n\nActual CI8 sourcebd936811 passes394 Java/11 PostgreSQL/197 Python tests plus failover/web,all0 skips;all five Java test tasks execute without restored results. All26 focused tests also pass on the actual controller Python3.8,including6 natural512MiB exits. Same-kernel raw observations reproduce18–20ms R/empty/PF_EXITING teardown. The revised sampler waits boundedly for terminal proof;PF_EXITING alone never means absent.\n\nAll227 actual CI8 application classes equal qualified CI6 classes;existing F3/79 artifacts are retained. All454 CI8/benchmark JDK files agree. The bridge changes only process_identity and the loader's base-source hash;all other lifecycle/signal AST and four attestation/readiness bodies remain unchanged. A real owned-child proof rejects a wrong identity without signal and passes the original pidfd SIGTERM/strict-exit path. No forced kill or numeric-PID fallback.\n\nBoth prior campaigns remain incomplete,with original C2 and retest D1 invalid and all never-executed arms preserved. Their private source/raw closures remain verifiable. This package includes complete original CI8 source/compiler/test/log evidence,actual controller tests,diagnosis,bridge/native proof and previous reporting proof/checker failure/corrected checker. A fresh C1/D1/C2/D2 is registered under verified-archive-handoff-exitwait with common source and unchanged4000/s20s setup. No orders execute before whole-Git private qualification. This is not a performance improvement,SLA,100M result or production certification.\n")

inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),
    archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,newComparisonExecuted=False,
    identityReaderSha256=bridge['identityReaderSha256'],ownedWrapperSha256=bridge['ownedWrapperSha256'],cpuLoaderSha256=bridge['cpuLoaderSha256'],higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'],payloadFiles=len(inv['files']))))
