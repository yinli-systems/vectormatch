from pathlib import Path
import importlib.util,json,hashlib,shlex,subprocess,datetime,tarfile,base64
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent;O=B/'process-identity-exit-wait-controller-native-proof-r1';assert not O.exists()
x=json.loads((P/'PREPARATION.json').read_text());assert x['passed'];O.mkdir()
script=(B/'process-identity-controller-native-proof-r1/remote-source.py').read_text().replace('process-identity-controller-proof-r1','process-identity-exit-wait-controller-proof-r1');(O/'remote-source.py').write_text(script)
with tarfile.open(O/'inputs.tar.gz','w:gz')as t:
 for n in x['rows']:t.add(P/'inputs'/n,arcname=n,recursive=False)
c=dict(root='/opt/vectormatch-cpu/tools/process-identity-exit-wait-controller-proof-r1',rows=x['rows'],bundleSha256=hashlib.sha256((O/'inputs.tar.gz').read_bytes()).hexdigest(),ownedWrapperSha256=x['ownedWrapperSha256'],cpuLoaderSha256=x['cpuLoaderSha256'])
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),config=c,sourceSha256=hashlib.sha256(script.encode()).hexdigest(),oneOwnedBenignChildOnly=True),indent=2)+'\n')
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=subprocess.run(m.sshargs()+[shlex.join(['python3','-B','-c',script,base64.b64encode(json.dumps(c).encode()).decode()])],input=(O/'inputs.tar.gz').read_bytes(),capture_output=True,timeout=60)
(O/'stdout.json').write_bytes(r.stdout);(O/'stderr').write_bytes(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0,r.stderr.decode();assert json.loads(r.stdout)['passed'];print(r.stdout.decode())
O=B/'process-identity-ci8-jdk-equivalence-r1';O.mkdir();script=(B/'process-identity-ci7-jdk-equivalence-r1/remote-source.py').read_text().replace('production-correctness-r7','production-correctness-r8');(O/'remote-source.py').write_text(script)
r=m.run(shlex.join(['python3','-B','-c',script]),timeout=45);(O/'stdout.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);assert r.returncode==0,r.stderr;assert json.loads(r.stdout)['passed'];print(r.stdout)
