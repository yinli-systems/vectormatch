from pathlib import Path
import ast,hashlib,json,shutil,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;I=P/'inputs';assert not I.exists()
ci=json.loads((B/'process-identity-exit-wait-forced-correctness-r1/RESULT.json').read_text())
assert ci['passed'] and ci['junit']==dict(tests=394,failures=0,errors=0,skipped=0) and ci['pythonTests']==197 and ci['pythonSkipped']==0
native=json.loads((B/'process-identity-exit-wait-linux-r1/RESULT.json').read_text());assert native['passed'] and native['tests']==26 and native['skipped']==0
S=B/'startup-readiness-controller-preparation-r2';I.mkdir()
names=['cpu_read_window32_abab.py','owned_linux_base_8eeb.py','idle_attestation.py','owner_poll_attestation.py','shutdown_warning.py','readiness_validation.py']
for name in names:shutil.copy2(S/name,I/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I/'owned_linux_base_8eeb.py')=='8eeb10c14d6e5a9aa3895fbb674fc5c59ceac7fd3b15a6e3e11da325f444ab87'
assert sha(I/'cpu_read_window32_abab.py')=='1d15cd2c53e0914c6d1d203cc486c563be3d2cfdaa1fa159ffaa8ffd231b14c4'
C=B/'production-ci-attempt-8-collection-r1'
with tarfile.open(C/'complete-code-compiled-tests-and-public-logs.tar.gz')as t:
    body=t.extractfile('original/source/scripts/owned_process_identity.py').read()
    assert body==(R/'scripts/owned_process_identity.py').read_bytes()
    (I/'owned_process_identity.py').write_bytes(body)
    compiled={m:{}for m in ('core','cluster')}
    for entry in t.getmembers():
        for module in compiled:
            prefix='original/compiled-and-tests/'+module+'/build/classes/java/main/'
            if entry.name.startswith(prefix)and entry.name.endswith('.class'):
                data=t.extractfile(entry).read();compiled[module][entry.name[len(prefix):]]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
assert compiled==json.loads((B/'verified-archive-handoff-artifact-preparation-r1/JAR_INPUTS.json').read_text())['compiledClasses']
readerSha=sha(I/'owned_process_identity.py');original=(I/'owned_linux_base_8eeb.py').read_text()
a=original.index('def process_identity(pid):');z=original.index('\ndef matching_identity(',a)
replacement='''def process_identity(pid):
    reader = globals().get('_qualified_identity_reader')
    if reader is None:
        path = Path(__file__).resolve().with_name('owned_process_identity.py')
        require(not path.is_symlink(), 'Qualified identity reader symlink refused')
        body = path.read_bytes()
        require(len(body) <= 65536 and hashlib.sha256(body).hexdigest() == READER_SHA,
                'Exact CI-qualified process identity source differs')
        namespace = {'__name__': 'qualified_owned_process_identity', '__file__': str(path)}
        exec(compile(body, str(path), 'exec'), namespace)
        reader = namespace['read_identity']
        globals()['_qualified_identity_reader'] = reader
    return reader(pid, PROC)

'''.replace('READER_SHA',repr(readerSha))
updated=original[:a]+replacement+original[z:];(I/'owned_linux_base_8eeb.py').write_text(updated)
def without_identity(s):return ast.dump(ast.Module(body=[n for n in ast.parse(s).body if not(isinstance(n,ast.FunctionDef)and n.name=='process_identity')],type_ignores=[]),include_attributes=False)
assert without_identity(original)==without_identity(updated)
cpu=(I/'cpu_read_window32_abab.py').read_text();newCpu=cpu.replace("BASE_SHA = '8eeb10c14d6e5a9aa3895fbb674fc5c59ceac7fd3b15a6e3e11da325f444ab87'",'BASE_SHA = '+repr(sha(I/'owned_linux_base_8eeb.py')))
assert newCpu!=cpu
def without_base_sha(s):return ast.dump(ast.Module(body=[n for n in ast.parse(s).body if not(isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='BASE_SHA'for x in n.targets))],type_ignores=[]),include_attributes=False)
assert without_base_sha(cpu)==without_base_sha(newCpu);(I/'cpu_read_window32_abab.py').write_text(newCpu)
unchanged={name:sha(I/name)for name in names[2:]};assert all((I/name).read_bytes()==(S/name).read_bytes()for name in unchanged)
rows={p.name:dict(bytes=p.stat().st_size,sha256=sha(p),mode=420)for p in I.iterdir()if p.is_file()}
for p in I.iterdir():p.chmod(0o644)
result=dict(passed=True,ciSourceCommit=ci['sourceCommit'],ciRun=ci['runId'],junit=ci['junit'],pythonTests=197,
    actualPython38TestsPassed=26,actualPython38Skipped=0,identityReaderSha256=readerSha,
    ownedWrapperSha256=sha(I/'owned_linux_base_8eeb.py'),cpuLoaderSha256=sha(I/'cpu_read_window32_abab.py'),
    onlyOwnedIdentityFunctionChanged=True,onlyCpuLoaderBaseHashChanged=True,allOtherOwnedSignalAndLifecycleAstUnchanged=True,
    fourAttestationAndReadinessSourceBodiesByteIdentical=unchanged,all227ActualCi8ApplicationClassesEqualQualifiedCi6=True,rows=rows,
    sourceSha256=sha(Path(__file__)))
(P/'PREPARATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in('rows','fourAttestationAndReadinessSourceBodiesByteIdentical')}))
