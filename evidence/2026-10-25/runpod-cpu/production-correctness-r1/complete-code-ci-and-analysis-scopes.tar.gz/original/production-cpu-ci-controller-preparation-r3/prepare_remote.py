import base64,json,pathlib,os,pwd,tarfile,hashlib,subprocess
c=json.loads(base64.b64decode(__import__('sys').argv[1]));root=pathlib.Path(c['root']);old=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r1');previous=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r2')
assert root==pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r3')and not root.exists()
assert not(previous/'runner/.runner').exists()and not(previous/'runner/.credentials').exists()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
u=pwd.getpwnam('vmci');assert u.pw_uid==999;root.mkdir();(root/'home').mkdir()
for name in ('runner','python'):
 archive=old/(name+'.tar.gz');assert sha(archive)==c[name]['sha256']and archive.stat().st_size==c[name]['bytes'];target=root/name;target.mkdir()
 with tarfile.open(archive)as t:
  for m in t.getmembers():
   path=pathlib.PurePosixPath(m.name);assert not path.is_absolute()and '..'not in path.parts
   assert m.isfile()or m.isdir()or m.issym()or m.islnk()
   if m.issym()or m.islnk():
    link=(target/pathlib.Path(m.name).parent/m.linkname)if m.issym()else(target/m.linkname)
    assert os.path.commonpath([str(target),str(link.resolve())])==str(target)
  t.extractall(target)
git=previous/'tools/git-2.56.0/bin/git';qualified=json.loads((previous/'PREPARED.json').read_text());assert qualified['passed']and sha(git)==qualified['gitExecutableSha256']
(root/'tools').mkdir();(root/'tools/git-2.56.0').symlink_to(previous/'tools/git-2.56.0',target_is_directory=True)
for p in [root,*root.rglob('*')]:os.chown(p,u.pw_uid,u.pw_gid,follow_symlinks=False)
root.chmod(0o750);result=dict(passed=True,freshRunnerWorktree=True,reusedArchivesFullyRehashed=True,gitExecutableSha256=sha(git),gitVersion=subprocess.check_output([str(git),'--version'],text=True).strip(),noRunnerRegistered=True)
(root/'PREPARED.json').write_text(json.dumps(result,indent=2)+'\n');os.chown(root/'PREPARED.json',u.pw_uid,u.pw_gid);print(json.dumps(result))
