plugins { `java-library` }

