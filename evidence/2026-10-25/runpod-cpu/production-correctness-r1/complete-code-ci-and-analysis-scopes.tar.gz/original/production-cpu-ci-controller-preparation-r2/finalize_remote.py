import json,pathlib,subprocess,os,pwd,hashlib
root=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r2');assert not(root/'PREPARED.json').exists()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
git=root/'tools/git-2.56.0/bin/git';r=subprocess.run([str(git),'--version'],capture_output=True,text=True);assert r.returncode==0 and r.stdout.strip()=='git version 2.56.0'
net=subprocess.run(['runuser','-u','vmci','--','env','HOME='+str(root/'home'),str(git),'ls-remote','https://github.com/git/git.git','HEAD'],cwd=root/'home',capture_output=True,text=True,timeout=60);assert net.returncode==0,net.stderr
result=dict(passed=True,gitVersion=r.stdout.strip(),gitExecutableSha256=sha(git),gitSourceSha256=sha(root/'tools/git-source.tar.xz'),
 curlHeaderSourceSha256=sha(root/'tools/curl-source.tar.gz'),gitBuildLogSha256=sha(root/'git-build-c-only.log'),
 initialFailedBuildLogSha256=sha(root/'git-build.log'),upstreamSupportedNoRustBuild=True,publicHttpsRemoteProbe=net.stdout.strip(),
 initialNetworkProbeFailure='Successful build;first ls-remote inherited root-only /root cwd and failed before network;corrected probe uses dedicated user home',
 noSystemPackagesChanged=True,noRunnerRegistered=True,noJavaOrTradingStarted=True)
(root/'PREPARED.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');u=pwd.getpwnam('vmci');os.chown(root/'PREPARED.json',u.pw_uid,u.pw_gid)
print(json.dumps(result))
