import json,pathlib,subprocess,os,pwd,hashlib
root=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r2');assert root.exists()and not(root/'PREPARED.json').exists()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
tools=root/'tools';gitSource=next((tools/'git-source').iterdir());curlSource=next((tools/'curl-source').iterdir());prefix=tools/'git-2.56.0'
assert not prefix.exists()and b'cargo: not found'in(root/'git-build.log').read_bytes()
old=gitSource/'GIT-CFLAGS';assert old.is_file();(root/'initial-failed-build-CFLAGS').write_bytes(old.read_bytes())
options=['prefix='+str(prefix),'NO_RUST=YesPlease','NO_GETTEXT=YesPlease','NO_TCLTK=YesPlease','NO_PERL=YesPlease','NO_PYTHON=YesPlease',
         'CFLAGS=-O2 -I'+str(curlSource/'include'),'CURL_CONFIG=/bin/false','CURL_LIBCURL=-l:libcurl.so.4']
(root/'C_ONLY_BUILD_ARGUMENTS.json').write_text(json.dumps(options,indent=2)+'\n')
with(root/'git-build-c-only.log').open('xb')as log:
 for args in [['make','-j8',*options,'all'],['make',*options,'install']]:
  r=subprocess.run(['runuser','-u','vmci','--','env','HOME='+str(root/'home'),*args],cwd=gitSource,stdout=log,stderr=subprocess.STDOUT,timeout=240);assert r.returncode==0,'Git C-only build failed; preserve complete log'
git=prefix/'bin/git';r=subprocess.run([str(git),'--version'],capture_output=True,text=True);assert r.returncode==0 and r.stdout.strip()=='git version 2.56.0'
net=subprocess.run(['runuser','-u','vmci','--','env','HOME='+str(root/'home'),str(git),'ls-remote','https://github.com/git/git.git','HEAD'],capture_output=True,text=True,timeout=60);assert net.returncode==0,net.stderr
result=dict(passed=True,gitVersion=r.stdout.strip(),gitExecutableSha256=sha(git),gitSourceSha256=sha(tools/'git-source.tar.xz'),
 curlHeaderSourceSha256=sha(tools/'curl-source.tar.gz'),gitBuildLogSha256=sha(root/'git-build-c-only.log'),
 initialFailedBuildLogSha256=sha(root/'git-build.log'),upstreamSupportedNoRustBuild=True,publicHttpsRemoteProbe=net.stdout.strip(),noSystemPackagesChanged=True,noRunnerRegistered=True,noJavaOrTradingStarted=True)
(root/'PREPARED.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');u=pwd.getpwnam('vmci');os.chown(root/'PREPARED.json',u.pw_uid,u.pw_gid)
print(json.dumps(result))
