import base64,json,pathlib,sys,subprocess,os,pwd,tarfile,hashlib,shutil
c=json.loads(base64.b64decode(sys.argv[1]));root=pathlib.Path(c['root']);old=pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r1')
assert root==pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r2')and not root.exists()
assert not(old/'runner/.runner').exists()and not(old/'runner/.credentials').exists()
user=pwd.getpwnam('vmci');assert user.pw_uid==999
root.mkdir();home=root/'home';home.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def extract(archive,target):
 target.mkdir()
 with tarfile.open(archive)as t:
  for m in t.getmembers():
   name=pathlib.PurePosixPath(m.name);assert not name.is_absolute()and '..'not in name.parts
   assert m.isfile()or m.isdir()or m.issym()or m.islnk()
   if m.issym()or m.islnk():
    link=(target/pathlib.Path(m.name).parent/m.linkname)if m.issym()else(target/m.linkname)
    assert os.path.commonpath([str(target),str(link.resolve())])==str(target)
  t.extractall(target)
for name in ('runner','python'):
 archive=old/(name+'.tar.gz');assert sha(archive)==c[name]['sha256']and archive.stat().st_size==c[name]['bytes'];extract(archive,root/name)
tools=root/'tools';tools.mkdir();source=tools/'git-source.tar.xz'
subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','20',c['git']['url'],'-o',str(source)],check=True);assert sha(source)==c['git']['sha256']
headers=tools/'curl-source.tar.gz'
subprocess.run(['curl','-fsSL','--retry','3','--connect-timeout','20',c['curlHeaders']['url'],'-o',str(headers)],check=True);assert sha(headers)==c['curlHeaders']['sha256']and headers.stat().st_size==c['curlHeaders']['bytes']
extract(source,tools/'git-source');extract(headers,tools/'curl-source')
gitSource=next((tools/'git-source').iterdir());curlSource=next((tools/'curl-source').iterdir());prefix=tools/'git-2.56.0'
for p in [root,*root.rglob('*')]:os.chown(p,user.pw_uid,user.pw_gid,follow_symlinks=False)
root.chmod(0o750)
options=['prefix='+str(prefix),'NO_GETTEXT=YesPlease','NO_TCLTK=YesPlease','NO_PERL=YesPlease','NO_PYTHON=YesPlease',
         'CFLAGS=-O2 -I'+str(curlSource/'include'),'CURL_CONFIG=/bin/false','CURL_LIBCURL=-l:libcurl.so.4']
with(root/'git-build.log').open('xb')as log:
 for args in [['make','-j8',*options,'all'],['make',*options,'install']]:
  r=subprocess.run(['runuser','-u','vmci','--','env','HOME='+str(home),*args],cwd=gitSource,stdout=log,stderr=subprocess.STDOUT,timeout=240);assert r.returncode==0,'Git build failed; preserve git-build.log'
git=prefix/'bin/git';r=subprocess.run([str(git),'--version'],capture_output=True,text=True);assert r.returncode==0 and r.stdout.strip()=='git version 2.56.0'
network=subprocess.run(['runuser','-u','vmci','--','env','HOME='+str(home),str(git),'ls-remote','https://github.com/git/git.git','HEAD'],capture_output=True,text=True,timeout=60);assert network.returncode==0,network.stderr
result=dict(passed=True,runnerAndPythonArchivesReusedAfterFullShaVerification=True,pythonVersion=subprocess.check_output([str(root/'python/python/bin/python3'),'--version'],text=True).strip(),
 gitVersion=r.stdout.strip(),gitExecutableSha256=sha(git),gitSourceSha256=sha(source),curlHeaderSourceSha256=sha(headers),gitBuildLogSha256=sha(root/'git-build.log'),
 publicHttpsRemoteProbe=network.stdout.strip(),noSystemPackagesChanged=True,noRunnerRegistered=True,noJavaOrTradingStarted=True)
(root/'PREPARED.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');os.chown(root/'PREPARED.json',user.pw_uid,user.pw_gid)
print(json.dumps(result))
