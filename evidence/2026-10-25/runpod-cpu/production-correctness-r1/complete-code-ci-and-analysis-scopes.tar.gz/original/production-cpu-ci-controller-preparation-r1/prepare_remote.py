import base64, json, os, pathlib, subprocess, sys, tarfile, hashlib, pwd, shutil

c=json.loads(base64.b64decode(sys.argv[1]));root=pathlib.Path(c['root'])
assert root==pathlib.Path('/opt/vectormatch-cpu/ci/production-correctness-r1')
assert c['user']=='vmci' and c['oneJobOnly'] is True and not root.exists()
# Correctness testing may start only after all benchmark JVMs have stopped.
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try: args=(p/'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    assert not args or pathlib.Path(os.fsdecode(args[0])).name not in ('java','postgres'), str(p)
assert shutil.disk_usage('/opt').free>5*1024**3
try:pwd.getpwnam(c['user']);raise AssertionError('dedicated CI user unexpectedly exists')
except KeyError:pass
root.mkdir(parents=True);home=root/'home';home.mkdir()
subprocess.run(['useradd','--system','--user-group','--home-dir',str(home),'--shell','/usr/sbin/nologin',c['user']],check=True)
user=pwd.getpwnam(c['user'])
assets={}
for name in ('runner','python'):
    asset=c[name];archive=root/(name+'.tar.gz')
    subprocess.run(['curl','--fail','--silent','--show-error','--location','--retry','3','--connect-timeout','20',asset['url'],'-o',str(archive)],check=True)
    h=hashlib.sha256()
    with archive.open('rb')as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    assert archive.stat().st_size==asset['bytes'] and h.hexdigest()==asset['sha256']
    target=root/name;target.mkdir()
    with tarfile.open(archive)as t:
        for m in t.getmembers():
            path=pathlib.PurePosixPath(m.name);assert not path.is_absolute()and '..'not in path.parts
            assert m.isfile()or m.isdir()or m.issym()or m.islnk()
            if m.issym()or m.islnk():
                link=(target/pathlib.Path(m.name).parent/m.linkname)if m.issym()else(target/m.linkname)
                assert os.path.commonpath([str(target),str(link.resolve())])==str(target)
        t.extractall(target)
    assets[name]=dict(bytes=archive.stat().st_size,sha256=h.hexdigest())
python=root/'python/python/bin/python3'
r=subprocess.run([str(python),'--version'],capture_output=True,text=True);assert r.returncode==0 and '3.12.15'in r.stdout
(root/'PREPARED.json').write_text(json.dumps(dict(passed=True,assets=assets,pythonVersion=r.stdout.strip(),userUid=user.pw_uid,userGid=user.pw_gid,noRunnerRegistered=True,noBusinessWorkloadLaunched=True),indent=2)+'\n')
for p in [root,*root.rglob('*')]:os.chown(p,user.pw_uid,user.pw_gid,follow_symlinks=False)
root.chmod(0o750)
print((root/'PREPARED.json').read_text())
