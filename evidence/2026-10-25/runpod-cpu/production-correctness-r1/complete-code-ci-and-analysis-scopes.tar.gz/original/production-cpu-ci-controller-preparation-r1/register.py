from pathlib import Path
import importlib.util,json,hashlib,shlex,subprocess,datetime
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent
O=B/'production-cpu-ci-registration-r1';assert not O.exists();O.mkdir()
source=(P/'register_remote.py').read_text();config=json.loads((P/'CONFIG.json').read_text())
assert json.loads((B/'production-cpu-ci-environment-r1/stdout.json').read_text())['passed']
api=subprocess.run(['gh','api','--method','POST','repos/yinli-systems/vectormatch/actions/runners/registration-token'],capture_output=True,text=True)
assert api.returncode==0,'Registration token request failed'
secret=json.loads(api.stdout)['token'];config['registrationToken']=secret
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(source.encode()).hexdigest(),oneAttemptOnly=True,registrationTokenRetained=False),indent=2)+'\n')
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=subprocess.run(m.sshargs()+[shlex.join(['python3','-B','-c',source])],input=json.dumps(config),text=True,capture_output=True,timeout=150)
assert secret not in r.stdout and secret not in r.stderr
(O/'stdout.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n')
assert r.returncode==0,r.stderr;assert json.loads(r.stdout)['passed'];print(r.stdout)
