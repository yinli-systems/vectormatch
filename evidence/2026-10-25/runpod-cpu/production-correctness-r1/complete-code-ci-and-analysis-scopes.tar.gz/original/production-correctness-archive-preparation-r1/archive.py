from pathlib import Path
import json,tarfile,shutil,sys,re,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024'
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=R/'evidence/2026-10-25/runpod-cpu/production-correctness-r1';assert not O.exists()
forced=json.loads((B/'production-correctness-forced-comparison-r2/RESULT.json').read_text());assert forced['passed']and forced['allTestTasksExecutedWithoutResultCache']and forced['junit']==dict(tests=390,failures=0,errors=0,skipped=0)
names=['production-ci-startup-audit-r1','production-code-only-checkout-r1','production-code-only-checkout-r2',
    'production-web-dependency-audit-r1','production-workflow-validation-r1','production-ci-evidence-collection-preparation-r1','production-ci-evidence-collection-preparation-r2',
    'production-correctness-comparison-r1','production-correctness-forced-comparison-r1','production-correctness-forced-comparison-r2','production-correctness-forced-comparison-preparation-r1',
    'writer-phase-timing-local-validation-r1','writer-phase-timing-local-validation-r2','production-correctness-archive-preparation-r1',
    'production-cpu-ci-environment-c-only-r1','production-cpu-ci-environment-finalize-r1']
for n in range(1,6):
    names += [f'production-cpu-ci-controller-preparation-r{n}',f'production-cpu-ci-environment-r{n}',f'production-cpu-ci-registration-r{n}',f'production-cpu-ci-dispatch-r{n}',f'production-ci-attempt-{n}-collection-r1']
names+=['production-cpu-ci-dispatch-r5b']
# The shared-object clone's .git directory is intentionally not collected.
sourceReview=B/'source-only-review-checkout-r1/VERIFICATION.json';assert json.loads(sourceReview.read_text())['passed']
scopes={n:tree(B/n)for n in names};assert sum(sum(p['bytes']for p in v['files'].values())for v in scopes.values())<256*1024**2
# Registration sources contain variable names but never the actual registration/API tokens.
for n,inv in scopes.items():
    for relative in inv['files']:
        p=B/n/relative
        assert p.name not in('.credentials','.credentials_rsaparams','id_ed25519','id_rsa')
        if p.suffix in('.json','.log','.stdout','.stderr','.txt','.py')or p.name in('stdout','stderr'):
            data=p.read_bytes()
            assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY-----',data),'credential-shaped text; stop archival'
O.mkdir(parents=True);archive=O/'complete-code-ci-and-analysis-scopes.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
review=verify(archive,scopes);assert all(tree(B/n)==scopes[n]for n in names)
(O/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(scopes,indent=2,sort_keys=True)+'\n')
shutil.copy2(sourceReview,O/'SOURCE_CHECKOUT_VERIFICATION.json');shutil.copy2(B/'production-correctness-forced-comparison-r2/RESULT.json',O/'FORCED_RESULT.json')
for n in ['README.md','docs/PRODUCTION_ACCEPTANCE.md','docs/PRODUCTION_CORRECTNESS_RESULTS.md','docs/REVIEW_AND_REPRODUCE.md','docs/MAINTENANCE_WRITER_TIMING_V3.md']:
    p=O/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p);assert sha(p)==sha(R/n)
# Preserve the preceding capacity publication's actual direct-Git restoration proof and verifier.
for src,dst in [(B/'dispatch-capacity-repeat-2-reporting-private-proof-r1/PRIVATE_PUSH.json','boundary-repeat-private-publication.json'),(B/'dispatch-capacity-repeat-2-reporting-preparation-r1/verify_private.py','executed-boundary-repeat-private-verifier.py')]:shutil.copy2(src,O/dst)
(O/'README.md').write_text('''# Forced complete Linux correctness evidence

Sourceaed9430d133d86bfe9fc6abe47ede623ef3309b2,actual GitHub CPU run40204254478:390 Java tests/0 failures/0 errors/0 skips,including11 real PostgreSQL tests;171 Linux Python tests/0 skips;three-JVM failover/snapshot/restart and web build/format all passed. All five actual test tasks execute with a fresh Gradle home and --no-build-cache --rerun-tasks. The prior successful cached-result run,three executed failed attempts,the invalid workflow rejected before a CPU job,failed source-extraction/analysis attempts,upstream Git build failures and all fixes remain in the complete scopes.

Each closed CI collection retains every materialized tracked source file,compiled class/resource/JAR,JUnit result body and CI result log,plus whitelisted public runner metadata. Every collected original file is independently streamed and verified against its original SHA/size/mode/owner. No .git authentication state,registration token,job credentials,SSH/API key or worker diagnostic log is collected. New paid resources and hosted billing limits were not changed. The hosted account payment/spending blocker remains distinct from these real self-hosted jobs.

The forced smoke is a fresh57-command/59-event/6-market-event lineage on three local JVMs,sync2;leader-kill to next confirmation is11563.597ms,including client failure/reconnect handling. It does not prove independent physical-host failover or an RTO SLA. A separate current-lockfile npm audit has0 known vulnerabilities,not a security certification. Source sparse-pattern verification materializes340 files/3707864 bytes at the recorded revision,without bulk evidence;it uses local shared Git objects and is not an internet bandwidth measurement.

Maintenance timing adds measured writer prevalidation,hashing,queue/copy and receipt-write/force phases while preserving canonical checks,forced full readback,ACK order and bounds. No performance improvement,production readiness,millisecond trading latency or100M target is established by this package. The prior same-artifact boundary publication's complete direct-Git restoration proof is retained separately alongside its verifier.
''')
inv=tree(O);(O/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(O/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(O/'INVENTORY.json'),compressedArchiveSha256=sha(archive),compressedArchiveBytes=archive.stat().st_size,originalScopeReview=review,sourceCommit=forced['sourceCommit'],runId=forced['runId'],allActualTestTasksExecuted=True,notProductionOrPerformanceCertification=True),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,payloadFiles=len(inv['files']),compressedBytes=archive.stat().st_size,originalFiles=review['originalFiles'],inventorySha256=sha(O/'INVENTORY.json'))))
