from pathlib import Path
import sys,json,subprocess,importlib.util,shlex,hashlib,datetime,tarfile,stat
B=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent
attempt=int(sys.argv[1]);expected={1:(40200139438,'c765671f5990c922d738cb360ceeb8695a21220a'),2:(40201846818,'0f7fa74a09c7a8c6b7f55e99acfd5f222273cc38'),3:(40202202158,'f142508e08d9205c7f0409f78ec5afbf8149fffd'),4:(40203098509,'3ed6be30115e85f6be3399f29f8969322a42eb07')}
run,source=expected[attempt];O=B/f'production-ci-attempt-{attempt}-collection-r1';assert not O.exists();O.mkdir()
job=json.loads(subprocess.check_output(['gh','run','view',str(run),'--json','status,conclusion,headSha,jobs,url']))
assert job['status']=='completed'and job['headSha']==source
(O/'GITHUB_RUN.json').write_text(json.dumps(job,indent=2)+'\n')
with(O/'github-complete-job.log').open('xb')as out:subprocess.run(['gh','run','view',str(run),'--log'],stdout=out,check=True)
c=dict(attempt=attempt,expectedSource=source,githubRun=run,githubConclusion=job['conclusion']);script=(P/'remote_collect.py').read_text()
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(script.encode()).hexdigest(),oneClosedCollection=True,noWorkload=True,config=c),indent=2)+'\n')
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.run(shlex.join(['python3','-B','-c',script,json.dumps(c)]),timeout=180)
(O/'remote-manifest.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode),indent=2)+'\n');assert r.returncode==0,r.stderr
d=json.loads(r.stdout);a=d['archive'];local=O/'complete-code-compiled-tests-and-public-logs.tar.gz'
with local.open('xb')as out,(O/'download.stderr').open('xb')as err:r=subprocess.run(m.sshargs()+[shlex.join(['cat',a['path']])],stdout=out,stderr=err,timeout=180)
assert r.returncode==0 and local.stat().st_size==a['bytes']and hashlib.sha256(local.read_bytes()).hexdigest()==a['sha256']
seen=set()
with tarfile.open(local)as t:
 for item in t:
  assert item.isfile()and item.name.startswith('original/');name=item.name[len('original/'):];assert name not in seen and name in d['originalFiles'];seen.add(name);pin=d['originalFiles'][name];h=hashlib.sha256()
  f=t.extractfile(item)
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
  assert item.size==pin['bytes']and h.hexdigest()==pin['sha256']and stat.S_IMODE(item.mode)==pin['mode']and item.uid==pin['uid']and item.gid==pin['gid']
assert seen==set(d['originalFiles'])
(O/'VERIFIED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),attempt=attempt,sourceCommit=d['sourceCommit'],allOriginalCollectedFilesVerified=len(seen),archiveBytes=a['bytes'],archiveSha256=a['sha256'],githubConclusion=job['conclusion'],noKeyOrCredentialDirectoriesCollected=True),indent=2)+'\n');print(json.dumps(dict(passed=True,attempt=attempt,files=len(seen),archiveBytes=a['bytes'],githubConclusion=job['conclusion'])))
