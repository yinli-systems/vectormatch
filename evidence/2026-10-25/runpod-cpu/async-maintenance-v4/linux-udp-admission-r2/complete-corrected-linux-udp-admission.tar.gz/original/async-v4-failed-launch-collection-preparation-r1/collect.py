from pathlib import Path
import importlib.util,json,subprocess,shlex,hashlib,base64,datetime,sys
P=Path(__file__).resolve().parent;B=P.parent;O=B/'async-v4-failed-launch-complete-collection-r1';assert not O.exists();O.mkdir()
helper=(B/'dispatch-capacity-scope-tar-preparation-r1/scope_tar.py').read_text()
script=r'''from pathlib import Path
import sys,json,base64,tarfile,hashlib
c=json.load(sys.stdin);ns={};exec(compile(base64.b64decode(c['helper']),'qualified-scope-tar','exec'),ns)
base=Path('/opt/vectormatch-cpu/experiments');roots={'failed-native-r1':base/'async-v4-udp-functional-r1','exact-owned-recovery-r1':base/'async-v4-failed-launch-recovery-r1'}
assert json.loads((roots['failed-native-r1']/'FAILED.json').read_text())['passed']is False
assert not(roots['failed-native-r1']/'state/logical-trace-v4.bin').exists()and not(roots['failed-native-r1']/'state/wire-attempts.bin').exists()
assert json.loads((roots['exact-owned-recovery-r1']/'RESULT.json').read_text())['allThreeProcDirectoriesAbsent']
out=Path('/opt/vectormatch-cpu/collections/async-v4-first-failed-native-r1');assert not out.exists();out.mkdir(parents=True)
before={name:ns['tree'](root)for name,root in roots.items()};archive=out/'complete-failed-native-and-owned-recovery.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for name,root in roots.items():t.add(root,arcname='original/'+name)
verified=ns['verify'](archive,before);assert all(ns['tree'](root)==before[name]for name,root in roots.items())
result=dict(passed=True,failedNativeResultNotChanged=True,sourceScopes=before,everyOriginalMemberVerified=verified,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=ns['sha'](archive)),noBusinessTapesCreated=True,allThreeProvenOwnedChildrenCleaned=True)
(out/'MANIFEST.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
'''
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(script.encode()).hexdigest(),scopeTarSourceSha256=hashlib.sha256(helper.encode()).hexdigest(),readOnlyClosedOriginalScopes=True),indent=2)+'\n')
r=m.run(shlex.join(['python3','-B','-c',script]),input=json.dumps(dict(helper=base64.b64encode(helper.encode()).decode())),timeout=120);(O/'remote-manifest.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0,r.stderr
d=json.loads(r.stdout);a=d['archive'];archive=O/'complete-failed-native-and-owned-recovery.tar.gz'
with archive.open('xb')as out,(O/'download.stderr').open('xb')as err:r=subprocess.run(m.sshargs()+[shlex.join(['cat',a['path']])],stdout=out,stderr=err,timeout=120)
assert r.returncode==0 and archive.stat().st_size==a['bytes']and hashlib.sha256(archive.read_bytes()).hexdigest()==a['sha256']
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import verify
review=verify(archive,d['sourceScopes']);assert review==d['everyOriginalMemberVerified']
(O/'VERIFIED.json').write_text(json.dumps(dict(passed=True,archiveBytes=a['bytes'],archiveSha256=a['sha256'],allOriginalMembers=review,failedNativeNotRedeemed=True,noBusinessTapesCreated=True),indent=2)+'\n');print(json.dumps(dict(passed=True,archiveBytes=a['bytes'],originalFiles=review['originalFiles'],logicalBytes=review['logicalBytes'])))
