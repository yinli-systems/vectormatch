import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
public final class VerifyOriginalOwnedBirth {
 static String json(Object value){if(value instanceof Map<?,?> map){var rows=new ArrayList<String>();for(var e:map.entrySet())rows.add(json(e.getKey().toString())+":"+json(e.getValue()));return "{"+String.join(",",rows)+"}";}if(value instanceof Iterable<?> list){var rows=new ArrayList<String>();for(var e:list)rows.add(json(e));return "["+String.join(",",rows)+"]";}if(value instanceof Number||value instanceof Boolean)return value.toString();return "\""+value.toString().replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
 public static void main(String[] args)throws Exception{
  if(args.length!=2)throw new IllegalArgumentException("exact original receipt directory and new output required");var root=Path.of(args[0]);var rows=new ArrayList<Object>();
  for(int node=0;node<3;node++){
   Path receipt=root.resolve("owned-node-"+node+"-g1.txt");var original=new LinkedHashMap<String,String>();for(var line:Files.readAllLines(receipt)){int p=line.indexOf('=');if(p>0)original.put(line.substring(0,p),line.substring(p+1));}
   long pid=Long.parseLong(original.get("pid"));var process=ProcessHandle.of(pid).orElseThrow();if(!process.isAlive())throw new IllegalStateException("original child not live");var info=process.info();var arguments=List.of(info.arguments().orElseThrow());
   String started=info.startInstant().orElseThrow().toString(),command=info.command().orElseThrow();String argumentHash=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(String.join("\u0000",arguments).getBytes(StandardCharsets.UTF_8)));
   if(!started.equals(original.get("started"))||!command.equals(original.get("command"))||!arguments.toString().equals(original.get("arguments"))||!argumentHash.equals(original.get("argumentsSha256")))throw new IllegalStateException("original Java-owned birth/command/arguments differ: no signal");
   rows.add(Map.of("pid",pid,"node",node,"receipt",receipt.toString(),"started",started,"command",command,"arguments",arguments,"argumentsSha256",argumentHash,"sameOriginalJavaProcessHandleBirth",true));
  }
  Files.writeString(Path.of(args[1]),json(Map.of("passed",true,"scope","read-only actual same-JDK ProcessHandle birth equality before qualified pidfd cleanup","nodes",rows))+"\n",StandardOpenOption.CREATE_NEW);
 }
}
