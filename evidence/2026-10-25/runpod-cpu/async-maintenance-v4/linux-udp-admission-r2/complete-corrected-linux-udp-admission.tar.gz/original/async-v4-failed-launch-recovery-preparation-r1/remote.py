from pathlib import Path
import sys,json,base64,hashlib,subprocess,importlib.util,os,socket
c=json.load(sys.stdin);old=Path('/opt/vectormatch-cpu/experiments/async-v4-udp-functional-r1');out=Path('/opt/vectormatch-cpu/experiments/async-v4-failed-launch-recovery-r1');assert socket.gethostname()=='33ace3d92505'and not out.exists()
assert json.loads((old/'FAILED.json').read_text())['passed']is False and not(old/'state/logical-trace-v4.bin').exists()and not(old/'state/wire-attempts.bin').exists()
source=base64.b64decode(c['source']);assert hashlib.sha256(source).hexdigest()==c['sourceSha256']
spec=importlib.util.spec_from_file_location('qualified',old/'owned_linux_base_8eeb.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.enable_pidfd()
records=[];originals={}
for node in range(3):
 p=old/'state'/('owned-node-'+str(node)+'-g1.txt');body=p.read_bytes();originals[str(p)]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest());v=dict(line.split('=',1)for line in body.decode().splitlines()if '='in line);row=m.process_identity(int(v['pid']));assert row is not None and row['pid']in(127792,127802,127811);records.append(row)
out.mkdir(mode=0o700);(out/'classes').mkdir();(out/'VerifyOriginalOwnedBirth.java').write_bytes(source);java=Path('/opt/vectormatch-cpu/tools/jdk-21.0.13+9/bin/java');assert m.sha(java)=='9cad3f2620d3ef2ed10b26f922af7e773d54fdaa05f615d6d6df014f3fec4155'
env=os.environ.copy()
for name in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS']:env.pop(name,None)
for label,args in [('javac',[str(java.with_name('javac')),'-d',str(out/'classes'),str(out/'VerifyOriginalOwnedBirth.java')]),('read-only-java',[str(java),'-Xmx64m','-cp',str(out/'classes'),'VerifyOriginalOwnedBirth',str(old/'state'),str(out/'ACTUAL_JAVA_OWNED_BIRTHS.json')])]:
 with(out/(label+'.stdout')).open('xb')as stdout,(out/(label+'.stderr')).open('xb')as stderr:r=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=40)
 assert r.returncode==0,label
proof=json.loads((out/'ACTUAL_JAVA_OWNED_BIRTHS.json').read_text());assert proof['passed']and len(proof['nodes'])==3
for row in records:assert m.matching_identity(row) is not None
for name,pin in originals.items():assert m.sha(name)==pin['sha256']and Path(name).stat().st_size==pin['bytes']
m.save(out/'BEFORE_SIGNALS.json',dict(passed=True,actualSameJdkOriginalProcessHandleBirths=proof,qualifiedProcBirths=records,originalReceipts=originals,metadataHelperSourceSha256=c['sourceSha256'],noBusinessRpcsOrUnregisteredSignals=True))
cleanup=[]
for row in records:
 result=m.stop_owned(row,10);result['procDirectoryAbsent']=not Path('/proc',str(row['pid'])).exists();cleanup.append(result)
for row in records:assert m.process_identity(row['pid'])is None
m.save(out/'RESULT.json',dict(passed=True,cleanup=cleanup,allThreeOriginalJavaOwnedBirthsVerifiedBeforePidfdSignals=True,allThreeProvenExited=True,allThreeProcDirectoriesAbsent=all(x['procDirectoryAbsent']for x in cleanup),failedNativeScopeRetained=True,noBusinessRpcsOrUnregisteredSignals=True));print((out/'RESULT.json').read_text())
