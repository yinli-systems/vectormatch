from pathlib import Path
import sys,subprocess,shutil,json,struct,hashlib,csv
P=Path(__file__).resolve().parent;B=P.parent;S=B/'async-v4-local-udp-functional-r1/state';O=B/'async-v4-trace-audit-negative-qualification-r1';assert not O.exists();O.mkdir()
def read_records(path):
 body=path.read_bytes();assert body[:8]==struct.pack('>Ii',0x564d5434,1);pos=8;out=[]
 while pos<len(body):
  kind,n,ns,length=struct.unpack_from('>iqqi',body,pos);pos+=24;out.append([kind,n,ns,body[pos:pos+length]]);pos+=length
 assert pos==len(body);return out
def write_records(path,records):path.write_bytes(struct.pack('>Ii',0x564d5434,1)+b''.join(struct.pack('>iqqi',kind,n,ns,len(body))+body for kind,n,ns,body in records))
def fixture(name):
 state=O/name;state.mkdir()
 for n in ['registration.json','logical-trace-v4.bin','wire-attempts.bin','wire-positive-offers.bin','wire-replies.bin','offer-codes.csv']:shutil.copy2(S/n,state/n)
 shutil.copytree(S/'writer',state/'writer');records=read_records(state/'logical-trace-v4.bin')
 for row in records:
  if row[0]==5:
   value=json.loads(row[3]);value['path']=str((state/'writer'/Path(value['path']).name).resolve());value['receiptPath']=value['path']+'.verified.txt';row[3]=json.dumps(value,separators=(',',':')).encode()
 write_records(state/'logical-trace-v4.bin',records);return state,records
def run(state,expected):
 output=O/(state.name+'-audit');args=[sys.executable,str(P/'audit.py'),str(state),str(output)];r=subprocess.run(args,capture_output=True,text=True,timeout=30)
 (output/'COMMAND.json').write_text(json.dumps(dict(arguments=args,expectedPass=expected,exitCode=r.returncode),indent=2)+'\n');(output/'stdout').write_text(r.stdout);(output/'stderr').write_text(r.stderr)
 assert (r.returncode==0)==expected,(state.name,r.stdout,r.stderr);return dict(name=state.name,expectedPass=expected,exitCode=r.returncode)
results=[];base,_=fixture('relocated-valid-original');results.append(run(base,True))
state,rows=fixture('unreleased-read-credit')
for row in rows:
 if row[0]==4:
  value=json.loads(row[3])
  if value['readPhaseGeneration']is not None and value['consumed']:
   value['consumed']=False;row[3]=json.dumps(value).encode();break
write_records(state/'logical-trace-v4.bin',rows);results.append(run(state,False))
state,rows=fixture('self-consistent-five-offer-intent');path=next((state/'writer').glob('*control-intent-v4.bin'));body=bytearray(path.read_bytes());struct.pack_into('>i',body,24,5);path.write_bytes(body);new_hash=hashlib.sha256(body).hexdigest();receipt=Path(str(path)+'.verified.txt');text=receipt.read_text();old_hash=next(line[7:]for line in text.splitlines()if line.startswith('sha256='));receipt.write_text(text.replace(old_hash,new_hash))
for row in rows:
 if row[0]==5:
  value=json.loads(row[3])
  if value['path']==str(path.resolve()):value['sha256']=new_hash;row[3]=json.dumps(value).encode()
write_records(state/'logical-trace-v4.bin',rows);results.append(run(state,False))
state,rows=fixture('missing-positive-original');path=state/'wire-positive-offers.bin';body=path.read_bytes();length=struct.unpack_from('>i',body)[0];path.write_bytes(body[4+length:]);results.append(run(state,False))
state,rows=fixture('business-offer-during-read-lease');when=next(row[2]for row in rows if row[0]==3 and json.loads(row[3]).get('to')=='ARCHIVE_READ')+1
body=(state/'wire-attempts.bin').read_bytes();offset=0;selected=None;ordinal=0
while offset<len(body):
 length=struct.unpack_from('>i',body,offset)[0];wire=body[offset+4:offset+4+length];offset+=4+length;ordinal+=1;pos=6
 for _ in range(2):n=struct.unpack_from('>i',wire,pos)[0];pos+=4+n
 pos+=8
 if wire[pos]in (1,8):selected=ordinal;break
with(state/'offer-codes.csv').open()as f:codes=list(csv.DictReader(f));fields=list(codes[0])
codes[selected-1]['offer_called_monotonic_ns']=str(when);codes[selected-1]['offer_returned_monotonic_ns']=str(when+1)
with(state/'offer-codes.csv').open('w')as f:writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(codes)
results.append(run(state,False))
(O/'RESULT.json').write_text(json.dumps(dict(passed=True,originalsUnchanged=True,validRelocatedOriginalAccepted=True,allFourSemanticOrMissingEvidenceMutationsRejected=True,cases=results),indent=2)+'\n');print(json.dumps(dict(passed=True,cases=results)))
