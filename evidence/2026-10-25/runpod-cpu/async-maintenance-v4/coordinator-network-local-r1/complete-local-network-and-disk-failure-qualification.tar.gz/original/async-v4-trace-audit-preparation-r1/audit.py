from pathlib import Path
import sys,struct,json,csv,collections,hashlib,datetime
state=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]);assert not output.exists();output.mkdir()
class Reader:
 def __init__(self,body):self.body=body;self.offset=0
 def read(self,n):
  assert 0<=n<=len(self.body)-self.offset;v=self.body[self.offset:self.offset+n];self.offset+=n;return v
 def value(self,fmt):return struct.unpack('>'+fmt,self.read(struct.calcsize('>'+fmt)))[0]
 def text(self,limit=128):
  n=self.value('i');assert 0<=n<=limit;return self.read(n).decode('utf-8','strict')
 def end(self):assert self.offset==len(self.body)
def digest(body):return hashlib.sha256(body).hexdigest()
def framed(path,limit):
 body=path.read_bytes();assert len(body)<=64*1024*1024;r=Reader(body);frames=[]
 while r.offset<len(body):
  n=r.value('i');assert 1<=n<=limit;frames.append(r.read(n));assert len(frames)<=20000
 r.end();return frames
def header(body,reply=False):
 r=Reader(body);assert r.value('I')==(0x564d5233 if reply else 0x564d5733)and r.value('H')==3
 scope=(r.text(64),r.text(64));cid=r.value('q');assert cid>0;return r,scope,cid
registration=json.loads((state/'registration.json').read_text());scope=(registration['profile'],registration['lineage'])
trace=Reader((state/'logical-trace-v4.bin').read_bytes());assert trace.value('I')==0x564d5434 and trace.value('i')==1
records=[];requests={};logical_replies={};observations=collections.defaultdict(list);phases=[];receipts=[];last_ns=-1
while trace.offset<len(trace.body):
 kind=trace.value('i');number=trace.value('q');ns=trace.value('q');n=trace.value('i');assert 1<=kind<=5 and number==len(records)+1 and ns>=last_ns and 0<n<=12288;last_ns=ns;body=trace.read(n);records.append((kind,number,ns,body))
 if kind in(1,2):
  r,s,cid=header(body,kind==2);assert s==scope
  if kind==1:assert cid not in requests;requests[cid]=dict(body=body,ns=ns,operation=r.value('B'))
  else:assert cid in requests and cid not in logical_replies;logical_replies[cid]=body
 elif kind==3:
  value=json.loads(body)
  if 'from'in value:phases.append((ns,value));assert not value['readBankOpen']or value['to']in ('ARCHIVE_READ','EVENT_READ')
  else:assert value['schema']=='retention-async-maintenance-v4-1'
 elif kind==4:
  value=json.loads(body);assert value['correlationId']in requests;assert value['wireSha256']==digest(requests[value['correlationId']]['body']);observations[value['correlationId']].append((ns,value))
 else:receipts.append((ns,json.loads(body)))
assert set(requests)==set(logical_replies) and phases[0][1]['from']=='INITIALIZING'and phases[-1][1]['to']=='IDLE'
retained=set();peak=0;generations=set()
for kind,number,ns,body in records:
 if kind!=4:continue
 value=json.loads(body);generation=value['readPhaseGeneration'];cid=value['correlationId']
 if generation is None:continue
 generations.add(generation)
 if value['consumed']:assert cid in retained;retained.remove(cid)
 elif cid not in retained:retained.add(cid)
 peak=max(peak,len(retained));assert len(retained)<=32
assert not retained and peak>0
attempts=framed(state/'wire-attempts.bin',4096);positives=framed(state/'wire-positive-offers.bin',4096);physical_replies=framed(state/'wire-replies.bin',8192)
with(state/'offer-codes.csv').open()as f:codes=list(csv.DictReader(f))
assert len(codes)==len(attempts);expected_positive=[];originals={};calls=collections.defaultdict(list);positive_counts=collections.Counter();forbidden={'INITIALIZING','PREPARE_WAIT','ARCHIVE_READ','EVENT_READ','ARCHIVE_INTENT','ARCHIVE_ACK','EVENT_INTENT','EVENT_ACK'}
for ordinal,(body,row)in enumerate(zip(attempts,codes),1):
 assert int(row['attempt'])==ordinal;called=int(row['offer_called_monotonic_ns']);returned=int(row['offer_returned_monotonic_ns']);assert returned>=called
 r,s,cid=header(body);assert s==scope;operation=r.value('B');assert cid not in originals or originals[cid]==body;originals[cid]=body;calls[cid].append(called)
 if int(row['original_code'])>=0:expected_positive.append(body);positive_counts[cid]+=1
 if operation in(1,8):
  phase='INITIALIZING'
  for timestamp,value in phases:
   if timestamp>called:break
   phase=value['to']
  assert phase not in forbidden,('business offer inside exclusive phase',phase,cid)
assert expected_positive==positives
for cid,value in requests.items():assert originals[cid]==value['body']and 1<=positive_counts[cid]<=4
physical_by_cid=collections.defaultdict(list)
for body in physical_replies:
 r,s,cid=header(body,True);assert s==scope and cid in originals;physical_by_cid[cid].append(body)
for cid,body in logical_replies.items():assert body in physical_by_cid[cid]
for cid,values in observations.items():
 deadline=values[0][1]['absoluteOfferDeadlineNs'];assert all(value['absoluteOfferDeadlineNs']==deadline and value['possibleOffers']<=4 for _,value in values)
receipt_by_path={};events=[];input_pins={}
for timestamp,value in receipts:
 path=Path(value['path']);assert path.parent==state/'writer'and not path.is_symlink();body=path.read_bytes();assert len(body)==value['bytes']and digest(body)==value['sha256']
 receipt=Path(value['receiptPath']);assert receipt==path.with_name(path.name+'.verified.txt');text=receipt.read_text();assert 'forceTrueCompleted=true\n'in text and 'fullReadbackVerified=true\n'in text and 'sha256='+digest(body)+'\n'in text
 assert path not in receipt_by_path;receipt_by_path[path]=(timestamp,value,body)
 if value['kind']=='events':
  for frame in framed(path,8192):
   r,s,cid=header(frame,True);assert s==scope
   counters=[r.value('q')for _ in range(7)];r.text(64);assert r.text(128)==''and r.value('B')==2
   exported=r.value('q');last=r.value('q');count=r.value('i');assert 1<=count<=32
   for _ in range(count):
    event=dict(eventSeq=r.value('q'),marketSeq=r.value('q'),type=r.value('B'),account=r.value('q'),order=r.value('q'),maker=r.value('q'),taker=r.value('q'),side=r.value('B'),price=r.value('q'),quantity=r.value('q'),detail=r.text(128));events.append(event)
   r.end()
commits=acks=0;previous_chain=None;through=0
for cid,request in requests.items():
 if request['operation']not in(2,3):continue
 wire=request['body'];matches=[]
 for path,(timestamp,value,body)in receipt_by_path.items():
  if value['kind']not in('archive-control-intent','event-control-intent'):continue
  r=Reader(body);assert r.value('I')==0x564d4934 and r.value('i')==1;reserved=r.value('q');deadline=r.value('q');assert r.value('i')==4;n=r.value('i');original=r.read(n);r.end()
  if original==wire:
   assert timestamp<min(calls[cid]);assert 0<deadline-reserved<=120000000000;assert deadline==observations[cid][0][1]['absoluteOfferDeadlineNs'];matches.append((path,timestamp))
 assert len(matches)==1
 r,s,_=header(wire);tag=r.value('B');producer=r.text(48);sequence=r.value('q')
 if tag==2:
  commits+=1;assert producer=='archive'and sequence==commits
  ack_scope=(r.text(64),r.text(64));first=r.value('q');last=r.value('q');previous=r.text(64);chain=r.text(64);payload=r.text(64);r.end();assert ack_scope[1]==scope[1]and first==through+1
  if previous_chain is not None:assert previous==previous_chain
  previous_chain=chain;through=last
  archives=[(time,value)for time,value,body in receipt_by_path.values()if value['kind']=='archive'and value['sha256']==payload];assert len(archives)==1 and archives[0][0]<min(calls[cid])
  prefix=str(4*(commits-1)+2).zfill(4)+'-events.bin';assert receipt_by_path[state/'writer'/prefix][0]<min(calls[cid])
 else:acks+=1;assert producer=='projector'and sequence==acks;r.value('q');r.end()
assert commits==acks==3 and through==1003 and len(receipts)==12 and len(events)==2003
assert [e['eventSeq']for e in events]==list(range(1,2004));assert [e['marketSeq']for e in events if e['marketSeq']]>list()and [e['marketSeq']for e in events if e['marketSeq']]==list(range(1,2002))
counts=collections.Counter(e['type']for e in events);assert counts=={0:2,1:1001,2:1000}
trades=[e for e in events if e['type']==2];assert all(e['account']==2 and e['maker']==1 and e['taker']==e['order']and e['side']==0 and e['price']==10 and e['quantity']==1 for e in trades)
assert {e['taker']for e in trades}==set(range(2,1002))
for p in [state/'logical-trace-v4.bin',state/'wire-attempts.bin',state/'wire-positive-offers.bin',state/'wire-replies.bin',state/'offer-codes.csv',*sorted((state/'writer').glob('*'))]:input_pins[p.name]=dict(bytes=p.stat().st_size,sha256=digest(p.read_bytes()))
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=digest(Path(__file__).read_bytes()),scope='Independent Python V4 trace/physical-offer/event/receipt audit;not a second matching algorithm or storage durability certification',logicalRpcs=len(requests),physicalOffers=len(attempts),positiveOffers=len(positives),physicalReplies=len(physical_replies),maximumRetainedReadCredits=peak,readGenerations=len(generations),allReadCreditsConsumed=True,allOriginalDeadlinesUnchanged=True,allDestructiveOriginalIntentsAndBothPrefixReceiptsPredateOffers=True,archiveCommitIdentities=commits,eventAckIdentities=acks,throughBusinessSeq=through,eventCounts=dict(counts),uniqueOneUnitTrades=len(trades),notional=sum(e['price']*e['quantity']for e in trades),inputs=input_pins)
(output/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='inputs'}))
