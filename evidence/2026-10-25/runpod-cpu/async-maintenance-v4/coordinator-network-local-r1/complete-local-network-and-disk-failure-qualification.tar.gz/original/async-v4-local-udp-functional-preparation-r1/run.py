from pathlib import Path
import os,subprocess,json,datetime,hashlib
B=Path(__file__).resolve().parent.parent;R=B.parents[2];W=B/'async-maintenance-v4-worktree';O=B/'async-v4-local-udp-functional-r1';assert not O.exists();O.mkdir()
source=W/'cluster/src/main/java/io/vectormatch/cluster/RetentionAsyncAeronSmokeV4.java';args=[str(W/'gradlew'),'--no-daemon',':cluster:asyncMaintenanceSmokeV4','-PasyncV4Root='+str(O/'state')]
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),arguments=args,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),localMacLoopbackThreeJvmOnly=True,independentHosts=False,capacityClaim=False,newStateOnly=True),indent=2)+'\n')
env=os.environ.copy();env['JAVA_HOME']=str(R/'.tools/jdk');env['GRADLE_USER_HOME']=str(R/'.tools/gradle-user-home')
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:result=subprocess.run(args,cwd=W,env=env,stdout=out,stderr=err,timeout=300)
(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=result.returncode))+'\n');assert result.returncode==0
completion=json.loads((O/'state/completion.json').read_text());assert completion['passed']and completion['allOwnedStopped'];assert hashlib.sha256(source.read_bytes()).hexdigest()==json.loads((O/'REGISTRATION.json').read_text())['sourceSha256']
print(json.dumps(dict(passed=True,completion=completion,result=json.loads((O/'state/result.json').read_text()))))
