from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';P=Path(__file__).resolve().parent;A=W/'evidence/2026-10-25/runpod-cpu/async-maintenance-v4/maintenance-reservation-local-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=B/'async-maintenance-reservation-local-tests-r1';result=json.loads((O/'RESULT.json').read_text());assert result['passed']and result['junit']==dict(tests=46,failures=0,errors=0,skipped=0)
names=[P.name,O.name,'dispatch-capacity-scope-tar-preparation-r1'];before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-maintenance-reservation-local-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(O/'RESULT.json',A/'RESULT.json');p=A/'published/docs/ASYNC_MAINTENANCE_V4.md';p.parent.mkdir(parents=True);shutil.copy2(W/'docs/ASYNC_MAINTENANCE_V4.md',p)
(A/'README.md').write_text('''# Explicit serial maintenance reservation:local qualification

Complete actual forced local Mac sources,compiled classes,commands,logs and JUnit:46 tests,zero failure/error/skip. The opt-in reservation stays unofferable before explicit arm by its original caller. Repeated reservation does not renew its original correlation/deadline,legacy automatic admission cannot silently switch its mode,expired unarmed intents preserve original evidence without offering,and unarmed intents do not force a1ns owner park loop. Existing owner/read-bank and asynchronous file/preparation/pipeline tests remain included.

Default legacy automatic submission remains available. This admission primitive does not itself persist an ACK intent,issue an ACK,integrate the V4 network coordinator,qualify Linux/deployment or prove a performance gain. Actual inputs/compiled/test/result bodies are preserved in the complete scope TAR. The current immutable-batch comparison uses none of this V4 code.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,junit=result['junit'],localMacOnly=True,noDeploymentOrPerformanceClaim=True),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
