from pathlib import Path
import json,tarfile,hashlib,re,struct,csv,io,collections,datetime
P=Path(__file__).resolve().parent;B=P.parent;R=B.parents[2];O=B/'async-v4-linux-udp-reporting-r1';assert not O.exists();O.mkdir()
collection=B/'async-v4-linux-udp-complete-collection-r1';manifest=json.loads((collection/'remote-manifest.json').read_text());verified=json.loads((collection/'VERIFIED.json').read_text());assert verified['passed']and verified['allOriginalMembers']['originalFiles']==116
archive=collection/'complete-linux-udp-functional-and-independent-audit.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==verified['archiveSha256']
root='original/linux-udp-functional-r2/';wanted={'SUCCESS.json','STAGED.json','SOURCE_FREEZE.json','state/registration.json','state/result.json','state/completion.json','state/network-replay.json','state/coordinator-final.json','state/held-original-file-business-progress.json','state/canonical-final-combined.bin','state/logical-trace-v4.bin','state/wire-attempts.bin','state/offer-codes.csv'}
for node in range(3):
 for gen in(1,2):wanted.update({'state/node-%d-g%d.log'%(node,gen),'state/owned-node-%d-g%d.txt'%(node,gen)})
data={};observed={};audit=None
with tarfile.open(archive,'r|gz')as t:
 for member in t:
  if not member.isfile():continue
  if member.name.startswith(root):
   name=member.name[len(root):]
   if name in wanted:data[name]=t.extractfile(member).read()
   elif re.fullmatch(r'owned-observed-[0-9]+-[0-9]+\.json',name):
    row=json.load(t.extractfile(member));observed[row['pid']]=row
  elif member.name=='original/independent-audit-r1/RESULT.json':audit=json.load(t.extractfile(member))
assert set(data)==wanted and len(observed)==6 and audit['passed']and audit['uniqueOneUnitTrades']==1000
j=lambda name:json.loads(data[name]);success=j('SUCCESS.json');native=j('state/result.json');registration=j('state/registration.json');replay=j('state/network-replay.json');final=native['finalCombinedSha256']
assert success['passed']and success['allOwnedJavaStrictlyAbsent']and j('STAGED.json')['remoteContractTests']==9
assert replay['finalCombinedSha256']==final and hashlib.sha256(data['state/canonical-final-combined.bin']).hexdigest()==final
assert replay['businessSeq']==1003 and replay['eventSeq']==2003 and replay['marketSeq']==2001 and replay['loadOrders']==1000
members='|'.join(str(n)+','+','.join('127.0.0.1:'+str(registration['ports']+n*100+offset)for offset in[2,3,4,5,1])for n in range(3));genesis=set();logs=[]
for node in range(3):
 for gen in(1,2):
  key='state/node-%d-g%d.log'%(node,gen);body=data[key];lines=body.decode('utf-8','strict').splitlines();assert body.endswith(b'\n')
  receipt=dict(line.split('=',1)for line in data['state/owned-node-%d-g%d.txt'%(node,gen)].decode().splitlines()if '='in line);pid=int(receipt['pid']);row=observed[pid];assert int(row['member'])==node
  assert hashlib.sha256('\0'.join(row['arguments'][1:]).encode()).hexdigest()==receipt['argumentsSha256']
  ready='VECTOR_V3_NODE_READY node=%d pid=%d profile=%s lineage=%s code=%s members=%s sync=2 mtu=1248 preparedArchiveCacheEnabled=true'%(node,pid,registration['profile'],registration['lineage'],registration['code'],members);assert ready in lines
  if gen==1:
   pattern='VECTOR_V3_SERVICE_READY profile='+registration['profile']+' lineage='+registration['lineage']+' restored=false hash='
   service=next(line for line in lines if line.startswith(pattern));h=service[len(pattern):];assert re.fullmatch('[0-9a-f]{64}',h);genesis.add(h)
   snapshot='VECTOR_V3_SNAPSHOT_WRITTEN profile=%s lineage=%s hash=%s bytes=%d'%(registration['profile'],registration['lineage'],final,len(data['state/canonical-final-combined.bin']));expected=[ready,service]+(['VECTOR_V3_ROLE role=LEADER']if node==0 else[])+[snapshot]
  else:expected=[ready,'VECTOR_V3_SERVICE_READY profile=%s lineage=%s restored=true hash=%s'%(registration['profile'],registration['lineage'],final)]+(['VECTOR_V3_ROLE role=LEADER']if node==0 else[])
  assert lines==expected,(key,lines);logs.append(dict(node=node,generation=gen,pid=pid,allLinesClassified=True,noWarningsOrErrorMarkers=True,sha256=hashlib.sha256(body).hexdigest()))
assert len(genesis)==1
trace=data['state/logical-trace-v4.bin'];assert trace[:8]==struct.pack('>Ii',0x564d5434,1);pos=8;phases=[]
while pos<len(trace):
 kind,ordinal,ns,length=struct.unpack_from('>iqqi',trace,pos);pos+=24;body=trace[pos:pos+length];pos+=length
 if kind==3:
  value=json.loads(body)
  if 'to'in value:phases.append((ns,value['to']))
start=next(ns for ns,phase in phases if phase=='FILE_WAIT');end=next(ns for ns,phase in phases if phase=='ACK_DRAIN'and ns>start)
attempts=[];body=data['state/wire-attempts.bin'];pos=0
while pos<len(body):n=struct.unpack_from('>i',body,pos)[0];attempts.append(body[pos+4:pos+4+n]);pos+=4+n
codes=list(csv.DictReader(io.StringIO(data['state/offer-codes.csv'].decode())));assert len(codes)==len(attempts)
inside={}
for wire,code in zip(attempts,codes):
 if int(code['original_code'])<0 or not start<=int(code['offer_called_monotonic_ns'])<end:continue
 p=6
 for _ in range(2):n=struct.unpack_from('>i',wire,p)[0];p+=4+n
 cid=struct.unpack_from('>q',wire,p)[0];p+=8;operation=wire[p];p+=1
 if operation==8:inside[cid]=struct.unpack_from('>i',wire,p)[0]
 elif operation==1:inside[cid]=1
assert sum(inside.values())==128 and j('state/held-original-file-business-progress.json')['archiveReceiptStillAbsent']
index=json.loads((R/'evidence/index.json').read_text());assert len(index['runs'])==72 and len(index['capacityCohorts'])==32
(O/'index-before.json').write_text(json.dumps(index,indent=2)+'\n')
record=dict(id='cpu-async-maintenance-v4-functional-r2',label='Asynchronous maintenance V4 · Linux UDP correctness',scope='1003 business commands;1000 unique one-unit trades;three archive cuts',model='One prepaid CPU host;three real JVMs;loopback UDP;leader0;sync2',commands=1003,trades=1000,unknown=0,correctnessPassed=True,timestamp=json.loads((B/'async-v4-linux-udp-launch-r2/REGISTRATION.json').read_text())['atUTC'],durability='Both forced/full-readback prefix receipts and original control intent precede destructive ACK;all three snapshot/cold-restore hashes match',artifactPath='evidence/2026-10-25/runpod-cpu/async-maintenance-v4/linux-udp-functional-r2/README.md',limitations=['Functional fixture with an intentional original-file gate;throughput and p99 are not measured.','No independent physical hosts/storage durability,client continuation after cold restore,100M continuity,production certification or funded external trading.','First controller attempt remains failed and separately archived;sourceb6a53eeb/artifactc6fc2e18;422 Java/197 Python Linux correctness qualification.'])
assert not any(row['id']==record['id']for row in index['runs']);index['runs'].append(record);(O/'index-derived.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=success['sourceCommit'],artifactFingerprint=success['artifactFingerprint'],profileFingerprint=registration['profile'],lineage=registration['lineage'],finalCombinedSha256=final,businessCommands=1003,uniqueOneUnitTrades=1000,acceptedPlaces=1001,events=2003,marketEvents=2001,archiveCuts=[512,640,1003],logicalRpcs=audit['logicalRpcs'],physicalOffers=audit['physicalOffers'],positiveOffers=audit['positiveOffers'],physicalReplies=audit['physicalReplies'],maximumRetainedReadCredits=audit['maximumRetainedReadCredits'],readGenerations=audit['readGenerations'],allSixActualLogsStrictlyClassified=logs,allSixActualNodeLifetimesAndParentStrictlyAbsent=True,independentRawPositiveBusinessCommandsInsideFirstFileWait=sum(inside.values()),all72PriorRunsAnd32CapacityCohortsPreserved=True,records=73,capacityCohorts=32,noCapacityOrP99Claim=True,originalCollectionArchiveSha256=verified['archiveSha256'],originalCollectionBytes=verified['archiveBytes'],originalFiles=116)
(O/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='allSixActualLogsStrictlyClassified'}))
