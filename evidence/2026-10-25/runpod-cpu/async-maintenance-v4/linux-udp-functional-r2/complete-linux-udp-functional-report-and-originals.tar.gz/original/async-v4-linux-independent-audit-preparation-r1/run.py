from pathlib import Path
import importlib.util,hashlib,json,base64,shlex,datetime
P=Path(__file__).resolve().parent;B=P.parent;O=B/'async-v4-linux-independent-audit-r1';assert not O.exists();O.mkdir()
source=(B/'async-v4-trace-audit-preparation-r1/audit.py').read_bytes();assert hashlib.sha256(source).hexdigest()=='3f35639a82dc04c1070593b5478b1a5f6a47d9d3e221353bf8a8781409a24756'
script=r'''from pathlib import Path
import sys,base64,json,hashlib,subprocess
c=json.load(sys.stdin);state=Path('/opt/vectormatch-cpu/experiments/async-v4-udp-functional-r2');assert json.loads((state/'SUCCESS.json').read_text())['passed']
assert json.loads((state/'state/completion.json').read_text())['passed']
source=base64.b64decode(c['source']);assert hashlib.sha256(source).hexdigest()==c['sha256'];root=Path('/opt/vectormatch-cpu/tools/async-v4-independent-audit-r1');assert not root.exists();root.mkdir(mode=0o700)
p=root/'audit.py';p.write_bytes(source);out=Path('/opt/vectormatch-cpu/collections/async-v4-udp-r2-independent-audit-r1');assert not out.exists()
with(root/'stdout').open('xb')as stdout,(root/'stderr').open('xb')as stderr:r=subprocess.run([sys.executable,'-B',str(p),str(state/'state'),str(out)],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60)
assert r.returncode==0,(root/'stderr').read_text();result=json.loads((out/'RESULT.json').read_text());assert result['passed']and result['sourceSha256']==c['sha256']
print(json.dumps(result))
'''
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(source).hexdigest(),remoteSourceSha256=hashlib.sha256(script.encode()).hexdigest(),readOnlyNativeInputs=True,noJavaOrBusinessStarted=True),indent=2)+'\n')
r=m.run(shlex.join(['python3','-B','-c',script]),input=json.dumps(dict(source=base64.b64encode(source).decode(),sha256=hashlib.sha256(source).hexdigest())),timeout=90);(O/'RESULT.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0,r.stderr;d=json.loads(r.stdout);print(json.dumps({k:v for k,v in d.items()if k!='inputs'}))
