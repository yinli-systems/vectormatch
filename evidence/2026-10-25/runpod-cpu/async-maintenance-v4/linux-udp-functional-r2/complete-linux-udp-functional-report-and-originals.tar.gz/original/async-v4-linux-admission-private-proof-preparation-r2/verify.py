from pathlib import Path
import sys,json,subprocess,tarfile,hashlib,datetime,stat
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';A=W/'evidence/2026-10-25/runpod-cpu/async-maintenance-v4/linux-udp-admission-r2';O=B/'async-v4-linux-admission-private-proof-r2';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/async-maintenance-v4').decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
assert git('diff','--name-only','b6a53eeb812877cfb6cabdf01cfeb4548de30502',head,'--','core/src/main','cluster/src/main','cluster/build.gradle.kts')==b''
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A);assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')and closed['contractTests']==9
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix();paths=sorted(prefix+'/'+n for n in actual['files']);blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
assert set(blobs)==set(paths)and git('hash-object','--',*[str(W/n)for n in paths]).decode().splitlines()==[blobs[n]for n in paths]
assert git('show',head+':docs/ASYNC_MAINTENANCE_V4.md')==(A/'published/docs/ASYNC_MAINTENANCE_V4.md').read_bytes()
O.mkdir();restored=O/'actual-new-git.tar.gz'
with restored.open('xb')as f:subprocess.run(['git','-C',str(W),'cat-file','blob',head+':'+prefix+'/complete-corrected-linux-udp-admission.tar.gz'],stdout=f,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];review=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert review==closed['scopeReview']
with tarfile.open(restored)as t:
 stem='original/async-v4-failed-launch-complete-collection-r1/';manifest=json.load(t.extractfile(stem+'remote-manifest.json'));nested=O/'actual-failed-native-and-recovery.tar.gz';nested.write_bytes(t.extractfile(stem+'complete-failed-native-and-owned-recovery.tar.gz').read())
 freeze=json.load(t.extractfile('original/async-v4-linux-udp-controller-preparation-r2/SOURCE_FREEZE.json'))
 for name,pin in freeze['files'].items():
  body=t.extractfile('original/async-v4-linux-udp-controller-preparation-r2/inputs/'+name).read();assert len(body)==pin['bytes']and hashlib.sha256(body).hexdigest()==pin['sha256']
assert nested.stat().st_size==manifest['archive']['bytes']and sha(nested)==manifest['archive']['sha256'];native=verify(nested,manifest['sourceScopes']);assert native==manifest['everyOriginalMemberVerified']and native['originalFiles']==56
previous='6021d111cb94fe0e9c9ae145ac6bf0f316198b73';old='evidence/2026-10-25/runpod-cpu/async-maintenance-v4/linux-udp-admission-r1';oldclosed=json.loads(git('show',previous+':'+old+'/CLOSED.json'));oldinv=json.loads(git('show',previous+':'+old+'/ORIGINAL_SCOPE_INVENTORIES.json'));oldtar=O/'actual-prior-complete-linux-admission.tar.gz'
with oldtar.open('xb')as f:subprocess.run(['git','-C',str(W),'cat-file','blob',previous+':'+old+'/complete-linux-udp-admission-qualification.tar.gz'],stdout=f,check=True)
assert oldtar.stat().st_size==oldclosed['archiveBytes']and sha(oldtar)==oldclosed['archiveSha256'];prior=verify(oldtar,oldinv);assert prior==oldclosed['scopeReview']
with tarfile.open(oldtar)as t:
 stem='original/production-ci-attempt-13-collection-r1/';ci_manifest=json.load(t.extractfile(stem+'remote-manifest.json'));ci=O/'actual-prior-ci13.tar.gz';ci.write_bytes(t.extractfile(stem+'complete-code-compiled-tests-and-public-logs.tar.gz').read())
assert sha(ci)==ci_manifest['archive']['sha256'];seen=set()
with tarfile.open(ci)as t:
 for member in t:
  assert member.isfile()and member.name.startswith('original/');name=member.name[len('original/'):];assert name not in seen;seen.add(name);pin=ci_manifest['originalFiles'][name];body=t.extractfile(member).read()
  assert member.size==pin['bytes']and hashlib.sha256(body).hexdigest()==pin['sha256']and stat.S_IMODE(member.mode)==pin['mode']and member.uid==pin['uid']and member.gid==pin['gid']
assert seen==set(ci_manifest['originalFiles'])and len(seen)==824 and ci_manifest['sourceCommit']=='b6a53eeb812877cfb6cabdf01cfeb4548de30502'and ci_manifest['githubConclusion']=='success'
for p in [restored,nested,oldtar,ci]:p.unlink()
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository='yinli-systems/vectormatch',branch='codex/async-maintenance-v4',commit=head,qualifiedSource=ci_manifest['sourceCommit'],allNewGitMetadataBlobsVerified=len(paths),wholeActualNewGitTarRestored=True,everyNewOriginalMemberVerified=review,all56FailedNativeAndExactRecoveryOriginalMembersVerified=native,priorCompleteLinuxGitAdmissionRestoredAndVerified=previous,all824ActualPriorCiOriginalMembersVerified=True,applicationJavaSourcesAndBuildUnchangedFromQualifiedSource=True,contractTests=9,allEightCorrectedFrozenInputBodiesVerified=len(freeze['files'])==8,correctedNativeAttemptNotYetExecuted=True,noPerformanceOrProductionClaim=True,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
