package io.vectormatch.cluster;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;
import io.vectormatch.core.MatchingEngine;
import io.vectormatch.core.RetentionEngineV3;
public final class AsyncV4DistributionObservation {
 public static void main(String[] args)throws Exception{
  var out=new LinkedHashMap<String,Object>();out.put("noDriverOrClusterStarted",true);out.put("performanceEvidence",false);
  out.put("sourceCommit","b6a53eeb812877cfb6cabdf01cfeb4548de30502");out.put("actualCodeFingerprint",RetentionNodeMainV3.codeFingerprint());
  var p=RetentionBatchProfilesV3.finiteLoadProfile();out.put("profileSha256",p.fingerprint());out.put("osName",System.getProperty("os.name"));out.put("javaRuntimeVersion",System.getProperty("java.runtime.version"));
  out.put("profileBounds",Map.of("historyCommands",p.core().maxPendingCommands(),"historyEvents",p.core().maxPendingEvents(),"historyBytes",p.core().maxPendingSerializedBytes(),"eventsPerCommand",p.core().maxEventsPerCommand(),"outboxEvents",p.outboxCapacity(),"journalRecords",p.maxMaintenanceJournalRecords(),"journalBytes",p.maxMaintenanceJournalBytes()));
  var unit=RetentionEngineV3.reservationBound(p.core(),RetentionEngineV3.place(2,"load-w1",2,MatchingEngine.Side.BUY,10,1,MatchingEngine.TimeInForce.IOC));
  var maker=RetentionEngineV3.reservationBound(p.core(),RetentionEngineV3.place(1,"maker",2,MatchingEngine.Side.SELL,10,1000,MatchingEngine.TimeInForce.GTC));
  out.put("reservationExamples",Map.of("unitEvents",unit.events(),"unitHistoryBytes",unit.historyBytes(),"makerEvents",maker.events(),"makerHistoryBytes",maker.historyBytes()));
  out.put("phases",Arrays.stream(RetentionAsyncMaintenanceV4.Phase.values()).map(Enum::name).toList());
  var origins=new ArrayList<Object>();for(Class<?> type:List.of(RetentionAsyncMaintenanceV4.class,RetentionAsyncAeronSmokeV4.class,RetentionPrefixPersistenceV4.class,RetentionArchivePreparationV4.class,RetentionDurableWriterV3.class,RetentionBatchOwnerV3.class,RetentionBatchAeronTransportV3.class,RetentionNodeMainV3.class,RetentionEngineV3.class,MatchingEngine.class,io.aeron.driver.MediaDriver.class,org.agrona.DirectBuffer.class)){
   Path jar=Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI());byte[] bytes=Files.readAllBytes(jar);origins.add(Map.of("class",type.getName(),"path",jar.toString(),"bytes",bytes.length,"sha256",HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes))));
  }out.put("actualClassOrigins",origins);RetentionCapacityJsonV3.writeNew(Path.of(args[0]),out);
 }
}
