"""One fresh finite V4 UDP correctness attempt. No rate/SLA/endurance claim or resource creation."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time,shutil,socket,importlib.util,traceback
HERE=Path(__file__).resolve().parent;C=json.loads((HERE/'config.json').read_text());ROOT=Path(C['root'])
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def save(p,value):
 with p.open('x')as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def require(value,reason):
 if not value:raise RuntimeError(reason)
require(HERE==ROOT and str(ROOT)=='/opt/vectormatch-cpu/experiments/async-v4-udp-functional-r1','wrong fresh namespace')
require(sha(HERE/'owned_linux_base_8eeb.py')==C['qualifiedBaseSha256']and sha(HERE/'owned_process_identity.py')=='51ad33fc51a92cdb9041e78093d39e38a42191a9ec50ad9635fd7cc314ba7a1a','qualified identity/signal bodies differ')
spec=importlib.util.spec_from_file_location('qualified_base',HERE/'owned_linux_base_8eeb.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
base.enable_pidfd();require(socket.gethostname()=='33ace3d92505','CPU host changed')
require(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==C['baseline']['bootId'],'boot changed')
require(sorted(os.sched_getaffinity(0))==C['baseline']['affinity'],'CPU affinity changed')
require(Path('/sys/fs/cgroup/cpu.max').read_text()==C['baseline']['cpuMax']and Path('/sys/fs/cgroup/memory.max').read_text()==C['baseline']['memoryMax'],'cgroups changed')
for parent in ROOT.parents:require(parent.is_dir()and not parent.is_symlink(),'unsafe namespace ancestor')
require(not(ROOT/'state').exists()and not(ROOT/'STARTED.json').exists(),'no automatic retry or reuse')
for p in [Path('/opt/vectormatch-cpu/restorations/original-native-r1'),Path('/opt/vectormatch-cpu/preparation')]:require(not p.exists(),'protected original application path changed')
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 row=base.process_identity(int(p.name))
 if row is not None:require(Path(row['arguments'][0]).name not in('java','javaw','postgres','postmaster'),'foreign Java/SQL workload active before functional run')
require(shutil.disk_usage(ROOT).free>=3*1024**3,'fresh CPU free-space floor3GiB')
java=Path(C['java']);require(sha(java)==C['javaSha256']and sha(java.parent.parent/'release')==C['releaseSha256'],'actual JDK differs')
lib=Path(C['lib']);require(lib==Path('/opt/vectormatch-cpu/tools/cpu-async-v4-metadata-r1/lib'),'wrong qualified runtime')
for name,pin in C['jars'].items():require(sha(lib/name)==pin['sha256']and(lib/name).stat().st_size==pin['bytes'],'runtime JAR body differs')
command=[str(java),'--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m','-cp',':'.join(str(lib/name)for name in C['jarOrder']),'io.vectormatch.cluster.RetentionAsyncAeronSmokeV4',str(ROOT/'state')]
env=os.environ.copy()
for name in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS']:env.pop(name,None)
child=None;owned={};failure=None;started=time.monotonic();native_started=False;observed=0;maximum_live=0
try:
 with(ROOT/'java.stdout').open('xb')as out,(ROOT/'java.stderr').open('xb')as err:
  child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env);native_started=True
  parent=None
  for unused in range(100):
   row=base.process_identity(child.pid)
   if row is not None and row['arguments']==command:parent=row;break
   if child.poll()is not None:break
   time.sleep(.005)
  require(parent is not None,'parent process identity not proven');owned[(parent['pid'],parent['startTicks'])]=dict(parent,role='parent')
  save(ROOT/'STARTED.json',dict(command=command,parent=parent,controller=base.process_identity(os.getpid()),sourceCommit=C['sourceCommit'],artifactFingerprint=C['artifactFingerprint'],performanceClaim=False))
  with(ROOT/'observations.jsonl').open('x')as observations:
   while child.poll()is None:
    now=time.monotonic();require(now-started<=180,'finite functional deadline180s exceeded')
    require(shutil.disk_usage(ROOT).free>=1024**3,'runtime free floor1GiB reached;do not lower')
    registration_path=ROOT/'state/registration.json';registration=None
    if registration_path.exists():
     try:registration=json.loads(registration_path.read_text())
     except json.JSONDecodeError:pass
    live=[]
    for proc in Path('/proc').iterdir():
     if not proc.name.isdigit():continue
     row=base.process_identity(int(proc.name))
     if row is None:continue
     args=row['arguments'];name=Path(args[0]).name
     if name not in ('java','javaw','postgres','postmaster'):continue
     if row['pid']==child.pid:require(all(row[k]==parent[k]for k in ('pid','startTicks','commandSha256','arguments')),'parent identity changed')
     else:
      require(registration is not None,'node appeared before its registration')
      child_cp=':'.join(str(lib/name)for name in ['cluster-0.1.0-SNAPSHOT.jar','core-0.1.0-SNAPSHOT.jar','aeron-all-1.53.3.jar','agrona-2.6.1.jar'])
      expected=[]
      for member in range(3):expected.append([str(java),'--add-opens=java.base/jdk.internal.misc=ALL-UNNAMED','--add-opens=java.base/java.util.zip=ALL-UNNAMED','-Xmx256m','-Daeron.cluster.appointed.leader.id=0','-cp',child_cp,'io.vectormatch.cluster.RetentionNodeMainV3',str(member),str(ROOT/'state'),str(registration['ports']),'2','finite-batch-load-v3-v1',registration['lineage'],C['profileFingerprint'],C['artifactFingerprint'],'bounded-maintenance-v1'])
      require(args in expected,'foreign or changed JVM/SQL process;no signal to unregistered identity')
      try:fields=(proc/'stat').read_text()
      except (FileNotFoundError,ProcessLookupError):continue
      sampled=base.process_identity(row['pid'])
      if sampled is None:continue
      require(all(sampled[k]==row[k]for k in ('pid','startTicks','commandSha256','arguments')),'node identity changed before registration')
      stat_fields=fields[fields.rfind(')')+2:].split();require(int(stat_fields[19])==row['startTicks'],'node birth changed during parent check');ppid=int(stat_fields[1]);require(ppid==child.pid,'node is not the owned parent direct child')
      key=(row['pid'],row['startTicks'])
      if key not in owned:owned[key]=dict(row,role='node',member=args[8]);save(ROOT/('owned-observed-'+str(row['pid'])+'-'+str(row['startTicks'])+'.json'),owned[key])
     live.append({k:row[k]for k in ('pid','startTicks','commandSha256')})
    maximum_live=max(maximum_live,len(live));observations.write(json.dumps(dict(monotonicSeconds=now,freeBytes=shutil.disk_usage(ROOT).free,live=live))+'\n');observations.flush();observed+=1;time.sleep(.05)
  status=child.wait(timeout=5)
 require(status==0,'functional Java returned nonzero;preserve native failure')
 for record in owned.values():require(base.process_identity(record['pid'])is None,'owned Java still alive after completion')
 require(len([r for r in owned.values()if r['role']=='node'])==6,'all six actual node process lifetimes must be observed')
 completion=json.loads((ROOT/'state/completion.json').read_text());require(completion['passed']and completion['allOwnedStopped'],'native completion not proven')
 require(json.loads((ROOT/'state/registration.json').read_text())['code']==C['artifactFingerprint'],'actual artifact fingerprint differs')
 for name,pin in C['jars'].items():require(sha(lib/name)==pin['sha256'],'runtime JAR changed during execution')
 save(ROOT/'SUCCESS.json',dict(passed=True,sourceCommit=C['sourceCommit'],artifactFingerprint=C['artifactFingerprint'],exitCode=status,elapsedSeconds=time.monotonic()-started,observations=observed,observedNodeLifetimes=6,maximumSimultaneousJavaProcesses=maximum_live,allOwnedJavaStrictlyAbsent=True,freeBytesAfter=shutil.disk_usage(ROOT).free,noCapacityOrEnduranceOrPhysicalHostIsolationClaim=True))
except BaseException as error:
 failure=error;cleanup=[]
 for record in sorted(owned.values(),key=lambda row:row['role']=='parent'):
  try:cleanup.append(base.stop_owned(record,10))
  except BaseException as cleanup_error:cleanup.append(dict(pid=record['pid'],error=repr(cleanup_error),noNumericPidFallback=True))
 if child is not None:
  try:child.wait(timeout=15)
  except subprocess.TimeoutExpired:pass
 save(ROOT/'FAILED.json',dict(passed=False,error=repr(error),traceback=traceback.format_exc(),originalFilesRetained=True,noAutomaticRetry=True,cleanup=cleanup,nativeStarted=native_started))
 raise
