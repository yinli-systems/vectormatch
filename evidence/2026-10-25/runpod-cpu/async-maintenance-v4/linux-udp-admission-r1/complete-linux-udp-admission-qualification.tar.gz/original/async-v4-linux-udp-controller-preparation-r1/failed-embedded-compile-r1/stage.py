from pathlib import Path
import importlib.util,hashlib,subprocess,json,base64,shlex,datetime
P=Path(__file__).resolve().parent;B=P.parent;O=B/'async-v4-linux-udp-staging-r1';assert not O.exists()
proof=json.loads((B/'async-v4-linux-admission-private-proof-r1/PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['private']and proof['qualifiedSource']=='b6a53eeb812877cfb6cabdf01cfeb4548de30502'
freeze=json.loads((P/'SOURCE_FREEZE.json').read_text());files={}
for name,pin in freeze['files'].items():
 body=(P/'inputs'/name).read_bytes();assert len(body)==pin['bytes']and hashlib.sha256(body).hexdigest()==pin['sha256'];files[name]=base64.b64encode(body).decode()
script='''from pathlib import Path
import sys,json,base64,hashlib,os,socket
c=json.load(sys.stdin);root=Path('/opt/vectormatch-cpu/experiments/async-v4-udp-functional-r1');assert socket.gethostname()=='33ace3d92505'and not root.exists()
for parent in root.parents:assert parent.is_dir()and not parent.is_symlink()
assert set(c['files'])=={'controller.py','config.json','owned_process_identity.py','owned_linux_base_8eeb.py'}
for name,encoded in c['files'].items():
 body=base64.b64decode(encoded);pin=c['freeze']['files'][name];assert len(body)==pin['bytes']and hashlib.sha256(body).hexdigest()==pin['sha256']
 if name.endswith('.py'):compile(body,name,'exec')
os.umask(0o077);root.mkdir(mode=0o700)
for name,encoded in c['files'].items():
 with(root/name).open('xb')as f:f.write(base64.b64decode(encoded))
(root/'SOURCE_FREEZE.json').write_text(json.dumps(c['freeze'],indent=2,sort_keys=True)+'\n')
result=dict(passed=True,root=str(root),sourceCommit=c['freeze']['sourceCommit'],artifactFingerprint=c['freeze']['artifactFingerprint'],inputBodiesVerified=len(c['files']),actualSystemPythonSyntaxCompiled=True,privateAdmissionCommit=c['privateCommit'],noJavaOrBusinessStarted=True)
(root/'STAGED.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
'''
s=importlib.util.spec_from_file_location('remote',B/'current-read-window32-collection-preparation-r2/remote_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
O.mkdir();(O/'REGISTRATION.json').write_text(json.dumps(dict(atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceSha256=hashlib.sha256(script.encode()).hexdigest(),privateAdmissionCommit=proof['commit'],stageOnlyNoWorkload=True),indent=2)+'\n')
r=m.run(shlex.join(['python3','-B','-c',script]),input=json.dumps(dict(files=files,freeze=freeze,privateCommit=proof['commit'])),timeout=60);(O/'stdout.json').write_text(r.stdout);(O/'stderr').write_text(r.stderr);(O/'EXECUTION.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0,r.stderr;assert json.loads(r.stdout)['passed'];print(r.stdout)
