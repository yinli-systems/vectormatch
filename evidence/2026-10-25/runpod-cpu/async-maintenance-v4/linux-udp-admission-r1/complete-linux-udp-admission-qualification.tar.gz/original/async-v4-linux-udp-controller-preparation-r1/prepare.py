from pathlib import Path
import json,shutil,hashlib,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';P=Path(__file__).resolve().parent;I=P/'inputs';assert not I.exists();I.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ci=json.loads((B/'async-v4-integrated-forced-correctness-r1/RESULT.json').read_text());assert ci['passed']and ci['junit']==dict(tests=422,failures=0,errors=0,skipped=0)
meta=json.loads((B/'async-v4-linux-metadata-execution-r1/ROOT_REVIEW.json').read_text());assert meta['passed']and meta['allTwelveActualLoadedOriginsMatchStagedJars']
observation=json.loads((B/'async-v4-linux-metadata-execution-r1/actual-linux-observation.json').read_text());image=json.loads((B/'async-v4-artifact-preparation-r1/JDK_IMAGE_EQUIVALENCE.json').read_text());assert image['passed']and image['files']==[454,454]
for name in ['owned_linux_base_8eeb.py','owned_process_identity.py']:shutil.copy2(B/'process-identity-exit-wait-controller-bridge-preparation-r1/inputs'/name,I/name)
assert sha(I/'owned_process_identity.py')=='51ad33fc51a92cdb9041e78093d39e38a42191a9ec50ad9635fd7cc314ba7a1a'
assert (I/'owned_process_identity.py').read_bytes()==(R/'scripts/owned_process_identity.py').read_bytes()
shutil.copy2(P/'controller.py',I/'controller.py');c=json.loads((B/'async-v4-linux-metadata-preparation-r1/metadata-config.json').read_text())
c=dict(root='/opt/vectormatch-cpu/experiments/async-v4-udp-functional-r1',sourceCommit=ci['sourceCommit'],artifactFingerprint=observation['actualCodeFingerprint'],profileFingerprint=observation['profileSha256'],baseline=c['baseline'],java=c['java'],javaSha256=c['javaSha256'],releaseSha256=c['releaseSha256'],lib='/opt/vectormatch-cpu/tools/cpu-async-v4-metadata-r1/lib',jarOrder=c['jarOrder'],jars={n[4:]:v for n,v in c['rows'].items()if n.startswith('lib/')},qualifiedBaseSha256=sha(I/'owned_linux_base_8eeb.py'),oneAttemptOnly=True,capacityClaim=False)
(I/'config.json').write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
rows={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(I.iterdir())};(P/'SOURCE_FREEZE.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=rows,qualifiedCi=ci['runId'],sourceCommit=ci['sourceCommit'],artifactFingerprint=c['artifactFingerprint'],originalIdentityAndPidfdSourceBodiesReused=True,qualifiedLegacySignalSourceSha256=c['qualifiedBaseSha256'],newControllerNotYetExecuted=True,noBenchmarkClaim=True),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,source=c['sourceCommit'],fingerprint=c['artifactFingerprint'],files=len(rows))))
