from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';A=W/'evidence/2026-10-25/runpod-cpu/async-maintenance-v4/coordinator-local-r1';O=B/'async-maintenance-coordinator-local-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/async-maintenance-v4').decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A);assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json');assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*[str(W/n)for n in paths]).decode().splitlines()==[blobs[n]for n in paths]
assert git('show',head+':docs/ASYNC_MAINTENANCE_V4.md')==(A/'published/docs/ASYNC_MAINTENANCE_V4.md').read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','-C',str(W),'cat-file','blob',head+':'+prefix+'/complete-coordinator-local-qualification.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
inputs=B/'async-maintenance-coordinator-local-tests-r1/inputs'
registration=json.loads((inputs.parent/'REGISTRATION.json').read_text());sourceCount=0
for name,h in registration['allCoreAndClusterSourcePins'].items():
 source=inputs/name
 assert sha(source)==h and git('show',head+':'+name)==source.read_bytes()==(W/name).read_bytes();sourceCount+=1
assert sourceCount>100
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository='yinli-systems/vectormatch',branch='codex/async-maintenance-v4',commit=head,allGitMetadataBlobsVerified=len(paths),wholeActualGitTarRestored=True,everyOriginalMemberVerified=members,allRegisteredCommittedSourceBodiesMatchTestInputs=sourceCount,junit=closed['junit'],localMacOnly=True,noLinuxNetworkDeploymentOrPerformanceClaim=True,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
