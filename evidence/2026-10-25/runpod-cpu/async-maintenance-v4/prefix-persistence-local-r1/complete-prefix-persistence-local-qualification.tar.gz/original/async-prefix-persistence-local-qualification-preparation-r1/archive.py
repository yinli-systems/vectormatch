from pathlib import Path
import datetime,json,shutil,sys,tarfile
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';P=Path(__file__).resolve().parent;A=W/'evidence/2026-10-25/runpod-cpu/async-maintenance-v4/prefix-persistence-local-r1';assert not A.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=B/'async-prefix-persistence-local-tests-r1';result=json.loads((O/'RESULT.json').read_text());assert result['passed']and result['junit']==dict(tests=21,failures=0,errors=0,skipped=0)
names=[P.name,O.name,'dispatch-capacity-scope-tar-preparation-r1'];before={n:tree(B/n)for n in names};A.mkdir(parents=True);archive=A/'complete-prefix-persistence-local-qualification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
 for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,before);assert all(tree(B/n)==before[n]for n in names)
(A/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');shutil.copy2(O/'RESULT.json',A/'RESULT.json');p=A/'published/docs/ASYNC_MAINTENANCE_V4.md';p.parent.mkdir(parents=True);shutil.copy2(W/'docs/ASYNC_MAINTENANCE_V4.md',p)
(A/'README.md').write_text('''# V4 asynchronous file-prefix pipeline:local qualification

Complete actual forced local Mac source/compiled classes/commands/logs/JUnit:21 tests,zero failure/error/skip,covering writer polling,archive preparation and the new one-cut file-prefix persistence pipeline. Delayed archive force and delayed event force independently prevent a combined durable receipt. Caller mutation cannot change owned jobs,corrupted event evidence never produces success,foreign/double consume and lifetime admission are refused,wrong previous event frontiers fail before file writing,and rejected zero-event commands need no invented event file.

The pipeline never issues an ACK or mutates replicated state. File-credit consume is not network ACK permission. Original failed/unconsumed inputs remain available;borrowed workers are not cancelled. This is not an integrated network coordinator,Linux V4 qualification,deployment,an optimization gain or100M continuity. It is excluded from the concurrent immutable-batch encoding comparison. All original input/compiled/test/result bodies are preserved in the complete scope TAR.
''')
inv=tree(A);(A/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(A/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(A/'INVENTORY.json'),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),scopeReview=members,junit=result['junit'],localMacOnly=True,noDeploymentOrPerformanceClaim=True),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,archiveBytes=archive.stat().st_size,originalFiles=members['originalFiles'])))
