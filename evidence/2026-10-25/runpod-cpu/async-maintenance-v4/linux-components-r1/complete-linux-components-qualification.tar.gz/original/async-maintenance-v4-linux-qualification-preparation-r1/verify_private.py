from pathlib import Path
import datetime,json,subprocess,sys
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';W=B/'async-maintenance-v4-worktree';A=W/'evidence/2026-10-25/runpod-cpu/async-maintenance-v4/linux-components-r1';O=B/'async-maintenance-v4-linux-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
head=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/codex/async-maintenance-v4').decode().split()[0]==head
assert json.loads(subprocess.check_output(['gh','api','repos/yinli-systems/vectormatch']))['private']
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A);assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json');assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']and all(actual['files'][n]==v for n,v in inv['files'].items())
prefix=A.relative_to(W).as_posix();blobs={}
for row in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);blobs[name.decode()]=meta.split()[2].decode()
paths=sorted(blobs);assert set(paths)=={prefix+'/'+n for n in actual['files']};assert git('hash-object','--',*[str(W/n)for n in paths]).decode().splitlines()==[blobs[n]for n in paths]
assert git('show',head+':docs/ASYNC_MAINTENANCE_V4.md')==(A/'published/docs/ASYNC_MAINTENANCE_V4.md').read_bytes()
O.mkdir();restored=O/'restored.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','-C',str(W),'cat-file','blob',head+':'+prefix+'/complete-linux-components-qualification.tar.gz'],stdout=out,check=True)
assert restored.stat().st_size==closed['archiveBytes']and sha(restored)==closed['archiveSha256'];members=verify(restored,json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text()));assert members==closed['scopeReview'];restored.unlink()
import tarfile,hashlib,stat
collection=B/'production-ci-attempt-10-collection-r1';manifest=json.loads((collection/'remote-manifest.json').read_text());seen=set()
with tarfile.open(collection/'complete-code-compiled-tests-and-public-logs.tar.gz')as t:
 for member in t:
  assert member.isfile()and member.name.startswith('original/');n=member.name[len('original/'):];assert n not in seen;seen.add(n);v=manifest['originalFiles'][n]
  body=t.extractfile(member).read();assert member.size==v['bytes']and hashlib.sha256(body).hexdigest()==v['sha256']and stat.S_IMODE(member.mode)==v['mode']and member.uid==v['uid']and member.gid==v['gid']
assert seen==set(manifest['originalFiles'])and len(seen)==806
assert manifest['sourceCommit']=='9df3c0f0a36848e269a6ce9c024aedf7f3a9141e'
proof=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository='yinli-systems/vectormatch',branch='codex/async-maintenance-v4',commit=head,allGitMetadataBlobsVerified=len(paths),wholeActualGitTarRestored=True,everyOriginalMemberVerified=members,all806NestedActualLinuxOriginalFilesVerified=True,qualifiedSource=manifest['sourceCommit'],junit=closed['junit'],actualLinuxComponentsOnly=True,noNetworkCoordinatorOrDeploymentOrPerformanceClaim=True,sourceSha256=sha(Path(__file__)))
(O/'PRIVATE_PUSH.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n');print(json.dumps(proof))
