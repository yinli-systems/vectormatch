from pathlib import Path
import sys,json,tarfile,shutil,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024'
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
O=R/'evidence/2026-10-25/runpod-cpu/writer-phase-timing-v3/reporting-r1';assert not O.exists()
report=B/'writer-timing-abab-reporting-r1';comparison=json.loads((report/'COMPARISON.json').read_text());applied=json.loads((report/'APPLIED.json').read_text())
assert comparison['passed']and applied['passed']and applied['indexSha256']==sha(R/'evidence/index.json')
sources={n:n for n in ['writer-timing-abab-reporting-r1','writer-timing-abab-reporting-preparation-r1',
    'writer-timing-abab-bottleneck-preparation-r1','writer-timing-abab-recovery-preparation-r1','writer-timing-abab-maintenance-phases-preparation-r1']}
sources['writer-timing-schema-audit-preparation-r1']='writer-timing-schema-audit-preparation-r1'
sources['writer-timing-abab-local-duplicate-retirement-preparation-r1']='writer-timing-abab-local-duplicate-retirement-preparation-r1'
for case in ('a1','b1','a2','b2'):
    for suffix in ('private-proof','bottleneck','cut-recovery','maintenance-phases','schema-audit'):
        sources[f'{case}-{suffix}']=f'writer-timing-abab-{case}-{suffix}-r1'
for p in B.glob('writer-timing-abab-duplicate-retirement-*-r1'):
    sources[p.name]=p.name
scopes={label:tree(B/n)for label,n in sources.items()}
O.mkdir();archive=O/'complete-reporting-scopes.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for label,n in sources.items():t.add(B/n,arcname='original/'+label)
review=verify(archive,scopes);assert all(tree(B/n)==scopes[label]for label,n in sources.items())
(O/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(scopes,indent=2,sort_keys=True)+'\n')
(O/'SOURCE_MIRRORS.json').write_text(json.dumps(sources,indent=2,sort_keys=True)+'\n')
for n in ['README.md','docs/WRITER_TIMING_RESULTS_V3.md','docs/WRITER_TIMING_ABAB_V3.md','docs/PRODUCTION_ACCEPTANCE.md','evidence/index.json']:
    p=O/'published'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p);assert sha(p)==sha(R/n)
shutil.copy2(report/'COMPARISON.json',O/'COMPARISON.json')
(O/'README.md').write_text('# Writer timing A1/B1/A2/B2: complete reporting\n\nFour registered fresh80,000-arrival lineages at4,000/s for20s. Two original-control and two instrumentation observations,with the same project-only cache preconditioning,JDK,leader,durability and runtime bounds. Every original native/raw body remains in the four sibling arm archives. No optimization,statistical significance,sustained capacity,millisecond SLA or100M proof is claimed.\n\nThis package retains every analysis source and result,all private native closure proofs,per-arrival decomposition,recovery intervals,cycle/receipt timing audits,previous and derived index,application/HTTP receipts,and exact published files. All51 earlier runs and20 cohorts remain unchanged;the derived index contains55 runs/22 cohorts. HTTP verification is not a browser-render claim. See the exact published report for measured values and phase accounting.\n')

inv=tree(O);(O/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
(O/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(O/'INVENTORY.json'),scopeReview=review,records=55,cohorts=22,observations=4,higherLoadPermitted=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,payloadFiles=len(inv['files']),originalReportingFiles=review['originalFiles'],archiveBytes=archive.stat().st_size,inventorySha256=sha(O/'INVENTORY.json'))))
