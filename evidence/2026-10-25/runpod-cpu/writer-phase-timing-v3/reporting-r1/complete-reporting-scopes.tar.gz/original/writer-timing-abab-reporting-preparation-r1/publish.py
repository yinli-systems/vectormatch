from pathlib import Path
import datetime, hashlib, json, urllib.request

R = Path.cwd()
B = R / 'runtime/cloud/cpu-20261024'
O = B / 'writer-timing-abab-reporting-r1'
assert not (O / 'APPLIED.json').exists()
c = json.loads((O / 'COMPARISON.json').read_text())
assert c['passed'] and c['all51PriorRunsAnd20CohortsPreserved']
assert (R/'evidence/index.json').read_bytes() == (O/'index-before.json').read_bytes()
rows = c['observations']
text = '''# Writer phase timing: A1/B1/A2/B2

All four registered observations accept every planned arrival,with zero notSent,rejection,observed UNKNOWN or final UNKNOWN. This closes an instrumentation comparison,not a performance optimization or the production latency target.

Each observation is a fresh80,000-order lineage at4,000 scheduled IOC arrivals/s for20s. All four use leader0,sync2,ROTATING_CONTINUE,read128,page32,batch4,chunk6144,owner1ms,driver100us,W128/Q64,one physical session and three JVMs on the same CPU host. JDK/container/boot/affinity/cgroups are pinned;two original-PID2s readiness gates bracket setup/5s warm-up;no JFR. The same registered project-only read-only cache preconditioning precedes each arm. The initial A1 memory-headroom refusal and every preflight/cache receipt are retained. See the [prospective registration](WRITER_TIMING_ABAB_V3.md).

## Observed finite behavior

| Arm | Artifact | Accepted | In-window goodput/s | All-arrival p50 ms | All-arrival p99 ms | After-positive-offer p99 ms | Clearing offered-cut intervals |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for r in rows:
    text += f"| {r['caseId'].upper()} | {r['codeFingerprint'][:8]} | {r['accepted']:,} | {r['goodput']:.2f} | {r['p50Ns']/1e6:.6f} | {r['p99Ns']/1e6:.6f} | {r['afterOfferP99Ns']/1e6:.6f} | {r['clearingIntervals']}/{r['fullOfferedCutIntervals']} |\n"
text += '''
A1/A2 use original source566dd2fa/code2b8d7594. B1/B2 use timing sourceaed9430d/codef3a5745c,qualified by the full forced Linux CI run. The41 core classes are identical;the timing change preserves all canonical validation,force/readback,receipt completion and ACK fences. The small p99 differences do not establish causation or statistical significance. These are two observations per artifact on shared hardware,without randomized ordering or long-duration replication.

In-window goodput counts confirmations during the20s arrival window;all80,000 distinct accepts reconcile after drain. Comparable recovery intervals exclude setup and post-arrival drain. Clearing recorded waiting is a finite observation,not proof of an unbounded steady-state workload. Successful-offer-to-reply includes client polling,loopback transport,replication and service;it is not network RTT.

## Where maintenance time goes

Each arm completes27 maintenance cycles. Every original cycle and all54 payloads/receipts are checked. Every B cycle has timing schema1;every A cycle retains the legacy schema. Exported write/force/readback values exactly match their corresponding payload receipts,with payload byte length/SHA-256 verified. All seven serial writer phases fit within writer elapsed;copy and queue precede that interval.

The following durations are summed over one arm's27 cycles,in seconds. RPC intervals are merged by monotonic interval union,not summed across concurrent calls. They include queueing,service and evidence consumption. Writer elapsed includes prevalidation,hashing,write,force,full readback and receipt write/force;the subphases below are components of elapsed and must not be added to elapsed a second time.

| Measured duration,seconds | B1 | B2 |
| --- | ---: | ---: |
'''
bs = [r for r in rows if r['caseId'].startswith('b')]
metrics = [
    ('Maintenance wall', lambda r:r['maintenanceWallNs']),
    ('Source-RPC interval union', lambda r:r['rpcIntervalUnionNs']),
    ('Coordinator archive verification', lambda r:r['coordinatorArchiveVerificationNs']),
    ('Archive writer elapsed', lambda r:r['writerTotals']['archive']['ElapsedNs']),
    ('Archive writer repeated prevalidation,inside elapsed', lambda r:r['writerTotals']['archive']['PrevalidationNs']),
    ('Archive full readback,inside elapsed', lambda r:r['writerTotals']['archive']['ReadbackNs']),
    ('Event writer elapsed', lambda r:r['writerTotals']['events']['ElapsedNs']),
    ('All payload and receipt forces,inside writer elapsed', lambda r:sum(t['ForceNs']+t['ReceiptForceNs'] for t in r['writerTotals'].values())),
    ('All handoff copy and queue,outside writer elapsed', lambda r:sum(t['CopyNs']+t['QueueWaitNs'] for t in r['writerTotals'].values())),
    ('Remaining coordinator/uninstrumented residual', lambda r:r['detailedUninstrumentedResidualNs'])]
for label, fn in metrics:text += f"| {label} | {fn(bs[0])/1e9:.9f} | {fn(bs[1])/1e9:.9f} |\n"
text += '\n'
for r in bs:
    duplicate = r['writerTotals']['archive']['PrevalidationNs']/r['maintenanceWallNs']*100
    force = sum(t['ForceNs']+t['ReceiptForceNs'] for t in r['writerTotals'].values())/r['maintenanceWallNs']*100
    text += f"{r['caseId'].upper()}:duplicate archive prevalidation accounts for{duplicate:.2f}% of maintenance wall;all measured payload/receipt forces account for{force:.2f}%. The slowest1% requests spend{r['tailPredispatchShare']*100:.2f}% of their summed latency before dispatch.\n\n"
text += '''The measured next candidate is an [immutable verified archive handoff](VERIFIED_ARCHIVE_HANDOFF_V3.md),which avoids one repeated pre-write parse while keeping complete canonical validation of the forced readback. It needs separate artifact qualification and controlled trials. None of this report's arms executes that candidate. The results do not justify attributing the bottleneck to physical disk,CPU alone or a cross-host network.

## Complete evidence and limits

'''
for r in rows:
    case = r['caseId']
    text += f"- [{case.upper()} complete native/raw evidence](../evidence/2026-10-25/runpod-cpu/writer-phase-timing-v3/arm-{case}-native-r1/README.md),privately closed at`{r['privateCommit']}`.\n"
text += '''
The [complete reporting package](../evidence/2026-10-25/runpod-cpu/writer-phase-timing-v3/reporting-r1/README.md) retains the comparison/audit sources,per-arrival decomposition,recovery intervals,phase/receipt checks,private closure proofs,and previous/derived UI index. The four native packages retain every original closed native TAR,CSV,wire/frame/offer,identity,readiness and lifecycle record as lossless compressed scope parts,with full member SHA/size/mode/owner verification. Candidate-codec/reference checks are not an independent matching oracle or binary cold restore.

All51 prior runs and20 cohorts remain unchanged. The index appends four observations in two separate artifact/setup cohorts,55 runs/22 cohorts. No stable marker or prior capacity curve is inferred from this diagnostic. HTTP verification is not a rendered-browser check.

The four fresh lineages cannot be added into continuous endurance. No100M target,independent physical-host fault isolation,millisecond SLA,production certification or HFT endorsement is established. Current all-arrival p99 remains hundreds of milliseconds. The [production acceptance gates](PRODUCTION_ACCEPTANCE.md) remain explicit.
'''
target = R/'docs/WRITER_TIMING_RESULTS_V3.md'
assert not target.exists()
target.write_text(text)
(R/'evidence/index.json').write_bytes((O/'index-derived.json').read_bytes())
applied = dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               indexSha256=hashlib.sha256((R/'evidence/index.json').read_bytes()).hexdigest(),
               reportSha256=hashlib.sha256(target.read_bytes()).hexdigest(),records=55,cohorts=22,
               all51PriorRunsAnd20CohortsPreserved=True)
(O/'APPLIED.json').write_text(json.dumps(applied,indent=2,sort_keys=True)+'\n')
# Public local workbench route only;do not collect account/private application APIs.
with urllib.request.urlopen('http://127.0.0.1:8011/api/evidence',timeout=10) as response:
    body=response.read();status=response.status
(O/'http-evidence-body.json').write_bytes(body)
doc=json.loads(body)
http=dict(passed=status==200 and doc==json.loads((R/'evidence/index.json').read_text()),status=status,
          bodySha256=hashlib.sha256(body).hexdigest(),records=len(doc['runs']),cohorts=len(doc['capacityCohorts']),
          browserRenderVerified=False,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(O/'HTTP_REVIEW.json').write_text(json.dumps(http,indent=2,sort_keys=True)+'\n')
assert http['passed']
print(json.dumps(dict(applied=applied,http=http)))
