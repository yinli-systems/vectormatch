package io.vectormatch.cluster;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;
public final class Read128CapacityDistributionObservation {
 public static void main(String[] args)throws Exception{
  var out=new LinkedHashMap<String,Object>();out.put("noDriverOrClusterStarted",true);out.put("performanceEvidence",false);out.put("sourceCommit","aed9430d133d86bfe9fc6abe47ede623ef3309b2");out.put("preloadWarmupMillisIntent",5000);out.put("actualCodeFingerprint",RetentionNodeMainV3.codeFingerprint());out.put("profileSha256",RetentionBatchProfilesV3.finiteLoadProfile().fingerprint());out.put("osName",System.getProperty("os.name"));out.put("javaRuntimeVersion",System.getProperty("java.runtime.version"));
  var plans=new LinkedHashMap<String,Object>();
  for(int rate:new int[]{500,1000,2000,4000,8000,16000}){
   var config=RetentionCapacityExperimentV3.Config.maintainedReadWindow128Capacity(rate);var plan=RetentionCapacityExperimentV3.boundedPlan(config,RetentionBatchProfilesV3.finiteLoadProfile());plan.requireAdmitted();
   plans.put(Integer.toString(rate),Map.of("arrivals",config.arrivals(),"rate",config.rate(),"windowNs",config.windowNs(),"readWindow",config.readWindow(),"eventFetchCount",config.eventFetchCount(),"maintainedCapacityPreset",config.maintainedCapacityPreset(),"plan",plan.observation()));
  }
  out.put("readinessContract",Map.of("quietPeriodNs",RetentionStartupReadinessV3.class.getDeclaredField("QUIET_NS").getLong(null),"deadlineNs",RetentionStartupReadinessV3.class.getDeclaredField("TIMEOUT_NS").getLong(null),"gateCountBeforeArrivalWindow",2));var fairness=new LinkedHashMap<String,Object>();for(boolean rotating:new boolean[]{false,true}){var c=RetentionCapacityExperimentV3.Config.read128DispatchFairness(rotating);var p=RetentionCapacityExperimentV3.boundedPlan(c,RetentionBatchProfilesV3.finiteLoadProfile());p.requireAdmitted();fairness.put(rotating?"rotating":"fixed",Map.of("policy",c.dispatchOrderPolicy(),"arrivals",c.arrivals(),"rate",c.rate(),"plan",p.observation()));}out.put("dispatchFairnessConfigs",fairness);var fine=new LinkedHashMap<String,Object>();for(int rate:new int[]{4000,6000,7000,7500,8000}){var policies=new LinkedHashMap<String,Object>();for(boolean rotating:new boolean[]{false,true}){var c=RetentionCapacityExperimentV3.Config.read128DispatchCapacity(rate,rotating);var p=RetentionCapacityExperimentV3.boundedPlan(c,RetentionBatchProfilesV3.finiteLoadProfile());p.requireAdmitted();policies.put(rotating?"rotating":"fixed",Map.of("policy",c.dispatchOrderPolicy(),"fineDispatchCapacityPreset",c.fineDispatchCapacityPreset(),"arrivals",c.arrivals(),"rate",c.rate(),"plan",p.observation()));}fine.put(Integer.toString(rate),policies);}out.put("dispatchCapacityConfigs",fine);out.put("plans",plans);var origins=new ArrayList<Object>();
  for(Class<?> type:List.of(RetentionCapacityAeronPilotV3.class,RetentionStartupReadinessV3.class,RetentionCapacityDispatchOrderV3.class,RetentionCapacityExperimentV3.class,RetentionBatchOwnerV3.class,RetentionBatchMaintenanceV3.class,io.vectormatch.core.MatchingEngine.class,io.aeron.driver.MediaDriver.class,org.agrona.DirectBuffer.class)){
   Path jar=Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI());byte[] bytes=Files.readAllBytes(jar);origins.add(Map.of("class",type.getName(),"path",jar.toString(),"bytes",bytes.length,"sha256",HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes))));
  }
  out.put("actualClassOrigins",origins);RetentionCapacityJsonV3.writeNew(Path.of(args[0]),out);
 }
}
