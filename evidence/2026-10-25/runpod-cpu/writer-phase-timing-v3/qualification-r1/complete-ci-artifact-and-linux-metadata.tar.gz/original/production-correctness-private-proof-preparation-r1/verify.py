from pathlib import Path
import sys,json,subprocess,tarfile,hashlib,io,stat,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';A=R/'evidence/2026-10-25/runpod-cpu/production-correctness-r1';O=B/'production-correctness-private-proof-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
def git(*args):return subprocess.check_output(['git',*args])
head=git('rev-parse','HEAD').decode().strip()
for branch in ('main','codex/production-correctness-and-maintenance'):assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==head
repo=json.loads(subprocess.check_output(['gh','repo','view','yinli-systems/vectormatch','--json','isPrivate,nameWithOwner']));assert repo['isPrivate']and repo['nameWithOwner']=='yinli-systems/vectormatch'
inv=json.loads((A/'INVENTORY.json').read_text());closed=json.loads((A/'CLOSED.json').read_text());actual=tree(A)
assert closed['passed']and closed['inventorySha256']==sha(A/'INVENTORY.json')
assert set(actual['files'])==set(inv['files'])|{'INVENTORY.json','CLOSED.json'}and actual['directories']==inv['directories']
assert all(actual['files'][n]==row for n,row in inv['files'].items())
prefix=A.relative_to(R).as_posix();blobs={}
for e in git('ls-tree','-r','-z',head,'--',prefix).split(b'\0'):
    if e:
        m,n=e.split(b'\t',1);assert m.split()[1]==b'blob';blobs[n.decode()]=m.split()[2].decode()
names=sorted(blobs);assert set(names)=={prefix+'/'+n for n in actual['files']}
assert git('hash-object','--',*names).decode().splitlines()==[blobs[n]for n in names]
O.mkdir();restored=O/'restored-complete-code-ci-and-analysis-scopes.tar.gz'
with restored.open('xb')as out:subprocess.run(['git','cat-file','blob',head+':'+prefix+'/'+restored.name.removeprefix('restored-')],stdout=out,check=True)
assert restored.stat().st_size==closed['compressedArchiveBytes']and sha(restored)==closed['compressedArchiveSha256']
scopes=json.loads((A/'ORIGINAL_SCOPE_INVENTORIES.json').read_text());members=verify(restored,scopes);assert members==closed['originalScopeReview']
nested=[]
with tarfile.open(restored)as outer:
    outerFiles={m.name:m for m in outer}
    for attempt in range(1,6):
        base=f'original/production-ci-attempt-{attempt}-collection-r1/'
        manifest=json.load(outer.extractfile(outerFiles[base+'remote-manifest.json']));review=json.load(outer.extractfile(outerFiles[base+'VERIFIED.json']));assert review['passed']
        raw=outer.extractfile(outerFiles[base+'complete-code-compiled-tests-and-public-logs.tar.gz']).read();assert len(raw)==review['archiveBytes']and hashlib.sha256(raw).hexdigest()==review['archiveSha256']==manifest['archive']['sha256']
        seen=set()
        with tarfile.open(fileobj=io.BytesIO(raw))as inner:
            for m in inner:
                assert m.isfile()and m.name.startswith('original/');name=m.name[len('original/'):];assert name not in seen and name in manifest['originalFiles'];seen.add(name);p=manifest['originalFiles'][name];h=hashlib.sha256()
                f=inner.extractfile(m)
                for block in iter(lambda:f.read(1024**2),b''):h.update(block)
                assert m.size==p['bytes']and h.hexdigest()==p['sha256']and stat.S_IMODE(m.mode)==p['mode']and m.uid==p['uid']and m.gid==p['gid']
        assert seen==set(manifest['originalFiles'])and len(seen)==review['allOriginalCollectedFilesVerified']
        nested.append(dict(attempt=attempt,sourceCommit=manifest['sourceCommit'],githubConclusion=manifest['githubConclusion'],allOriginalFilesReverified=len(seen),compressedArchiveSha256=review['archiveSha256']))
forced=json.loads((A/'FORCED_RESULT.json').read_text());assert forced['passed']and forced['allTestTasksExecutedWithoutResultCache']and forced['junit']==dict(tests=390,failures=0,errors=0,skipped=0)
source=forced['sourceCommit'];subprocess.run(['git','merge-base','--is-ancestor',source,head],check=True)
changed=git('diff','--name-only',source,head).decode().splitlines();assert all(n=='README.md'or n.startswith(('docs/','evidence/'))for n in changed)
published=['README.md','docs/PRODUCTION_ACCEPTANCE.md','docs/PRODUCTION_CORRECTNESS_RESULTS.md','docs/REVIEW_AND_REPRODUCE.md','docs/MAINTENANCE_WRITER_TIMING_V3.md']
for n in published:assert git('show',head+':'+n)==(A/'published'/n).read_bytes()==(R/n).read_bytes()
result=dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),private=True,repository=repo['nameWithOwner'],commit=head,bothRemoteBranchesVerified=True,
    allEvidenceGitBlobsVerified=len(names),publishedGitBlobsVerified=len(published),restoredArchiveDirectlyFromCommittedGitBlob=True,
    completeOuterScopeReview=members,allFiveNestedCiOriginalCollectionsReverified=nested,totalNestedOriginalFiles=sum(x['allOriginalFilesReverified']for x in nested),
    forcedCiSourceCommit=source,forcedRunId=forced['runId'],allTestTasksActuallyExecuted=True,noApplicationOrWorkflowCodeChangeSinceForcedCi=True,
    junit=forced['junit'],postgresIntegration=forced['postgresIntegration'],pythonTests=forced['pythonTests'],hostedBillingBlockStillPresent=True,
    noProductionOrPerformanceCertification=True,inventorySha256=sha(A/'INVENTORY.json'),sourceSha256=sha(Path(__file__)),onlyGeneratedRestoredDuplicateRemoved=True)
(O/'PRIVATE_PUSH.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');restored.unlink();print(json.dumps({k:v for k,v in result.items()if k not in('allFiveNestedCiOriginalCollectionsReverified','completeOuterScopeReview')}))
