from pathlib import Path
import json,tarfile,shutil,sys,datetime
R=Path.cwd();B=R/'runtime/cloud/cpu-20261024';O=R/'evidence/2026-10-25/runpod-cpu/writer-phase-timing-v3/qualification-r1';assert not O.exists()
sys.path.insert(0,str(B/'dispatch-capacity-scope-tar-preparation-r1'));from scope_tar import tree,verify,sha
names=['writer-phase-timing-artifact-preparation-r1','writer-phase-timing-linux-metadata-preparation-r1','writer-phase-timing-linux-metadata-execution-r1',
       'writer-phase-timing-metadata-generation-fix-r1','production-correctness-private-proof-r1','production-correctness-private-proof-preparation-r1',
       'writer-phase-timing-qualification-archive-preparation-r1']
artifact=B/names[0];metadata=B/names[2];proof=json.loads((B/'production-correctness-private-proof-r1/PRIVATE_PUSH.json').read_text());assert proof['passed']and proof['private']and proof['allTestTasksActuallyExecuted']
for n in ['JDK_IMAGE_EQUIVALENCE.json','CLASS_DIFFERENCE_REVIEW.json','TICKET_CODE_EQUIVALENCE.json']:assert json.loads((artifact/n).read_text())['passed']
actual=json.loads((metadata/'actual-linux-observation.json').read_text());review=json.loads((metadata/'ROOT_REVIEW.json').read_text());assert review['passed']and actual['sourceCommit']==proof['forcedCiSourceCommit']and actual['actualCodeFingerprint']=='f3a5745cb67f6d46aae28ef68dede0a5b7a767a795dab3bd07c3b5d4143464ca'
legacy=json.loads((B/'dispatch-capacity-controller-4000-preparation-r1/release.json').read_text())
assert actual['dispatchCapacityConfigs']['4000']['rotating']['plan']==legacy['derivedPlan']
assert actual['readinessContract']==legacy['readinessContract']
scopes={n:tree(B/n)for n in names};O.mkdir(parents=True);archive=O/'complete-ci-artifact-and-linux-metadata.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as t:
    for n in names:t.add(B/n,arcname='original/'+n)
members=verify(archive,scopes);assert all(tree(B/n)==scopes[n]for n in names)
(O/'ORIGINAL_SCOPE_INVENTORIES.json').write_text(json.dumps(scopes,indent=2,sort_keys=True)+'\n')
for src,name in [(artifact/'JAR_INPUTS.json','JAR_INPUTS.json'),(artifact/'JDK_IMAGE_EQUIVALENCE.json','JDK_IMAGE_EQUIVALENCE.json'),(artifact/'CLASS_DIFFERENCE_REVIEW.json','CLASS_DIFFERENCE_REVIEW.json'),(metadata/'ROOT_REVIEW.json','LINUX_METADATA_REVIEW.json'),(B/'production-correctness-private-proof-r1/PRIVATE_PUSH.json','CI_PRIVATE_PROOF.json')]:shutil.copy2(src,O/name)
p=O/'published/docs/WRITER_TIMING_ABAB_V3.md';p.parent.mkdir(parents=True);shutil.copy2(R/'docs/WRITER_TIMING_ABAB_V3.md',p)
(O/'README.md').write_text('''# CI-qualified writer timing artifact and registered comparison

Sourceaed9430d/codef3a5745c is taken from the actual forced Linux CI build. All226 core/cluster class bodies equal actual tested compiled classes.390 Java/11 real PostgreSQL/171 Python plus failover and web checks passed;complete CI originals are privately archived and directly restored/reverified at the referenced commit. The complete454-file JDK image equals the existing benchmark JDK image. Local/Linux metadata agrees,all nine loaded origins match the four JAR bodies,all unchanged defaults/plans and the fixed4000/s plan remain admitted. Every JAR,source,metadata record and review body is retained in the complete scope TAR.

The original class-difference guard stopped because it expected four changed classes and omitted Ticket's shifted source-line debug metadata. All41 core classes are byte-identical. Only the two instrumented main sources change;five existing class bodies plus one added PhaseTimings class differ. Ticket method signatures/instructions and all verbose attributes except file identity and source line numbers agree. No compiler-option difference was established. The initial generated metadata wrapper also stopped locally on an existing-output guard;its corrected generator/wrapper and original sources remain retained. Neither issue launched a benchmark.

Register legacy/timing A1/B1/A2/B2 at4000/s,20s each;fixed leader0/sync2/ROTATING_CONTINUE/read128/page32/batch4/chunk6144/owner1ms/driver100us/W128Q64/one physical session. Strict native/readiness/raw/private closure precedes each arm. These are timing diagnostics,not an optimization,sustained-capacity result,millisecond SLA or100M proof. No benchmark has been executed by this qualification.
''')
inv=tree(O);(O/'INVENTORY.json').write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n');(O/'CLOSED.json').write_text(json.dumps(dict(passed=True,atUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),inventorySha256=sha(O/'INVENTORY.json'),archiveSha256=sha(archive),archiveBytes=archive.stat().st_size,scopeReview=members,sourceCommit=actual['sourceCommit'],codeFingerprint=actual['actualCodeFingerprint'],noNativePerformanceClaim=True),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(passed=True,payloadFiles=len(inv['files']),archiveBytes=archive.stat().st_size,sourceFiles=members['originalFiles'],inventorySha256=sha(O/'INVENTORY.json'))))
